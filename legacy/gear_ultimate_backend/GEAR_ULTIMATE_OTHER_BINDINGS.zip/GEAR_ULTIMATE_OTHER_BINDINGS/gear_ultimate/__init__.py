"""GEAR Ultimate reusable backend."""
GEAR_ULTIMATE_VERSION = "2026.08-other-bindings-v1"
