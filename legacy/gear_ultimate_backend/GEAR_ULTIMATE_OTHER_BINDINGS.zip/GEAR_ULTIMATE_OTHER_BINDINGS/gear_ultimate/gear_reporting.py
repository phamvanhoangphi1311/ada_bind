"""Reporting helpers for GEAR Ultimate."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from . import gear_core as core


def experiment_manifest(base, run_version, config, representations, extra=None, label_column=None):
    label_column = label_column or getattr(config, "label_column", "metal_binding")
    root=Path(base)/"results"/run_version/label_column; root.mkdir(parents=True,exist_ok=True)
    payload={"run_version":run_version,"config":config.__dict__ if hasattr(config,"__dict__") else dict(config),"representations":{k:list(v) for k,v in representations.items()}}
    if extra: payload.update(extra)
    p=root/"experiment_manifest.json"; p.write_text(json.dumps(payload,indent=2,default=str)); return p


def final_six_row_table(base, modern_run_version, model="MLP", label_column="metal_binding"):
    """Build paper-style final table with historical KAN plus five/final modern variants when available."""
    base=Path(base); modern=base/"results"/modern_run_version/label_column/"external_summary.csv"; rows=[]
    old_candidates=[base/"results/no_graph_final"/f"{label_column}_final_results.csv"]
    old=next((p for p in old_candidates if p.exists()),None)
    if old:
        odf=pd.read_csv(old)
        for _,r in odf.iterrows():
            rows.append({"representation":"Original ESM+Structure+KAN","dataset":r["dataset"],"AUPRC":r.get("auprc",np.nan),"AUROC":r.get("auroc",np.nan),"F1@0.5":r.get("micro_f1",np.nan),"MCC@0.5":r.get("micro_mcc",np.nan),"OOF_threshold":np.nan,"F1@OOF":np.nan,"MCC@OOF":np.nan})
    if modern.exists():
        df=pd.read_csv(modern); df=df[df.model.astype(str)==str(model)] if "model" in df else df
        wanted=["ESM+Atomic","ESM+Chem","ESM+Atomic+Chem","ESM+MULTI2","ESM+Atomic+Chem+MULTI2"]
        for rep in wanted:
            q=df[df.representation==rep]
            for _,r in q.iterrows():
                rows.append({"representation":rep,"dataset":r["dataset"],"AUPRC":r.get("AUPRC",np.nan),"AUROC":r.get("AUROC",np.nan),"F1@0.5":r.get("F1_at_0.5",r.get("F1@0.5",np.nan)),"MCC@0.5":r.get("MCC_at_0.5",r.get("MCC@0.5",np.nan)),"OOF_threshold":r.get("OOF_tuned_threshold",r.get("OOF_threshold",np.nan)),"F1@OOF":r.get("F1_at_OOF_threshold",r.get("F1@OOF",np.nan)),"MCC@OOF":r.get("MCC_at_OOF_threshold",r.get("MCC@OOF",np.nan))})
    out=pd.DataFrame(rows)
    if len(out):
        # relative AUPRC against original within dataset
        for ds in out.dataset.unique():
            mask=out.dataset==ds; q=out[mask & out.representation.str.startswith("Original")]
            if len(q):
                b=float(q.iloc[0].AUPRC); out.loc[mask,"relative_AUPRC_vs_original_pct"]=(out.loc[mask,"AUPRC"]/b-1)*100
    return out


def load_ensemble_csv(base, run_version, model, representation, dataset, label_column="metal_binding"):
    safe=representation.replace("+","__"); p=Path(base)/"results"/run_version/label_column/"ensemble_predictions"/f"{model}__{safe}__{dataset}.csv.gz"
    if not p.exists(): raise FileNotFoundError(p)
    return pd.read_csv(p)


def positive_transition_table(prediction_frames, threshold=.5):
    """Count TP/FN among truly positive residues for a mapping stage->prediction dataframe."""
    rows=[]
    for name,df in prediction_frames.items():
        y=df.label.to_numpy(int); p=df.probability.to_numpy(float); pos=y==1; pred=p>=threshold
        rows.append({"stage":name,"positive_residues":int(pos.sum()),"TP":int((pos&pred).sum()),"FN":int((pos&~pred).sum()),"recall":float((pos&pred).sum()/max(pos.sum(),1))})
    return pd.DataFrame(rows)


def esm_origin_rescue(prediction_frames, esm_key="ESM", final_key="Final", threshold=.5):
    """Quantify final rescues/losses relative to ESM among positive residues."""
    a=prediction_frames[esm_key]; b=prediction_frames[final_key]
    keys=["prot_id","residue_index","label"]
    m=a[keys+["probability"]].merge(b[keys+["probability"]],on=keys,suffixes=("_esm","_final")); m=m[m.label==1].copy(); e=m.probability_esm.to_numpy()>=threshold; f=m.probability_final.to_numpy()>=threshold
    return {"positive_residues":len(m),"ESM_TP":int(e.sum()),"ESM_FN":int((~e).sum()),"Final_TP":int(f.sum()),"Final_FN":int((~f).sum()),"rescued_ESM_FN":int(((~e)&f).sum()),"lost_ESM_TP":int((e&(~f)).sum()),"net_TP_gain":int(f.sum()-e.sum()),"rescue_rate_of_ESM_FN":float(((~e)&f).sum()/max((~e).sum(),1))}


def dimension_table(store):
    item=next(iter(store.values())); rows=[]
    for k,v in item.items():
        if isinstance(v,np.ndarray) and v.ndim==2: rows.append({"block":k,"dim":v.shape[1]})
    return pd.DataFrame(rows).sort_values("block")


def validate_no_direct_label_features(stores, feature_blocks):
    """Basic runtime audit: finite dimensions and no object identity aliasing with y."""
    rows=[]
    for split,store in stores.items():
        for b in feature_blocks:
            vals=[]; bad=0
            for item in store.values():
                if b not in item: bad+=1; continue
                x=np.asarray(item[b]); vals.append(np.isfinite(x).mean())
            rows.append({"split":split,"block":b,"missing_proteins":bad,"mean_finite_fraction":float(np.mean(vals)) if vals else np.nan})
    return pd.DataFrame(rows)
