"""Relation-aware graph experiments for GEAR Ultimate.

Implements the graph specification used after the maximal-graph ablation:
- 18 edge descriptors combining C-alpha proximity, sequence separation,
  donor-donor geometry, second-shell support, and charge relations.
- rich graph and donor-focused edge filters.
- pure graph predictor.
- residual graph predictor with a learned small correction coefficient alpha.

The clean graph is intentionally small (2 message-passing layers, hidden=128,
edge hidden=32). This follows the empirical lesson that the 453-d maximal node
representation was noisier than compact mechanism-first nodes.
"""
from __future__ import annotations
import gc, json, math, pickle, time
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from scipy.spatial import cKDTree
from sklearn.metrics import average_precision_score
from torch.utils.data import DataLoader, Dataset
from . import gear_core as core
from . import gear_mechanistic as mech

EDGE_FEATURE_NAMES = [
    "ca_distance_norm10","exp_minus_ca_over4","ca_le6","ca_le8",
    "seqsep_norm100","seqsep_eq1","seqsep_le4","seqsep_ge12",
    "src_canonical_donor","dst_canonical_donor","donor_pair",
    "donor_atom_distance_norm6","donor_pair_le6","likely_first_shell_le4p2",
    "donor_polar_second_shell_le4","acid_acid","basic_basic","opposite_charge",
]
assert len(EDGE_FEATURE_NAMES)==18

@dataclass
class GraphConfig:
    hidden: int = 128
    edge_hidden: int = 32
    layers: int = 2
    epochs: int = 25
    patience: int = 5
    lr: float = 2e-4
    weight_decay: float = 1e-4
    proteins_per_batch_gpu: int = 8
    proteins_per_batch_cpu: int = 4
    alpha_init_raw: float = -2.2
    grad_clip: float = 2.0
    seed: int = 42
    cache_version: str = "clean_relation_graph_v2"

CANONICAL = core.ATOM_DONOR_ATOMS
ACID3={"ASP","GLU"}; BASIC3={"LYS","ARG","HIS"}; POLAR3={"SER","THR","TYR","ASN","GLN","HIS","ASP","GLU","CYS"}

def _donor_xyz(res):
    rn=str(res.resname).upper(); out=[]
    for name in CANONICAL.get(rn,[]):
        if name in res: out.append(np.asarray(res[name].coord,np.float32))
    return out

def _hetero_xyz(res):
    out=[]
    for atom in res:
        e=(getattr(atom,"element","") or atom.name[:1]).upper()
        if e in {"O","N","S"}: out.append(np.asarray(atom.coord,np.float32))
    return out

def _mindist(A,B,default=99.0):
    if not A or not B: return default
    a=np.stack(A); b=np.stack(B); return float(np.linalg.norm(a[:,None,:]-b[None,:,:],axis=2).min())

def build_edge_graph(residues):
    """Build directed relation graph with the 18 documented edge attributes."""
    n=len(residues)
    ca=np.stack([np.asarray(r["CA"].coord,np.float32) for r in residues]) if n else np.empty((0,3),np.float32)
    donor=[_donor_xyz(r) for r in residues]; hetero=[_hetero_xyz(r) for r in residues]
    rn=[str(r.resname).upper() for r in residues]; tree=cKDTree(ca) if n else None
    pairs=set()
    if n:
        for i,j in tree.query_pairs(10.0): pairs.add((i,j))
        for i in range(n):
            for off in (1,2):
                j=i+off
                if j<n: pairs.add((i,j))
    edges=[]; attrs=[]
    for i,j in sorted(pairs):
        dca=float(np.linalg.norm(ca[i]-ca[j])); sep=abs(i-j); di=bool(donor[i]); dj=bool(donor[j]); dd=_mindist(donor[i],donor[j]); donor_close=(di and dj and dd<=6.0); first=(di and dj and dd<=4.2)
        # second-shell relation: canonical donor to a polar/hetero neighbor within 4 A.
        s12=(di and rn[j] in POLAR3 and _mindist(donor[i],hetero[j])<=4.0) or (dj and rn[i] in POLAR3 and _mindist(donor[j],hetero[i])<=4.0)
        include=(dca<=8.0 or sep<=2 or donor_close or s12)
        if not include: continue
        for src,dst in ((i,j),(j,i)):
            ds=_mindist(donor[src],donor[dst]); srcd=float(bool(donor[src])); dstd=float(bool(donor[dst])); dp=float(srcd and dstd)
            acid_src=rn[src] in ACID3; acid_dst=rn[dst] in ACID3; bas_src=rn[src] in BASIC3; bas_dst=rn[dst] in BASIC3
            second=(bool(donor[src]) and rn[dst] in POLAR3 and _mindist(donor[src],hetero[dst])<=4.0) or (bool(donor[dst]) and rn[src] in POLAR3 and _mindist(donor[dst],hetero[src])<=4.0)
            a=np.asarray([
                min(dca,10.0)/10.0, math.exp(-dca/4.0), dca<=6.0, dca<=8.0,
                min(sep,100)/100.0, sep==1, sep<=4, sep>=12,
                srcd,dstd,dp,min(ds,6.0)/6.0 if dp else 1.0, dp and ds<=6.0, dp and ds<=4.2,
                second, acid_src and acid_dst, bas_src and bas_dst,
                (acid_src and bas_dst) or (bas_src and acid_dst),
            ],dtype=np.float32)
            edges.append((src,dst)); attrs.append(a)
    if not edges:
        # Always maintain a usable graph for very short proteins.
        for i in range(max(0,n-1)):
            for src,dst in ((i,i+1),(i+1,i)):
                a=np.zeros(18,np.float32); a[0]=min(float(np.linalg.norm(ca[src]-ca[dst])),10)/10; a[1]=math.exp(-float(np.linalg.norm(ca[src]-ca[dst]))/4); a[4]=0.01; a[5]=1; a[6]=1
                edges.append((src,dst)); attrs.append(a)
    ei=np.asarray(edges,dtype=np.int64).T if edges else np.empty((2,0),np.int64); ea=np.stack(attrs).astype(np.float32) if attrs else np.empty((0,18),np.float32)
    return {"edge_index":ei,"edge_attr":ea,"n":n}

def graph_cache_path(base, split, version="clean_relation_graph_v2"):
    return Path(base)/"cache"/version/f"{split}_graph18.pkl"

def ensure_graph_cache(store, split: str, base, version="clean_relation_graph_v2"):
    p=graph_cache_path(base,split,version); p.parent.mkdir(parents=True,exist_ok=True); cache=core.load_pickle(p) if p.exists() else {}; missing=[pid for pid in store if pid not in cache or cache[pid].get("n")!=len(store[pid]["y"])]
    if not missing: print(f"[{split}] Reused graph cache: {p.name}"); return cache
    from tqdm.auto import tqdm
    for pid in tqdm(missing,desc=f"GRAPH {split}"):
        item=store[pid]; pdb=core.resolve_predicted_pdb(Path(base),pid,split); residues=core.parse_protein_residues(pdb,len(item["y"])); n,_=core.validate_feature_alignment(pid,item["sequence"],residues); n=min(n,len(item["y"])); cache[pid]=build_edge_graph(residues[:n])
    core.save_pickle(cache,p); return cache

def ensure_all_graph_caches(stores,base,version="clean_relation_graph_v2"):
    return {k:ensure_graph_cache(stores[k],{"train":"DevSet1010","test300":"TestSet300","test46":"TestSetNew46"}[k],base,version) for k in stores}

def filter_edges(edge_index,edge_attr,mode="rich"):
    if mode=="rich":
        return edge_index,edge_attr
    if mode=="generic":
        # Task-agnostic graph for non-metal binding labels: retain only spatial
        # contact / short sequence edges and explicitly zero metal-donor columns.
        keep=(edge_attr[:,3]>0.5)|(edge_attr[:,5]>0.5)
        ei=edge_index[:,keep]
        ea=edge_attr[keep].copy()
        if len(ea):
            ea[:,8:]=0.0
        return ei,ea
    if mode!="donor":
        raise ValueError(mode)
    # prior donor-focused specification: CA<=6, direct sequence, donor-close,
    # likely coordination, or second-shell support.
    keep=(edge_attr[:,2]>0.5)|(edge_attr[:,5]>0.5)|(edge_attr[:,12]>0.5)|(edge_attr[:,13]>0.5)|(edge_attr[:,14]>0.5)
    return edge_index[:,keep],edge_attr[keep]

class GraphProteinDataset(Dataset):
    def __init__(self,store,graph_cache,ids,blocks,scaler,edge_mode): self.store=store; self.graph=graph_cache; self.ids=list(ids); self.blocks=list(blocks); self.scaler=scaler; self.edge_mode=edge_mode
    def __len__(self): return len(self.ids)
    def __getitem__(self,i):
        pid=self.ids[i]; item=self.store[pid]; X=core.concat_features(item,self.blocks); X=((X-self.scaler["mean"])/self.scaler["std"]).astype(np.float32); y=np.asarray(item["y"],np.int64); g=self.graph[pid]; ei=np.asarray(g["edge_index"],np.int64); ea=np.asarray(g["edge_attr"],np.float32); ei,ea=filter_edges(ei,ea,self.edge_mode); return pid,torch.from_numpy(X),torch.from_numpy(y),torch.from_numpy(ei),torch.from_numpy(ea)

def graph_collate(batch):
    pids=[]; xs=[]; ys=[]; eis=[]; eas=[]; lens=[]; off=0
    for pid,x,y,ei,ea in batch:
        pids.append(pid); xs.append(x); ys.append(y); lens.append(len(y)); eis.append(ei+off); eas.append(ea); off+=len(y)
    return pids,torch.cat(xs).float(),torch.cat(ys).long(),torch.cat(eis,dim=1).long() if eis else torch.empty((2,0),dtype=torch.long),torch.cat(eas).float() if eas else torch.empty((0,18)),lens

class MessageLayer(nn.Module):
    def __init__(self,h,e_dim=18,e_hidden=32):
        super().__init__(); self.edge=nn.Sequential(nn.Linear(e_dim,e_hidden),nn.SiLU(),nn.Linear(e_hidden,e_hidden)); self.msg=nn.Sequential(nn.Linear(h+e_hidden,h),nn.SiLU(),nn.Linear(h,h)); self.gate=nn.Sequential(nn.Linear(h+e_hidden,1)); self.update=nn.Sequential(nn.Linear(2*h,h),nn.SiLU(),nn.Linear(h,h)); self.norm=nn.LayerNorm(h)
    def forward(self,h,ei,ea):
        if ei.numel()==0:return h
        src,dst=ei; e=self.edge(ea); z=torch.cat([h[src],e],dim=1); m=self.msg(z); g=torch.sigmoid(self.gate(z)); agg=torch.zeros_like(h); den=torch.zeros((h.shape[0],1),device=h.device,dtype=h.dtype); agg.index_add_(0,dst,m*g); den.index_add_(0,dst,g); agg=agg/den.clamp_min(1e-6); return self.norm(h+self.update(torch.cat([h,agg],dim=1)))

class PureGraph(nn.Module):
    def __init__(self,d,h=128,e_hidden=32,layers=2): super().__init__(); self.input=nn.Sequential(nn.Linear(d,h),nn.LayerNorm(h),nn.SiLU()); self.layers=nn.ModuleList([MessageLayer(h,18,e_hidden) for _ in range(layers)]); self.head=nn.Sequential(nn.Linear(h,h//2),nn.SiLU(),nn.Linear(h//2,1))
    def forward(self,x,ei,ea):
        h=self.input(x)
        for layer in self.layers:h=layer(h,ei,ea)
        return self.head(h).squeeze(-1)

class ResidualGraph(nn.Module):
    def __init__(self,d,h=128,e_hidden=32,layers=2,alpha_init_raw=-2.2):
        super().__init__(); self.input=nn.Sequential(nn.Linear(d,h),nn.LayerNorm(h),nn.SiLU()); self.layers=nn.ModuleList([MessageLayer(h,18,e_hidden) for _ in range(layers)]); self.local_head=nn.Sequential(nn.Linear(h,h//2),nn.SiLU(),nn.Linear(h//2,1)); self.delta_head=nn.Sequential(nn.Linear(h,h//2),nn.SiLU(),nn.Linear(h//2,1)); self.alpha_raw=nn.Parameter(torch.tensor(float(alpha_init_raw)))
    def forward(self,x,ei,ea):
        h0=self.input(x); h=h0
        for layer in self.layers:h=layer(h,ei,ea)
        local=self.local_head(h0).squeeze(-1); delta=self.delta_head(h-h0).squeeze(-1); return local+torch.sigmoid(self.alpha_raw)*delta
    @property
    def alpha(self): return float(torch.sigmoid(self.alpha_raw.detach()).cpu())

def _predict(model,store,gcache,ids,blocks,scaler,edge_mode,batch_size,device):
    ds=GraphProteinDataset(store,gcache,ids,blocks,scaler,edge_mode); dl=DataLoader(ds,batch_size=batch_size,shuffle=False,collate_fn=graph_collate); Y=[];P=[]; model.eval()
    with torch.inference_mode():
        for _,x,y,ei,ea,_ in dl:
            x=x.to(device); ei=ei.to(device); ea=ea.to(device); logits=model(x,ei,ea); Y.append(y.numpy()); P.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(Y),np.concatenate(P)

def train_graph_fold(store,gcache,tr_ids,va_ids,blocks,architecture,edge_mode,cfg,device,seed):
    core.set_seed(seed); scaler=core.fit_streaming_standardizer(store,tr_ids,blocks); d=sum(np.asarray(store[tr_ids[0]][b]).shape[1] for b in blocks); model=(PureGraph(d,cfg.hidden,cfg.edge_hidden,cfg.layers) if architecture=="pure" else ResidualGraph(d,cfg.hidden,cfg.edge_hidden,cfg.layers,cfg.alpha_init_raw)).to(device); pos=core.class_pos_weight(store,tr_ids); crit=nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos,device=device)); opt=torch.optim.AdamW(model.parameters(),lr=cfg.lr,weight_decay=cfg.weight_decay); bs=cfg.proteins_per_batch_gpu if device.type=="cuda" else cfg.proteins_per_batch_cpu; ds=GraphProteinDataset(store,gcache,tr_ids,blocks,scaler,edge_mode); dl=DataLoader(ds,batch_size=bs,shuffle=True,collate_fn=graph_collate); best=-np.inf; state=None; best_ep=0; patience=0
    for ep in range(1,cfg.epochs+1):
        model.train(); losses=[]
        for _,x,y,ei,ea,_ in dl:
            x=x.to(device); y=y.float().to(device); ei=ei.to(device); ea=ea.to(device); opt.zero_grad(set_to_none=True); logits=model(x,ei,ea); loss=crit(logits,y); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),cfg.grad_clip); opt.step(); losses.append(float(loss.detach().cpu()))
        yv,pv=_predict(model,store,gcache,va_ids,blocks,scaler,edge_mode,bs,device); ap=float(average_precision_score(yv,pv)); a=(model.alpha if hasattr(model,"alpha") else np.nan); print(f"epoch {ep:02d} | loss={np.mean(losses):.4f} | AUPRC={ap:.4f}"+(f" | α={a:.3f}" if np.isfinite(a) else ""))
        if ap>best:
            best=ap; best_ep=ep; state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}; patience=0
        else:
            patience+=1
            if patience>=cfg.patience: break
    model.load_state_dict(state); alpha=(model.alpha if hasattr(model,"alpha") else np.nan); return model,scaler,{"best_val_auprc":best,"best_epoch":best_ep,"alpha":alpha,"n_params":sum(p.numel() for p in model.parameters() if p.requires_grad)}

def run_graph_grid(stores, fold_ids, base, experiments, run_version="clean_noesm_graph_v2_ultimate", cfg=None, device=None, label_column="metal_binding"):
    """Run/resume clean graph experiments and return CV/external DataFrames.

    experiments format:
      {name: {"blocks":[...], "architecture":"pure|residual", "edge_mode":"rich|donor"}}
    """
    cfg=cfg or GraphConfig(); device=device or torch.device("cuda" if torch.cuda.is_available() else "cpu"); g=ensure_all_graph_caches(stores,base,cfg.cache_version); root=Path(base)/"results"/run_version/label_column; pred=root/"fold_predictions"; pred.mkdir(parents=True,exist_ok=True)
    results={}
    for name,exp in experiments.items():
        results[name]=[]; print("\n"+"="*100+"\n"+name)
        for fold in range(5):
            pp=pred/f"{name}__fold{fold+1}.pkl"
            if pp.exists():
                z=pickle.load(open(pp,"rb")); results[name].append(z); print("REUSE",name,fold+1); continue
            tr,va=core.get_fold_train_val_ids(fold,fold_ids,stores["train"]); t0=time.time(); model,scaler,meta=train_graph_fold(stores["train"],g["train"],tr,va,exp["blocks"],exp["architecture"],exp["edge_mode"],cfg,device,cfg.seed+fold); bs=cfg.proteins_per_batch_gpu if device.type=="cuda" else cfg.proteins_per_batch_cpu
            yv,pv=_predict(model,stores["train"],g["train"],va,exp["blocks"],scaler,exp["edge_mode"],bs,device); y300,p300=_predict(model,stores["test300"],g["test300"],list(stores["test300"]),exp["blocks"],scaler,exp["edge_mode"],bs,device); y46,p46=_predict(model,stores["test46"],g["test46"],list(stores["test46"]),exp["blocks"],scaler,exp["edge_mode"],bs,device); z={"name":name,"fold":fold+1,"blocks":exp["blocks"],"architecture":exp["architecture"],"edge_mode":exp["edge_mode"],"val_y":yv,"val_p":pv,"test300_y":y300,"test300_p":p300,"test46_y":y46,"test46_p":p46,"meta":meta,"seconds":time.time()-t0}; pickle.dump(z,open(pp,"wb"),protocol=pickle.HIGHEST_PROTOCOL); results[name].append(z); del model,scaler; gc.collect(); print(f"DONE | best={meta['best_val_auprc']:.4f} | epoch={meta['best_epoch']} | α={meta['alpha']}")
    cv=[]; ext=[]
    for name,folds in results.items():
        aps=[core.binary_metrics(z["val_y"],z["val_p"],.5)["auprc"] for z in folds]; oofy=np.concatenate([z["val_y"] for z in folds]); oofp=np.concatenate([z["val_p"] for z in folds]); th=core.choose_f1_threshold(oofy,oofp); cv.append({"representation":name,"CV_AUPRC":np.mean(aps),"CV_AUPRC_SD":np.std(aps,ddof=1),"fold_AUPRC":json.dumps(aps),"OOF_threshold":th,"mean_alpha":np.nanmean([z["meta"].get("alpha",np.nan) for z in folds])})
        for ds,yk,pk in (("TestSet300","test300_y","test300_p"),("TestSetNew46","test46_y","test46_p")):
            y=folds[0][yk]; p=np.mean(np.stack([z[pk] for z in folds]),axis=0); m=core.binary_metrics(y,p,.5); mt=core.binary_metrics(y,p,th); ext.append({"representation":name,"dataset":ds,"AUPRC":m["auprc"],"AUROC":m["auroc"],"F1@0.5":m["f1"],"MCC@0.5":m["mcc"],"OOF_threshold":th,"F1@OOF":mt["f1"],"MCC@OOF":mt["mcc"]})
    cvdf=pd.DataFrame(cv).sort_values("CV_AUPRC",ascending=False); extdf=pd.DataFrame(ext); cvdf.to_csv(root/"cv_summary.csv",index=False); extdf.to_csv(root/"external_summary.csv",index=False); return cvdf,extdf

CLEAN_GRAPH_EXPERIMENTS = {
    "PureGraph_AA_Chem":{"blocks":["AA","CHEM"],"architecture":"pure","edge_mode":"rich"},
    "PureGraph_AA_Atomic_Chem":{"blocks":["AA","ATOM","CHEM"],"architecture":"pure","edge_mode":"rich"},
    "ResidualGraph_AA_Atomic_Chem":{"blocks":["AA","ATOM","CHEM"],"architecture":"residual","edge_mode":"rich"},
    "ResidualGraph_Compact":{"blocks":["AA","ATOM","CHEM","METALSPEC","ELEC3D","TOPO","SOLV","SEQMOTIF"],"architecture":"residual","edge_mode":"rich"},
    "ResidualGraph_DonorFocused":{"blocks":["AA","ATOM","CHEM"],"architecture":"residual","edge_mode":"donor"},
}

MAXIMAL_NO_ESM_BLOCKS = [
    "AA","SEQCTX","SPATIAL","LOCAL","ATOM","CHEM",
    "ACCESS","SHELL2","ENV","CONF",
    "METALSPEC","ELEC3D","TOPO","SOLV","SEQMOTIF",
]
MAXIMAL_GRAPH_EXPERIMENT = {
    "MaximalNoESMGraph": {"blocks": MAXIMAL_NO_ESM_BLOCKS, "architecture":"pure", "edge_mode":"rich"}
}

def maximal_graph_config():
    """Architecture used by the archival maximal no-ESM graph diagnostic."""
    return GraphConfig(hidden=160, edge_hidden=48, layers=3, epochs=25, patience=5, lr=2e-4, weight_decay=1e-4, cache_version="clean_relation_graph_v2")


GENERIC_BINDING_GRAPH_EXPERIMENTS = {
    "PureGraph_AA": {"blocks":["AA"], "architecture":"pure", "edge_mode":"generic"},
    "PureGraph_AA_Structure": {"blocks":["AA","SPATIAL","LOCAL"], "architecture":"pure", "edge_mode":"generic"},
    "ResidualGraph_AA_Structure": {"blocks":["AA","SPATIAL","LOCAL"], "architecture":"residual", "edge_mode":"generic"},
}

def generic_evo_graph_experiments():
    return {
        "PureGraph_AA_EVO": {"blocks":["AA","EVO"], "architecture":"pure", "edge_mode":"generic"},
        "ResidualGraph_AA_Structure_EVO": {"blocks":["AA","SPATIAL","LOCAL","EVO"], "architecture":"residual", "edge_mode":"generic"},
    }
