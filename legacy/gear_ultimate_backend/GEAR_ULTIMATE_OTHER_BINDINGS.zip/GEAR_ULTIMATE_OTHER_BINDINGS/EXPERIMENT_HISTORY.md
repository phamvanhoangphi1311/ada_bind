# Experiment plan — Remaining binding labels

No performance numbers are pre-filled for the four tasks in this bundle. The existing `metal_binding` results are not transferable as measured results.

## Labels

- binding_sites
- any_ligand_binding_sites
- small_binding
- nuclear_binding

## Primary grid

For each label, run official 5-fold Dev CV for:

- AA
- AA + Structure
- ESM
- ESM + Structure

Models: MLP, KAN, XGBoost as needed.

## Evolutionary grid

- AA + EVO
- AA + Structure + EVO
- ESM
- ESM + EVO
- ESM + Structure
- ESM + Structure + EVO

The same MSA/EVO cache is reused across all labels.

## Generic graph grid

- PureGraph AA
- PureGraph AA + Structure
- ResidualGraph AA + Structure

Generic graph mode retains only spatial contact / direct sequence edges and zeros metal-donor-specific edge columns.

## Optional specificity controls

The metal-inspired families can be run against the other labels to test task specificity:

- ATOM15
- CHEM24
- MECH1
- MULTI2
- donor-focused graph

These are not primary mechanistic descriptors for the non-metal labels.
