# GEAR Ultimate — Other Binding Labels

Companion bundle for the four bindNode24 residue-level label columns other than `metal_binding`:

- `binding_sites`
- `any_ligand_binding_sites`
- `small_binding`
- `nuclear_binding`

## Install location

Extract this folder to:

```text
/content/drive/MyDrive/Protein-binding/GEAR_ULTIMATE_OTHER_BINDINGS/
```

Open:

```text
GEAR_ULTIMATE_OTHER_BINDINGS.ipynb
```

The notebook reuses the existing data, ESMFold PDBs, structure/ESM caches, ATOM/CHEM caches, graph cache, and `cache/evolution_v1/` MSA/EVO cache. It does not require copying those caches into this folder.

## Why this is not a blind copy of the metal notebook

The metal notebook developed `ATOM`, `CHEM`, `MULTI2`, and donor-focused graph relations specifically around coordination chemistry. Reusing them as the primary representation for the other labels would overstate their biological scope. Therefore this bundle has two explicit tracks:

1. **Primary generic track**
   - AA
   - AA + Structure
   - ESM
   - ESM + Structure
   - EVO48
   - generic contact/sequence graph

2. **Optional specificity / transfer controls**
   - ATOM / CHEM / MULTI2
   - the full standardized 13-representation grid
   - donor/metal graph variants

A positive transfer result is interesting, but should be reported as cross-task generalization of a metal-inspired representation rather than a task-specific mechanistic model.

## Main convenience

The notebook prepares label-independent features once, then uses `clone_context_for_label()` to swap only the residue label vector for each task. Thus the four tasks share expensive caches and can be run independently or together.

Example:

```python
ACTIVE_LABELS = ('small_binding',)
RUN_GENERIC_CORE = True
```

Or all four:

```python
ACTIVE_LABELS = tuple(suite.OTHER_BINDING_LABELS)
RUN_GENERIC_CORE = True
```

## Output layout

Each label is isolated under the same run version:

```text
/content/drive/MyDrive/Protein-binding/results/<run_version>/<label>/
```

Examples:

```text
results/ultimate_other_generic_core_v1/small_binding/
results/ultimate_other_generic_core_v1/nuclear_binding/
```

This prevents collision with the existing `metal_binding` results.

## Recommended execution order

1. `RUN_GENERIC_CORE = True` with MLP first.
2. Add KAN/XGBoost only after the data/context audit passes.
3. Test EVO48 on Dev CV. MSA generation is label-independent and shared.
4. Run the generic graph if it answers a useful relational question.
5. Only then use the metal-specific transfer branches as specificity controls.
6. Choose models/features from Dev CV; keep Test300/Test46 for confirmation.

## Important reproducibility notes

- Official bindNode24 protein-level 5-fold splits are retained.
- OOF threshold selection is Dev-only.
- Test300/Test46 are not used for threshold selection.
- Structures are ESMFold-derived unless replaced.
- `metal_binding` historical numerical results are **not** copied as results for these four tasks; these tasks must be rerun.
- Current graph implementation is a specification-faithful reconstruction of the earlier clean graph branch, with a new generic edge mode that zeroes donor/coordination columns for non-metal tasks.
