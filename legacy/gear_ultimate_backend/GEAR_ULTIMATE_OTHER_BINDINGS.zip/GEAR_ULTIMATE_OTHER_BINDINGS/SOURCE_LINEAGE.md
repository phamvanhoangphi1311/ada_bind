# Source lineage — Other Binding bundle

This bundle is derived from the validated `GEAR_ULTIMATE` metal-binding bundle and the same recovered project sources.

## Source-faithful components

- `gear_core.py`: standardized data loading, official folds, MLP/KAN/XGBoost training, metrics, ATOM15, CHEM24.
- `gear_structure.py`: ESM2 residue embeddings and SPATIAL/LOCAL structure features.
- `gear_mechanistic.py`: MECH1, MULTI2, SEQCTX feature extractors.
- `gear_legacy.py`: historical original KAN architecture and historical smoothness protocol.
- `gear_evolution.py`: resumable ColabFold/MMseqs2 MSA and EVO48 extraction.

## Changes made specifically for the four remaining labels

- `gear_suite.prepare_context()` now accepts `label_column`.
- `clone_context_for_label()` reuses all label-independent arrays while swapping only `y`.
- output directories are label-specific.
- graph runner accepts `label_column`.
- a `generic` graph edge mode retains generic spatial/sequence relations and zeros donor/coordination edge columns.
- primary grids exclude metal-specific descriptors; those are retained only as optional transfer/specificity controls.

## Graph caveat

As in the metal bundle, the clean graph branch is a specification-faithful reconstruction rather than a byte-for-byte recovery of the original experimental cell. All non-metal graph runs therefore use new run-version namespaces.
