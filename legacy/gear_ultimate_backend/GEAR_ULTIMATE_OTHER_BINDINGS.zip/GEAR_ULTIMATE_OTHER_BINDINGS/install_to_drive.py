#!/usr/bin/env python3
"""Copy the GEAR_ULTIMATE_OTHER_BINDINGS bundle to a Google Drive project folder.

Typical Colab use after uploading/extracting the bundle under /content:
    !python /content/GEAR_ULTIMATE_OTHER_BINDINGS/install_to_drive.py

The script is copy-only: it does not modify data/caches/results outside the
GEAR_ULTIMATE code directory.
"""
from __future__ import annotations
import argparse
import shutil
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default=str(Path(__file__).resolve().parent))
    ap.add_argument("--project-root", default="/content/drive/MyDrive/Protein-binding")
    ap.add_argument("--name", default="GEAR_ULTIMATE_OTHER_BINDINGS")
    ap.add_argument("--overwrite", action="store_true", help="replace existing files with same names")
    args = ap.parse_args()

    src = Path(args.source).resolve()
    dst = Path(args.project_root).expanduser().resolve() / args.name
    if not src.exists():
        raise FileNotFoundError(src)
    dst.mkdir(parents=True, exist_ok=True)

    skip = {"__pycache__", ".git", ".ipynb_checkpoints"}
    copied = 0
    for p in src.rglob("*"):
        if any(part in skip for part in p.parts):
            continue
        rel = p.relative_to(src)
        q = dst / rel
        if p.is_dir():
            q.mkdir(parents=True, exist_ok=True)
            continue
        q.parent.mkdir(parents=True, exist_ok=True)
        if q.exists() and not args.overwrite:
            # Preserve any Drive-edited version unless explicit overwrite.
            continue
        shutil.copy2(p, q)
        copied += 1

    print(f"Source:      {src}")
    print(f"Destination: {dst}")
    print(f"Copied files: {copied}")
    print("Done. Add destination to sys.path or open the notebook from that folder.")


if __name__ == "__main__":
    main()
