# Source lineage and reconstruction status

The Ultimate bundle was assembled from the experiment artifacts recovered from the project history rather than rewritten from memory alone.

## Source-faithful consolidations

- `gear_core.py` — consolidated from `gear_standardized_experiments.py` and the standardized chemistry notebook. It preserves the standardized MLP/KAN/XGBoost protocol, ATOM15/CHEM24 definitions, protein-fold handling, training-fold scaling, OOF thresholding and external ensemble reporting.
- `gear_structure.py` — consolidated from the patched spatial-revamp notebook: ESM-2 mean-last-two 1280-d embeddings, SPATIAL112, LOCAL8 and cache conventions.
- `gear_mechanistic.py` — consolidated from the MECH1 and merged MULTI2 experiment cells. It preserves ACCESS, SHELL2, ENV, CONF, METALSPEC, ELEC3D, TOPO, SOLV, SEQMOTIF and SEQCTX definitions used in the experiment lineage.
- `gear_legacy.py` — archival reimplementation of the historical original KAN protocol from the original base notebook, including the label-aware spatial smoothness training term.
- `gear_evolution.py` — modularization of the EVO48 / ColabFold MSA workflow developed in the later experiment stage.

## Specification-faithful reconstruction

- `gear_graph.py` — reconstructed from the frozen maximal/clean graph specification and observed run logs. It implements the documented 18 edge attributes, rich/donor edge modes, pure/residual graph heads, small learned residual alpha, maximal node block and clean experiment grid. The exact original clean-graph one-cell source was not recovered as a standalone source artifact, therefore new graph runs intentionally use new run-version names and should not be expected to generate byte-identical historical checkpoints.

## Historical results

`EXPERIMENT_HISTORY.md` stores observed historical metrics only as a reference/sanity-check layer. The notebook does not substitute those values for reruns.

## Reproducibility rule

When a new result is intended for a manuscript claim, use the generated run directory and its prediction/metric artifacts as the authoritative source. Historical reference tables are descriptive provenance only.
