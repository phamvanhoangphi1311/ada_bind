
"""Mechanism-first feature blocks used in the GEAR metal-binding study.

This module is reconstructed from the exact MECH1 and MULTI2 extraction code
used in the experiment lineage. Feature extraction is label-independent.
"""
from __future__ import annotations
import math
from pathlib import Path
from itertools import combinations
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from tqdm.auto import tqdm
from . import gear_core as core


ACCESS_NAMES = [

    "other_heavy_count_3A",

    "other_heavy_count_4A",

    "other_heavy_count_6A",

    "other_heavy_count_8A",

    "nearest_other_heavy_A",

    "other_residue_count_6A",

    "other_residue_count_8A",

    "open_octant_fraction_6A",

    "directional_anisotropy_6A",

    "relative_surface_radius",
]


SHELL2_NAMES = [

    "focal_primary_donor_count",

    "support_hetero_atoms_3p5A",

    "support_residues_3p5A",

    "support_hetero_atoms_4A",

    "support_residues_4A",

    "primary_donor_support_fraction",

    "min_support_distance_A",

    "mean_support_distance_A",

    "acidic_support_residues_4A",

    "basic_support_residues_4A",

    "polar_support_residues_4A",

    "backbone_support_atoms_3p5A",
]


ENV_NAMES = [

    "neighbor_residues_6A",

    "hydrophobic_fraction_6A",

    "polar_fraction_6A",

    "aromatic_fraction_6A",

    "acidic_fraction_6A",

    "basic_fraction_6A",

    "mean_hydropathy_6A",

    "hydropathy_std_6A",
]


CONF_NAMES = [

    "focal_plddt",

    "local6A_plddt_mean",

    "local6A_plddt_std",

    "local_donor_plddt_mean",
]


PRIMARY_DONORS = (
    core.ATOM_DONOR_ATOMS
)


HYDROPATHY = {

    "A": 1.8,

    "C": 2.5,

    "D": -3.5,

    "E": -3.5,

    "F": 2.8,

    "G": -0.4,

    "H": -3.2,

    "I": 4.5,

    "K": -3.9,

    "L": 3.8,

    "M": 1.9,

    "N": -3.5,

    "P": -1.6,

    "Q": -3.5,

    "R": -4.5,

    "S": -0.8,

    "T": -0.7,

    "V": 4.2,

    "W": -0.9,

    "Y": -1.3,
}


HYDROPHOBIC = set(
    "AVILMFWC"
)


POLAR = set(
    "STNQYC"
)


AROMATIC = set(
    "FWYH"
)


ACIDIC = set(
    "DE"
)


BASIC = set(
    "KRH"
)


POLAR_SUPPORT_AA = {

    "SER",

    "THR",

    "TYR",

    "ASN",

    "GLN",
}


ACIDIC_RES = {

    "ASP",

    "GLU",
}


BASIC_RES = {

    "LYS",

    "ARG",

    "HIS",
}


def residue_anchor(
    res
):

    """
    Prefer canonical metal-donor atoms.

    Otherwise use CB,
    glycine/fallback uses CA.
    """

    resname = str(
        res.resname
    ).upper()


    donor_names = (
        PRIMARY_DONORS.get(
            resname,
            [],
        )
    )


    donor_xyz = [

        np.asarray(
            res[n].coord,
            np.float32,
        )

        for n
        in donor_names

        if n in res
    ]


    if donor_xyz:

        return np.mean(

            np.stack(
                donor_xyz
            ),

            axis=0

        ).astype(
            np.float32
        )


    if "CB" in res:

        return np.asarray(
            res["CB"].coord,
            np.float32,
        )


    return np.asarray(
        res["CA"].coord,
        np.float32,
    )


def residue_plddt(
    res
):

    if "CA" not in res:

        return 0.0


    return float(

        np.clip(

            float(
                res["CA"].bfactor
            ),

            0.0,

            100.0,
        )
    )


def extract_mechanistic_features(
    residues
):

    n = len(
        residues
    )


    ACCESS = np.zeros(
        (
            n,
            len(
                ACCESS_NAMES
            ),
        ),
        np.float32,
    )


    SHELL2 = np.zeros(
        (
            n,
            len(
                SHELL2_NAMES
            ),
        ),
        np.float32,
    )


    ENV = np.zeros(
        (
            n,
            len(
                ENV_NAMES
            ),
        ),
        np.float32,
    )


    CONF = np.zeros(
        (
            n,
            len(
                CONF_NAMES
            ),
        ),
        np.float32,
    )


    anchors = np.stack(
        [
            residue_anchor(
                r
            )

            for r
            in residues
        ]
    ).astype(
        np.float32
    )


    ca = np.stack(
        [
            np.asarray(
                r["CA"].coord,
                np.float32,
            )

            for r
            in residues
        ]
    )


    aa = [

        core.safe_seq1(
            r.resname
        )

        for r
        in residues
    ]


    resnames = [

        str(
            r.resname
        ).upper()

        for r
        in residues
    ]


    plddt = np.asarray(
        [
            residue_plddt(
                r
            )

            for r
            in residues
        ],
        np.float32,
    )


    ca_tree = cKDTree(
        ca
    )


    protein_center = (
        ca.mean(
            axis=0
        )
    )


    radial = np.linalg.norm(

        ca
        -
        protein_center,

        axis=1,
    )


    radial_scale = float(

        np.percentile(
            radial,
            95
        )
    )


    radial_scale = max(
        radial_scale,
        1e-6,
    )


    # --------------------------------------------------------
    # Build atom pools
    # --------------------------------------------------------

    heavy_xyz = []

    heavy_res = []


    support_xyz = []

    support_res = []

    support_backbone = []


    primary_xyz = []

    primary_res = []


    for ri, res in enumerate(
        residues
    ):

        rname = (
            resnames[
                ri
            ]
        )


        canonical = set(

            PRIMARY_DONORS.get(
                rname,
                [],
            )
        )


        for atom in res:

            elem = str(
                atom.element
            ).upper()


            if elem == "H":

                continue


            xyz = np.asarray(
                atom.coord,
                np.float32,
            )


            name = str(
                atom.name
            )


            heavy_xyz.append(
                xyz
            )

            heavy_res.append(
                ri
            )


            # canonical first-shell donor
            if name in canonical:

                primary_xyz.append(
                    xyz
                )

                primary_res.append(
                    ri
                )


            # potential second-shell polar support
            #
            # Exclude canonical donor itself to reduce
            # redundancy with ATOM.
            if (
                elem
                in {
                    "N",
                    "O",
                    "S",
                }
                and
                name
                not in canonical
            ):

                support_xyz.append(
                    xyz
                )

                support_res.append(
                    ri
                )

                support_backbone.append(
                    name
                    in {
                        "N",
                        "O",
                        "OXT",
                    }
                )


    heavy_xyz = np.asarray(
        heavy_xyz,
        np.float32,
    )

    heavy_res = np.asarray(
        heavy_res,
        np.int32,
    )


    heavy_tree = (

        cKDTree(
            heavy_xyz
        )

        if len(
            heavy_xyz
        )

        else None
    )


    support_xyz = np.asarray(
        support_xyz,
        np.float32,
    )

    support_res = np.asarray(
        support_res,
        np.int32,
    )

    support_backbone = np.asarray(
        support_backbone,
        bool,
    )


    support_tree = (

        cKDTree(
            support_xyz
        )

        if len(
            support_xyz
        )

        else None
    )


    primary_xyz = np.asarray(
        primary_xyz,
        np.float32,
    )

    primary_res = np.asarray(
        primary_res,
        np.int32,
    )


    primary_tree = (

        cKDTree(
            primary_xyz
        )

        if len(
            primary_xyz
        )

        else None
    )


    # ========================================================
    # PER RESIDUE
    # ========================================================

    for i in range(
        n
    ):

        anchor = (
            anchors[
                i
            ]
        )


        # ====================================================
        # ACCESSIBILITY / PACKING
        # ====================================================

        if heavy_tree is not None:

            idx = (
                heavy_tree
                .query_ball_point(
                    anchor,
                    r=8.0,
                )
            )


            idx = [

                j

                for j
                in idx

                if heavy_res[
                    j
                ]
                != i
            ]


        else:

            idx = []


        coords = (

            heavy_xyz[
                idx
            ]

            if len(
                idx
            )

            else np.empty(
                (
                    0,
                    3,
                ),
                np.float32,
            )
        )


        rids = (

            heavy_res[
                idx
            ]

            if len(
                idx
            )

            else np.empty(
                0,
                np.int32,
            )
        )


        d = (

            np.linalg.norm(

                coords
                -
                anchor,

                axis=1,
            )

            if len(
                coords
            )

            else np.empty(
                0,
                np.float32,
            )
        )


        for col, radius in enumerate(
            [
                3.0,
                4.0,
                6.0,
                8.0,
            ]
        ):

            ACCESS[
                i,
                col
            ] = float(
                np.sum(
                    d
                    <=
                    radius
                )
            )


        ACCESS[
            i,
            4
        ] = (

            float(
                d.min()
            )

            if len(
                d
            )

            else 8.0
        )


        ACCESS[
            i,
            5
        ] = float(
            len(
                set(
                    rids[
                        d <= 6.0
                    ].tolist()
                )
            )
        )


        ACCESS[
            i,
            6
        ] = float(
            len(
                set(
                    rids[
                        d <= 8.0
                    ].tolist()
                )
            )
        )


        near = (

            coords[
                d <= 6.0
            ]

            if len(
                d
            )

            else np.empty(
                (
                    0,
                    3,
                ),
                np.float32,
            )
        )


        if len(
            near
        ):

            v = (
                near
                -
                anchor
            )


            octants = (

                (
                    v[:, 0]
                    >=
                    0
                ).astype(
                    int
                )
                *
                4

                +

                (
                    v[:, 1]
                    >=
                    0
                ).astype(
                    int
                )
                *
                2

                +

                (
                    v[:, 2]
                    >=
                    0
                ).astype(
                    int
                )
            )


            ACCESS[
                i,
                7
            ] = (
                1.0
                -
                len(
                    np.unique(
                        octants
                    )
                )
                /
                8.0
            )


            norms = np.linalg.norm(

                v,

                axis=1,

                keepdims=True,
            )


            unit = (

                v
                /
                np.maximum(
                    norms,
                    1e-6,
                )
            )


            if len(
                unit
            ) >= 3:

                cov = np.cov(
                    unit.T,
                    bias=True,
                )


                eig = np.sort(

                    np.maximum(

                        np.linalg.eigvalsh(
                            cov
                        ),

                        0.0,
                    )
                )


                ACCESS[
                    i,
                    8
                ] = float(

                    eig[
                        -1
                    ]

                    /

                    max(
                        eig.sum(),
                        1e-8,
                    )
                )


        else:

            ACCESS[
                i,
                7
            ] = 1.0

            ACCESS[
                i,
                8
            ] = 1.0


        ACCESS[
            i,
            9
        ] = float(

            np.clip(

                radial[
                    i
                ]

                /

                radial_scale,

                0.0,

                2.0,
            )
        )


        # ====================================================
        # ENVIRONMENT
        # ====================================================

        nbr = [

            j

            for j
            in ca_tree.query_ball_point(
                ca[
                    i
                ],
                r=6.0,
            )

            if j != i
        ]


        ENV[
            i,
            0
        ] = len(
            nbr
        )


        if nbr:

            aas = [

                aa[
                    j
                ]

                for j
                in nbr
            ]


            denom = float(
                len(
                    aas
                )
            )


            ENV[
                i,
                1
            ] = (
                sum(
                    a in HYDROPHOBIC
                    for a in aas
                )
                /
                denom
            )


            ENV[
                i,
                2
            ] = (
                sum(
                    a in POLAR
                    for a in aas
                )
                /
                denom
            )


            ENV[
                i,
                3
            ] = (
                sum(
                    a in AROMATIC
                    for a in aas
                )
                /
                denom
            )


            ENV[
                i,
                4
            ] = (
                sum(
                    a in ACIDIC
                    for a in aas
                )
                /
                denom
            )


            ENV[
                i,
                5
            ] = (
                sum(
                    a in BASIC
                    for a in aas
                )
                /
                denom
            )


            hyd = np.asarray(
                [
                    HYDROPATHY.get(
                        a,
                        0.0,
                    )

                    for a
                    in aas
                ],
                np.float32,
            )


            ENV[
                i,
                6
            ] = float(
                hyd.mean()
            )

            ENV[
                i,
                7
            ] = float(
                hyd.std()
            )


        # ====================================================
        # CONFIDENCE
        # ====================================================

        local = (
            ca_tree
            .query_ball_point(
                ca[
                    i
                ],
                r=6.0,
            )
        )


        CONF[
            i,
            0
        ] = (
            plddt[
                i
            ]
            /
            100.0
        )


        if local:

            vals = (

                plddt[
                    local
                ]
                /
                100.0
            )


            CONF[
                i,
                1
            ] = float(
                vals.mean()
            )


            CONF[
                i,
                2
            ] = float(
                vals.std()
            )


        if primary_tree is not None:

            pidx = (
                primary_tree
                .query_ball_point(
                    anchor,
                    r=6.0,
                )
            )


            if pidx:

                donor_res = np.unique(

                    primary_res[
                        pidx
                    ]
                )


                CONF[
                    i,
                    3
                ] = float(

                    (
                        plddt[
                            donor_res
                        ]
                        /
                        100.0
                    ).mean()
                )


            else:

                CONF[
                    i,
                    3
                ] = CONF[
                    i,
                    1
                ]


        else:

            CONF[
                i,
                3
            ] = CONF[
                i,
                1
            ]


        # ====================================================
        # SECOND COORDINATION SHELL
        # ====================================================

        focal_donors = []


        focal_res = (
            residues[
                i
            ]
        )


        for atom_name in PRIMARY_DONORS.get(
            resnames[
                i
            ],
            [],
        ):

            if atom_name in focal_res:

                focal_donors.append(

                    np.asarray(
                        focal_res[
                            atom_name
                        ].coord,
                        np.float32,
                    )
                )


        SHELL2[
            i,
            0
        ] = len(
            focal_donors
        )


        if (
            not focal_donors
            or
            support_tree is None
        ):

            SHELL2[
                i,
                6
            ] = 6.0

            SHELL2[
                i,
                7
            ] = 6.0

            continue


        support35 = set()

        support40 = set()

        support_res35 = set()

        support_res40 = set()

        support_dist = []

        supported_focal = 0

        backbone35 = set()


        for fd in focal_donors:

            idx35 = [

                j

                for j
                in support_tree.query_ball_point(
                    fd,
                    r=3.5,
                )

                if support_res[
                    j
                ] != i
            ]


            idx40 = [

                j

                for j
                in support_tree.query_ball_point(
                    fd,
                    r=4.0,
                )

                if support_res[
                    j
                ] != i
            ]


            if idx35:

                supported_focal += 1


            for j in idx35:

                support35.add(
                    int(
                        j
                    )
                )


                support_res35.add(
                    int(
                        support_res[
                            j
                        ]
                    )
                )


                support_dist.append(

                    float(

                        np.linalg.norm(

                            support_xyz[
                                j
                            ]

                            -
                            fd
                        )
                    )
                )


                if support_backbone[
                    j
                ]:

                    backbone35.add(
                        int(
                            j
                        )
                    )


            for j in idx40:

                support40.add(
                    int(
                        j
                    )
                )


                support_res40.add(
                    int(
                        support_res[
                            j
                        ]
                    )
                )


        SHELL2[
            i,
            1
        ] = len(
            support35
        )


        SHELL2[
            i,
            2
        ] = len(
            support_res35
        )


        SHELL2[
            i,
            3
        ] = len(
            support40
        )


        SHELL2[
            i,
            4
        ] = len(
            support_res40
        )


        SHELL2[
            i,
            5
        ] = (
            supported_focal
            /
            max(
                len(
                    focal_donors
                ),
                1,
            )
        )


        SHELL2[
            i,
            6
        ] = (

            min(
                support_dist
            )

            if support_dist

            else 6.0
        )


        SHELL2[
            i,
            7
        ] = (

            float(
                np.mean(
                    support_dist
                )
            )

            if support_dist

            else 6.0
        )


        SHELL2[
            i,
            8
        ] = sum(

            resnames[
                j
            ]
            in ACIDIC_RES

            for j
            in support_res40
        )


        SHELL2[
            i,
            9
        ] = sum(

            resnames[
                j
            ]
            in BASIC_RES

            for j
            in support_res40
        )


        SHELL2[
            i,
            10
        ] = sum(

            resnames[
                j
            ]
            in POLAR_SUPPORT_AA

            for j
            in support_res40
        )


        SHELL2[
            i,
            11
        ] = len(
            backbone35
        )


    return {

        "ACCESS":
            ACCESS,

        "SHELL2":
            SHELL2,

        "ENV":
            ENV,

        "CONF":
            CONF,
    }


METALS = [
    "Zn",
    "Mg",
    "Ca",
    "Mn",
    "Fe",
    "Cu",
]


METALSPEC_NAMES = [f"{m}_{suffix}" for m in METALS for suffix in ("distance_fit", "coordination_fit", "donor_type_fit")]


ELEC3D_NAMES = [
    "net_charge_8A",
    "field_magnitude_8A",
    "field_radial_component_8A",
    "dipole_magnitude_8A",
    "positive_negative_centroid_distance",
    "charge_anisotropy_8A",
    "net_charge_12A",
    "field_magnitude_12A",
]


TOPO_NAMES = [
    "donor_residue_count_8A",
    "donor_type_diversity",
    "donor_graph_edges",
    "donor_graph_density",
    "largest_component_fraction",
    "donor_triangles",
    "longrange_donor_count",
    "mean_sequence_separation",
    "max_sequence_separation",
    "donor_radius_of_gyration",
    "min_donor_pair_distance",
    "mean_donor_pair_distance",
]


SOLV_NAMES = [
    "polar_atoms_3A",
    "polar_atoms_4A",
    "polar_atoms_6A",
    "polar_fraction_4A",
    "polar_fraction_6A",
    "nonpolar_heavy_atoms_4A",
    "polar_shell_4_6_ratio",
    "local_void_proxy",
    "buried_polar_proxy",
    "polar_anisotropy_6A",
]


SEQMOTIF_NAMES = [
    "donor_fraction_w2",
    "donor_fraction_w4",
    "donor_fraction_w8",
    "donor_fraction_w16",
    "acidic_fraction_w4",
    "acidic_fraction_w8",
    "acidic_fraction_w16",
    "donor_type_diversity_w8",
    "donor_type_diversity_w16",
    "longrange_sequence_donor_density",
]


CANONICAL_DONORS = {
    "CYS": {
        "SG": "S",
    },
    "HIS": {
        "ND1": "N",
        "NE2": "N",
    },
    "ASP": {
        "OD1": "O",
        "OD2": "O",
    },
    "GLU": {
        "OE1": "O",
        "OE2": "O",
    },
}


BROAD_DONORS = {
    "CYS": {
        "SG": "S",
    },
    "HIS": {
        "ND1": "N",
        "NE2": "N",
    },
    "ASP": {
        "OD1": "O",
        "OD2": "O",
    },
    "GLU": {
        "OE1": "O",
        "OE2": "O",
    },
    "SER": {
        "OG": "O",
    },
    "THR": {
        "OG1": "O",
    },
    "TYR": {
        "OH": "O",
    },
    "ASN": {
        "OD1": "O",
    },
    "GLN": {
        "OE1": "O",
    },
    "MET": {
        "SD": "S",
    },
}


DONOR_AA = set(
    "HCDE"
)


METAL_PROTO = {

    "Zn": {
        "r0": 2.10,
        "coord": 4.0,
        "weights": {
            "O": 0.85,
            "N": 1.00,
            "S": 1.00,
        },
    },

    "Mg": {
        "r0": 2.10,
        "coord": 6.0,
        "weights": {
            "O": 1.00,
            "N": 0.35,
            "S": 0.10,
        },
    },

    "Ca": {
        "r0": 2.40,
        "coord": 7.0,
        "weights": {
            "O": 1.00,
            "N": 0.25,
            "S": 0.10,
        },
    },

    "Mn": {
        "r0": 2.20,
        "coord": 6.0,
        "weights": {
            "O": 1.00,
            "N": 0.60,
            "S": 0.25,
        },
    },

    "Fe": {
        "r0": 2.15,
        "coord": 6.0,
        "weights": {
            "O": 0.90,
            "N": 0.85,
            "S": 0.60,
        },
    },

    "Cu": {
        "r0": 2.05,
        "coord": 4.0,
        "weights": {
            "O": 0.65,
            "N": 1.00,
            "S": 0.95,
        },
    },
}


def safe_anchor(res):

    rn = str(
        res.resname
    ).upper()

    candidates = []

    for atom_name in CANONICAL_DONORS.get(
        rn,
        {}
    ):

        if atom_name in res:

            candidates.append(
                np.asarray(
                    res[atom_name].coord,
                    np.float32
                )
            )

    if candidates:

        return np.mean(
            np.stack(
                candidates
            ),
            axis=0
        )

    if "CB" in res:

        return np.asarray(
            res["CB"].coord,
            np.float32
        )

    return np.asarray(
        res["CA"].coord,
        np.float32
    )


def sphere_pair_centers(
    a,
    b,
    r=2.10,
    samples=12,
):

    a = np.asarray(
        a,
        float
    )

    b = np.asarray(
        b,
        float
    )

    v = b - a

    d = np.linalg.norm(
        v
    )

    if (
        d < 1e-6
        or
        d > 2 * r
    ):
        return np.empty(
            (0, 3),
            np.float32
        )

    u = v / d

    helper = np.array(
        [1., 0., 0.]
    )

    if abs(
        u @ helper
    ) > 0.9:

        helper = np.array(
            [0., 1., 0.]
        )

    e1 = np.cross(
        u,
        helper
    )

    e1 /= max(
        np.linalg.norm(
            e1
        ),
        1e-8
    )

    e2 = np.cross(
        u,
        e1
    )

    midpoint = (
        a + b
    ) / 2

    h = math.sqrt(
        max(
            r*r
            -
            (d/2)**2,
            0.0
        )
    )

    if h < 1e-8:

        return midpoint.reshape(
            1,
            3
        ).astype(
            np.float32
        )

    out = []

    for t in np.linspace(
        0,
        2*np.pi,
        samples,
        endpoint=False
    ):

        out.append(

            midpoint
            +
            h
            *
            (
                np.cos(t)*e1
                +
                np.sin(t)*e2
            )
        )

    return np.asarray(
        out,
        np.float32
    )


def extract_new2_features(
    residues,
    sequence,
):

    n = len(
        residues
    )

    METALSPEC = np.zeros(
        (
            n,
            len(
                METALSPEC_NAMES
            )
        ),
        np.float32
    )

    ELEC3D = np.zeros(
        (
            n,
            len(
                ELEC3D_NAMES
            )
        ),
        np.float32
    )

    TOPO = np.zeros(
        (
            n,
            len(
                TOPO_NAMES
            )
        ),
        np.float32
    )

    SOLV = np.zeros(
        (
            n,
            len(
                SOLV_NAMES
            )
        ),
        np.float32
    )

    SEQMOTIF = np.zeros(
        (
            n,
            len(
                SEQMOTIF_NAMES
            )
        ),
        np.float32
    )


    anchors = np.stack(
        [
            safe_anchor(
                r
            )

            for r
            in residues
        ]
    ).astype(
        np.float32
    )


    ca = np.stack(
        [
            np.asarray(
                r["CA"].coord,
                np.float32
            )

            for r
            in residues
        ]
    )


    resnames = [
        str(
            r.resname
        ).upper()

        for r
        in residues
    ]


    # --------------------------------------------------------
    # donor atom pool
    # --------------------------------------------------------

    donor_xyz = []
    donor_type = []
    donor_res = []


    canonical_xyz = []
    canonical_type = []
    canonical_res = []


    # all heavy atoms
    heavy_xyz = []
    heavy_res = []
    heavy_polar = []


    # charge-center proxies
    charge_xyz = []
    charge_q = []


    for ri, res in enumerate(
        residues
    ):

        rn = resnames[
            ri
        ]

        broad = BROAD_DONORS.get(
            rn,
            {}
        )

        canonical = CANONICAL_DONORS.get(
            rn,
            {}
        )


        # donor pools
        for atom_name, dtype in broad.items():

            if atom_name in res:

                donor_xyz.append(
                    np.asarray(
                        res[atom_name].coord,
                        np.float32
                    )
                )

                donor_type.append(
                    dtype
                )

                donor_res.append(
                    ri
                )


        for atom_name, dtype in canonical.items():

            if atom_name in res:

                canonical_xyz.append(
                    np.asarray(
                        res[atom_name].coord,
                        np.float32
                    )
                )

                canonical_type.append(
                    dtype
                )

                canonical_res.append(
                    ri
                )


        # heavy atoms
        for atom in res:

            elem = str(
                atom.element
            ).upper()

            if elem == "H":
                continue

            heavy_xyz.append(
                np.asarray(
                    atom.coord,
                    np.float32
                )
            )

            heavy_res.append(
                ri
            )

            heavy_polar.append(
                elem in {
                    "N",
                    "O",
                    "S",
                }
            )


        # charge centers
        if rn == "ASP":

            pts = [
                np.asarray(
                    res[x].coord,
                    np.float32
                )
                for x in [
                    "OD1",
                    "OD2"
                ]
                if x in res
            ]

            if pts:
                charge_xyz.append(
                    np.mean(
                        pts,
                        axis=0
                    )
                )
                charge_q.append(
                    -1.0
                )


        elif rn == "GLU":

            pts = [
                np.asarray(
                    res[x].coord,
                    np.float32
                )
                for x in [
                    "OE1",
                    "OE2"
                ]
                if x in res
            ]

            if pts:
                charge_xyz.append(
                    np.mean(
                        pts,
                        axis=0
                    )
                )
                charge_q.append(
                    -1.0
                )


        elif rn == "LYS":

            if "NZ" in res:

                charge_xyz.append(
                    np.asarray(
                        res["NZ"].coord,
                        np.float32
                    )
                )

                charge_q.append(
                    +1.0
                )


        elif rn == "ARG":

            pts = [
                np.asarray(
                    res[x].coord,
                    np.float32
                )

                for x in [
                    "NH1",
                    "NH2",
                    "CZ"
                ]

                if x in res
            ]

            if pts:

                charge_xyz.append(
                    np.mean(
                        pts,
                        axis=0
                    )
                )

                charge_q.append(
                    +1.0
                )


    donor_xyz = np.asarray(
        donor_xyz,
        np.float32
    )

    donor_type = np.asarray(
        donor_type,
        object
    )

    donor_res = np.asarray(
        donor_res,
        np.int32
    )


    canonical_xyz = np.asarray(
        canonical_xyz,
        np.float32
    )

    canonical_type = np.asarray(
        canonical_type,
        object
    )

    canonical_res = np.asarray(
        canonical_res,
        np.int32
    )


    heavy_xyz = np.asarray(
        heavy_xyz,
        np.float32
    )

    heavy_res = np.asarray(
        heavy_res,
        np.int32
    )

    heavy_polar = np.asarray(
        heavy_polar,
        bool
    )


    charge_xyz = np.asarray(
        charge_xyz,
        np.float32
    )

    charge_q = np.asarray(
        charge_q,
        np.float32
    )


    donor_tree = (
        cKDTree(
            donor_xyz
        )
        if len(
            donor_xyz
        )
        else None
    )


    canonical_tree = (
        cKDTree(
            canonical_xyz
        )
        if len(
            canonical_xyz
        )
        else None
    )


    heavy_tree = (
        cKDTree(
            heavy_xyz
        )
        if len(
            heavy_xyz
        )
        else None
    )


    charge_tree = (
        cKDTree(
            charge_xyz
        )
        if len(
            charge_xyz
        )
        else None
    )


    # ========================================================
    # PER RESIDUE
    # ========================================================

    for i in range(
        n
    ):

        anchor = anchors[
            i
        ]


        # ====================================================
        # A. METAL-SPECIFIC COMPATIBILITY
        # ====================================================

        local_donors = []

        if donor_tree is not None:

            local_donors = [
                j
                for j
                in donor_tree.query_ball_point(
                    anchor,
                    r=6.0
                )
                if donor_res[
                    j
                ] != i
            ]


        focal = []

        rn = resnames[
            i
        ]

        for atom_name in CANONICAL_DONORS.get(
            rn,
            {}
        ):

            if atom_name in residues[
                i
            ]:

                focal.append(
                    np.asarray(
                        residues[
                            i
                        ][
                            atom_name
                        ].coord,
                        np.float32
                    )
                )


        best_center = None


        if focal and local_donors:

            centers = []

            for fc in focal:

                for j in local_donors:

                    cc = sphere_pair_centers(
                        fc,
                        donor_xyz[
                            j
                        ],
                        r=2.10,
                        samples=8
                    )

                    if len(
                        cc
                    ):
                        centers.append(
                            cc
                        )


            if centers:

                centers = np.concatenate(
                    centers,
                    axis=0
                )


                best_score = None

                for center in centers:

                    distances = np.linalg.norm(
                        donor_xyz
                        -
                        center,
                        axis=1
                    )


                    near = np.where(
                        np.abs(
                            distances
                            -
                            2.10
                        )
                        <=
                        0.50
                    )[0]


                    if not np.any(
                        donor_res[
                            near
                        ]
                        ==
                        i
                    ):
                        continue


                    rmse = (
                        float(
                            np.sqrt(
                                np.mean(
                                    (
                                        distances[
                                            near
                                        ]
                                        -
                                        2.10
                                    )
                                    **2
                                )
                            )
                        )
                        if len(
                            near
                        )
                        else 9.0
                    )


                    score = (
                        len(
                            near
                        ),
                        -rmse
                    )


                    if (
                        best_score is None
                        or
                        score
                        >
                        best_score
                    ):

                        best_score = score
                        best_center = center


        col = 0

        for metal in METALS:

            proto = METAL_PROTO[
                metal
            ]


            if best_center is None:

                METALSPEC[
                    i,
                    col:col+3
                ] = 0.0

                col += 3
                continue


            distance = np.linalg.norm(
                donor_xyz
                -
                best_center,
                axis=1
            )


            near = np.where(
                np.abs(
                    distance
                    -
                    proto[
                        "r0"
                    ]
                )
                <=
                0.55
            )[0]


            if len(
                near
            ):

                rmse = float(
                    np.sqrt(
                        np.mean(
                            (
                                distance[
                                    near
                                ]
                                -
                                proto[
                                    "r0"
                                ]
                            )
                            **2
                        )
                    )
                )

                distance_fit = math.exp(
                    -
                    (
                        rmse
                        /
                        0.35
                    )
                    **2
                )


                coordination_fit = math.exp(
                    -
                    abs(
                        len(
                            near
                        )
                        -
                        proto[
                            "coord"
                        ]
                    )
                    /
                    2.0
                )


                type_scores = [
                    proto[
                        "weights"
                    ].get(
                        str(
                            donor_type[
                                j
                            ]
                        ),
                        0.0
                    )
                    for j in near
                ]


                donor_type_fit = float(
                    np.mean(
                        type_scores
                    )
                )

            else:

                distance_fit = 0.0
                coordination_fit = 0.0
                donor_type_fit = 0.0


            METALSPEC[
                i,
                col
            ] = distance_fit

            METALSPEC[
                i,
                col+1
            ] = coordination_fit

            METALSPEC[
                i,
                col+2
            ] = donor_type_fit

            col += 3


        # ====================================================
        # B. 3D ELECTROSTATIC FIELD
        # ====================================================

        for radius, offset in [
            (
                8.0,
                0
            ),
            (
                12.0,
                6
            ),
        ]:

            if charge_tree is None:
                continue


            idx = charge_tree.query_ball_point(
                anchor,
                r=radius
            )


            if not idx:
                continue


            xyz = charge_xyz[
                idx
            ]

            q = charge_q[
                idx
            ]


            rvec = xyz - anchor

            dist = np.maximum(
                np.linalg.norm(
                    rvec,
                    axis=1
                ),
                1.5
            )


            field = np.sum(
                q[
                    :,
                    None
                ]
                *
                (
                    -
                    rvec
                )
                /
                (
                    dist[
                        :,
                        None
                    ]
                    **3
                ),
                axis=0
            )


            net = float(
                q.sum()
            )


            if radius == 8.0:

                ELEC3D[
                    i,
                    0
                ] = net

                ELEC3D[
                    i,
                    1
                ] = float(
                    np.linalg.norm(
                        field
                    )
                )


                radial_vec = (
                    anchor
                    -
                    ca.mean(
                        axis=0
                    )
                )

                radial_norm = np.linalg.norm(
                    radial_vec
                )


                if radial_norm > 1e-8:

                    radial_vec /= radial_norm

                    ELEC3D[
                        i,
                        2
                    ] = float(
                        field
                        @
                        radial_vec
                    )


                centroid = np.average(
                    xyz,
                    axis=0,
                    weights=np.abs(
                        q
                    )
                )


                dipole = np.sum(
                    q[
                        :,
                        None
                    ]
                    *
                    (
                        xyz
                        -
                        centroid
                    ),
                    axis=0
                )


                ELEC3D[
                    i,
                    3
                ] = float(
                    np.linalg.norm(
                        dipole
                    )
                )


                pos = xyz[
                    q > 0
                ]

                neg = xyz[
                    q < 0
                ]


                if (
                    len(
                        pos
                    )
                    and
                    len(
                        neg
                    )
                ):

                    ELEC3D[
                        i,
                        4
                    ] = float(
                        np.linalg.norm(
                            pos.mean(
                                axis=0
                            )
                            -
                            neg.mean(
                                axis=0
                            )
                        )
                    )


                if len(
                    xyz
                ) >= 3:

                    u = (
                        xyz
                        -
                        anchor
                    )

                    u = (
                        u
                        /
                        np.maximum(
                            np.linalg.norm(
                                u,
                                axis=1,
                                keepdims=True
                            ),
                            1e-8
                        )
                    )


                    cov = np.cov(
                        u.T,
                        bias=True
                    )


                    eig = np.maximum(
                        np.linalg.eigvalsh(
                            cov
                        ),
                        0
                    )


                    ELEC3D[
                        i,
                        5
                    ] = float(
                        eig.max()
                        /
                        max(
                            eig.sum(),
                            1e-8
                        )
                    )


            else:

                ELEC3D[
                    i,
                    6
                ] = net

                ELEC3D[
                    i,
                    7
                ] = float(
                    np.linalg.norm(
                        field
                    )
                )


        # ====================================================
        # C. DONOR NETWORK TOPOLOGY
        # ====================================================

        if canonical_tree is not None:

            idx = [
                j
                for j
                in canonical_tree.query_ball_point(
                    anchor,
                    r=8.0
                )
            ]

        else:

            idx = []


        if idx:

            rr = canonical_res[
                idx
            ]

            unique_res = np.unique(
                rr
            )


            coords = np.asarray(
                [
                    anchors[
                        r
                    ]
                    for r
                    in unique_res
                ],
                np.float32
            )


            types = [
                resnames[
                    r
                ]
                for r
                in unique_res
            ]


            TOPO[
                i,
                0
            ] = len(
                unique_res
            )


            TOPO[
                i,
                1
            ] = len(
                set(
                    types
                )
            )


            edges = []

            pair_dist = []

            for a, b in combinations(
                range(
                    len(
                        unique_res
                    )
                ),
                2
            ):

                dd = float(
                    np.linalg.norm(
                        coords[
                            a
                        ]
                        -
                        coords[
                            b
                        ]
                    )
                )

                pair_dist.append(
                    dd
                )

                if dd <= 5.0:

                    edges.append(
                        (
                            a,
                            b
                        )
                    )


            TOPO[
                i,
                2
            ] = len(
                edges
            )


            possible = (
                len(
                    unique_res
                )
                *
                (
                    len(
                        unique_res
                    )
                    -
                    1
                )
                /
                2
            )


            TOPO[
                i,
                3
            ] = (
                len(
                    edges
                )
                /
                possible
                if possible
                else 0.0
            )


            # connected components
            parent = list(
                range(
                    len(
                        unique_res
                    )
                )
            )


            def find(
                x
            ):

                while parent[
                    x
                ] != x:

                    parent[
                        x
                    ] = parent[
                        parent[
                            x
                        ]
                    ]

                    x = parent[
                        x
                    ]

                return x


            def union(
                a,
                b
            ):

                a = find(
                    a
                )

                b = find(
                    b
                )

                if a != b:

                    parent[
                        b
                    ] = a


            for a, b in edges:

                union(
                    a,
                    b
                )


            comps = {}

            for j in range(
                len(
                    unique_res
                )
            ):

                root = find(
                    j
                )

                comps[
                    root
                ] = (
                    comps.get(
                        root,
                        0
                    )
                    +
                    1
                )


            largest = (
                max(
                    comps.values()
                )
                if comps
                else 0
            )


            TOPO[
                i,
                4
            ] = (
                largest
                /
                max(
                    len(
                        unique_res
                    ),
                    1
                )
            )


            edge_set = {
                tuple(
                    sorted(
                        x
                    )
                )
                for x in edges
            }


            triangles = 0

            for a, b, c in combinations(
                range(
                    len(
                        unique_res
                    )
                ),
                3
            ):

                if (
                    (
                        a,
                        b
                    )
                    in edge_set
                    and
                    (
                        a,
                        c
                    )
                    in edge_set
                    and
                    (
                        b,
                        c
                    )
                    in edge_set
                ):

                    triangles += 1


            TOPO[
                i,
                5
            ] = triangles


            seq_sep = np.abs(
                unique_res
                -
                i
            )


            TOPO[
                i,
                6
            ] = int(
                np.sum(
                    seq_sep
                    >=
                    12
                )
            )


            TOPO[
                i,
                7
            ] = float(
                seq_sep.mean()
            )


            TOPO[
                i,
                8
            ] = float(
                seq_sep.max()
            )


            center = coords.mean(
                axis=0
            )


            TOPO[
                i,
                9
            ] = float(
                np.sqrt(
                    np.mean(
                        np.sum(
                            (
                                coords
                                -
                                center
                            )
                            **2,
                            axis=1
                        )
                    )
                )
            )


            if pair_dist:

                TOPO[
                    i,
                    10
                ] = float(
                    np.min(
                        pair_dist
                    )
                )

                TOPO[
                    i,
                    11
                ] = float(
                    np.mean(
                        pair_dist
                    )
                )


        # ====================================================
        # D. SOLVATION / POLAR ORGANIZATION
        # ====================================================

        if heavy_tree is not None:

            idx = [
                j
                for j
                in heavy_tree.query_ball_point(
                    anchor,
                    r=6.0
                )
                if heavy_res[
                    j
                ]
                != i
            ]

        else:

            idx = []


        if idx:

            xyz = heavy_xyz[
                idx
            ]

            polar = heavy_polar[
                idx
            ]


            d = np.linalg.norm(
                xyz
                -
                anchor,
                axis=1
            )


            for col, radius in enumerate(
                [
                    3.0,
                    4.0,
                    6.0
                ]
            ):

                SOLV[
                    i,
                    col
                ] = int(
                    np.sum(
                        polar
                        &
                        (
                            d
                            <=
                            radius
                        )
                    )
                )


            mask4 = (
                d
                <=
                4.0
            )

            mask6 = (
                d
                <=
                6.0
            )


            SOLV[
                i,
                3
            ] = (
                polar[
                    mask4
                ].mean()
                if mask4.any()
                else 0.0
            )


            SOLV[
                i,
                4
            ] = (
                polar[
                    mask6
                ].mean()
                if mask6.any()
                else 0.0
            )


            SOLV[
                i,
                5
            ] = int(
                np.sum(
                    (~polar)
                    &
                    mask4
                )
            )


            core_polar = np.sum(
                polar
                &
                (
                    d
                    <=
                    4.0
                )
            )


            shell_polar = np.sum(
                polar
                &
                (
                    d
                    >
                    4.0
                )
                &
                (
                    d
                    <=
                    6.0
                )
            )


            SOLV[
                i,
                6
            ] = (
                shell_polar
                /
                (
                    core_polar
                    +
                    1.0
                )
            )


            SOLV[
                i,
                7
            ] = (
                1.0
                /
                (
                    1.0
                    +
                    np.sum(
                        d
                        <=
                        3.0
                    )
                )
            )


            SOLV[
                i,
                8
            ] = (
                core_polar
                /
                (
                    np.sum(
                        mask4
                    )
                    +
                    1.0
                )
            )


            pxyz = xyz[
                polar
                &
                mask6
            ]


            if len(
                pxyz
            ) >= 3:

                u = pxyz - anchor

                u /= np.maximum(
                    np.linalg.norm(
                        u,
                        axis=1,
                        keepdims=True
                    ),
                    1e-8
                )


                cov = np.cov(
                    u.T,
                    bias=True
                )


                eig = np.maximum(
                    np.linalg.eigvalsh(
                        cov
                    ),
                    0
                )


                SOLV[
                    i,
                    9
                ] = float(
                    eig.max()
                    /
                    max(
                        eig.sum(),
                        1e-8
                    )
                )


        # ====================================================
        # E. EXPLICIT SEQUENCE MOTIF
        # ====================================================

        for col, w in enumerate(
            [
                2,
                4,
                8,
                16
            ]
        ):

            lo = max(
                0,
                i-w
            )

            hi = min(
                n,
                i+w+1
            )


            chars = [
                sequence[
                    j
                ]
                for j in range(
                    lo,
                    hi
                )
                if j != i
            ]


            SEQMOTIF[
                i,
                col
            ] = (
                sum(
                    c in DONOR_AA
                    for c in chars
                )
                /
                max(
                    len(
                        chars
                    ),
                    1
                )
            )


        for col, w in zip(
            [
                4,
                5,
                6
            ],
            [
                4,
                8,
                16
            ]
        ):

            lo = max(
                0,
                i-w
            )

            hi = min(
                n,
                i+w+1
            )


            chars = [
                sequence[
                    j
                ]
                for j in range(
                    lo,
                    hi
                )
                if j != i
            ]


            SEQMOTIF[
                i,
                col
            ] = (
                sum(
                    c in {
                        "D",
                        "E"
                    }
                    for c in chars
                )
                /
                max(
                    len(
                        chars
                    ),
                    1
                )
            )


        for col, w in [
            (
                7,
                8
            ),
            (
                8,
                16
            )
        ]:

            lo = max(
                0,
                i-w
            )

            hi = min(
                n,
                i+w+1
            )


            chars = [
                sequence[
                    j
                ]
                for j in range(
                    lo,
                    hi
                )
                if (
                    j != i
                    and
                    sequence[
                        j
                    ]
                    in DONOR_AA
                )
            ]


            SEQMOTIF[
                i,
                col
            ] = len(
                set(
                    chars
                )
            )


        # sequence-distant donor density
        all_donor = [
            j
            for j, c in enumerate(
                sequence[
                    :n
                ]
            )
            if (
                c in DONOR_AA
                and
                abs(
                    j-i
                )
                >=
                12
            )
        ]


        SEQMOTIF[
            i,
            9
        ] = (
            len(
                all_donor
            )
            /
            max(
                n,
                1
            )
        )


    return {
        "METALSPEC":
            METALSPEC,

        "ELEC3D":
            ELEC3D,

        "TOPO":
            TOPO,

        "SOLV":
            SOLV,

        "SEQMOTIF":
            SEQMOTIF,
    }



MECH1_BLOCKS = ("ACCESS", "SHELL2", "ENV", "CONF")
MULTI2_BLOCKS = ("METALSPEC", "ELEC3D", "TOPO", "SOLV", "SEQMOTIF")
ALL_MECHANISTIC_BLOCKS = MECH1_BLOCKS + MULTI2_BLOCKS


def ensure_mech1_cache(df, split: str, paths, cfg):
    """Create/reuse ACCESS/SHELL2/ENV/CONF cache for one split."""
    path = paths["cache"] / f"{split}_mechanistic_v1.pkl"
    cache = core.load_pickle(path) if path.exists() else {}
    rows = {str(r.prot_id): r for r in df.itertuples()}
    missing = [str(p) for p in df.prot_id if str(p) not in cache]
    if not missing:
        print(f"[{split}] Reused MECH1 cache: {path.name}")
        return cache
    for pid in tqdm(missing, desc=f"MECH1 {split}"):
        row = rows[pid]
        seq = str(row.sequence)[:cfg.max_residues]
        pdb = core.resolve_predicted_pdb(paths["base"], pid, split)
        residues = core.parse_protein_residues(pdb, len(seq))
        n, _ = core.validate_feature_alignment(pid, seq, residues)
        cache[pid] = extract_mechanistic_features(residues[:n])
    core.save_pickle(cache, path)
    print("Saved:", path)
    return cache


def ensure_multi2_cache(df, split: str, paths, cfg):
    """Create/reuse METALSPEC/ELEC3D/TOPO/SOLV/SEQMOTIF cache for one split."""
    path = paths["cache"] / f"{split}_multisignal_v2.pkl"
    cache = core.load_pickle(path) if path.exists() else {}
    rows = {str(r.prot_id): r for r in df.itertuples()}
    missing = [str(p) for p in df.prot_id if str(p) not in cache]
    if not missing:
        print(f"[{split}] Reused MULTI2 cache: {path.name}")
        return cache
    for pid in tqdm(missing, desc=f"MULTI2 {split}"):
        row = rows[pid]
        seq = str(row.sequence)[:cfg.max_residues]
        pdb = core.resolve_predicted_pdb(paths["base"], pid, split)
        residues = core.parse_protein_residues(pdb, len(seq))
        n, _ = core.validate_feature_alignment(pid, seq, residues)
        cache[pid] = extract_new2_features(residues[:n], seq[:n])
    core.save_pickle(cache, path)
    print("Saved:", path)
    return cache


def attach_feature_cache(store, cache, block_names):
    """Attach blocks to an existing standardized store, trimming all arrays to common length."""
    for pid in list(store):
        if pid not in cache:
            del store[pid]
            continue
        item = store[pid]
        n = min(len(item["y"]), *[np.asarray(cache[pid][b]).shape[0] for b in block_names])
        for key in list(item):
            if key == "sequence":
                item[key] = item[key][:n]
            elif isinstance(item[key], np.ndarray) and item[key].shape[0] >= n:
                item[key] = item[key][:n]
        for b in block_names:
            item[b] = np.asarray(cache[pid][b][:n], dtype=np.float32)
    return store


def ensure_and_attach_all(stores, frames, paths, cfg, mech1=True, multi2=True):
    """Convenience wrapper over all three splits."""
    split_map = {"train":"DevSet1010", "test300":"TestSet300", "test46":"TestSetNew46"}
    for key, split in split_map.items():
        if mech1:
            c = ensure_mech1_cache(frames[key], split, paths, cfg)
            attach_feature_cache(stores[key], c, MECH1_BLOCKS)
        if multi2:
            c = ensure_multi2_cache(frames[key], split, paths, cfg)
            attach_feature_cache(stores[key], c, MULTI2_BLOCKS)
    return stores


def make_seqctx(sequence: str) -> np.ndarray:
    """182-d explicit local sequence context used in the no-ESM diagnostic.

    160 dims: AA one-hot at offsets [-4,-3,-2,-1,+1,+2,+3,+4]
     20 dims: AA composition in +/-8 window excluding focal residue
      1 dim : relative sequence position [0,1]
      1 dim : normalized proximity to nearest terminus [0,1]
    """
    aa20 = core.AA20
    aa_i = core.AA_TO_IDX
    seq = str(sequence)
    n = len(seq)
    out = np.zeros((n, 182), dtype=np.float32)
    offsets = (-4,-3,-2,-1,1,2,3,4)
    for i in range(n):
        for oi, off in enumerate(offsets):
            j = i + off
            if 0 <= j < n and seq[j] in aa_i:
                out[i, oi*20 + aa_i[seq[j]]] = 1.0
        lo, hi = max(0, i-8), min(n, i+9)
        denom = 0
        for j in range(lo, hi):
            if j == i: continue
            a = seq[j]
            if a in aa_i:
                out[i, 160 + aa_i[a]] += 1.0
                denom += 1
        if denom:
            out[i,160:180] /= float(denom)
        out[i,180] = 0.0 if n <= 1 else i / float(n-1)
        out[i,181] = 0.0 if n <= 1 else min(i, n-1-i) / max((n-1)/2.0, 1.0)
    return out


def attach_seqctx(stores):
    for store in stores.values():
        for item in store.values():
            item["SEQCTX"] = make_seqctx(item["sequence"])
    return stores
