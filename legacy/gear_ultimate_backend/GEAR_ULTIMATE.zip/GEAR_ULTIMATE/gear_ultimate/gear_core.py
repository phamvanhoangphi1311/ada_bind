#!/usr/bin/env python3
"""
GEAR standardized representation x classifier experiment runner.

Purpose
-------
Run one locked, resumable experiment grid on the bindNode24 DevSet1010 official
5-fold splits and the two external sets (TestSet300, TestSetNew46), reusing the
existing GEAR ESM / structure / atomic caches whenever they are compatible.

Models
------
- MLP: residue-wise MLP on raw representation
- KAN: learned linear compression -> KAN head
- XGBoost: GPU hist on raw representation

Representation blocks
---------------------
- AA        : 20-d focal amino-acid one-hot (existing structure cache)
- ESM       : 1280-d mean(last two layers) ESM2-t33 embedding (existing cache)
- STRUCTURE : 112-d spatial + 8-d local structural descriptors (existing cache)
- ATOM      : 15-d atom-level coordination geometry (reuses existing cache;
              rebuilds only if missing)
- CHEM      : 24-d chemistry/electrostatics descriptor added in this runner

Leakage guardrails
------------------
- Official protein-level folds only.
- Standardization and class weighting are fit on training proteins only.
- ATOM and CHEM extractors never receive binding labels.
- External labels are used only to compute final metrics.
- OOF threshold is selected only from DevSet1010 OOF predictions, then locked.
- External sets are never used for early stopping or hyperparameter selection.

This runner intentionally does NOT reuse older model result CSVs because those
may have different seeds/training protocols. It DOES reuse feature caches.
"""

from __future__ import annotations

import argparse
import ast
import gc
import hashlib
import json
import math
import os
import pickle
import random
import sys
import time
import traceback
import urllib.request
from dataclasses import asdict, dataclass
from itertools import combinations
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from tqdm.auto import tqdm

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

from Bio import PDB
from Bio.SeqUtils import seq1
from scipy.spatial import cKDTree
from scipy.stats import t as student_t
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)
import xgboost as xgb

try:
    from kan import KAN
    HAS_KAN = True
except Exception as exc:  # pragma: no cover - runtime environment dependent
    KAN = None
    HAS_KAN = False
    KAN_IMPORT_ERROR = repr(exc)


# =============================================================================
# CONFIG
# =============================================================================

@dataclass
class Config:
    base: str = "/content/drive/MyDrive/Protein-binding"
    label_column: str = "metal_binding"
    max_residues: int = 1000
    seed: int = 42
    run_version: str = "standardized_chem_v1"

    # Neural heads
    neural_epochs: int = 30
    neural_patience: int = 6
    proteins_per_batch_mlp: int = 8
    proteins_per_batch_kan: int = 8
    lr: float = 2e-4
    weight_decay: float = 1e-4
    dropout: float = 0.20
    grad_clip: float = 2.0

    # XGBoost
    xgb_estimators: int = 700
    xgb_depth: int = 7
    xgb_lr: float = 0.04
    xgb_subsample: float = 0.85
    xgb_colsample: float = 0.65
    xgb_min_child_weight: float = 3.0
    xgb_reg_lambda: float = 1.0
    xgb_patience: int = 40
    xgb_max_bin: int = 256
    # None = all training residues. Change only if RAM/GPU OOM and document it.
    xgb_train_max_residues: Optional[int] = None

    # Atomic geometry
    donor_search_radius_A: float = 5.0
    ideal_metal_donor_distance_A: float = 2.10
    center_distance_tol_A: float = 0.35
    center_distance_tol_loose_A: float = 0.50
    candidate_circle_samples: int = 12
    center_clearance_threshold_A: float = 1.20

    # Chemistry descriptor
    chem_radius_inner_A: float = 4.0
    chem_radius_outer_A: float = 6.0
    chem_charge_radius_outer_A: float = 8.0

    # Reporting
    fixed_threshold: float = 0.50
    save_models: bool = False
    save_ensemble_predictions: bool = True

    # Experiment grid
    preset: str = "full"  # full | core
    models: Tuple[str, ...] = ("MLP", "KAN", "XGBoost")


LABEL_COLUMNS = [
    "binding_sites",
    "any_ligand_binding_sites",
    "metal_binding",
    "small_binding",
    "nuclear_binding",
]
AA20 = list("ACDEFGHIKLMNPQRSTVWY")
AA_TO_IDX = {a: i for i, a in enumerate(AA20)}

# Existing 15-d ATOM feature definition, kept compatible with the prior notebook.
ATOM_GEOM_FEATURE_NAMES = [
    "focal_has_donor",
    "n_focal_donor_atoms",
    "n_neighbor_donor_atoms_5A",
    "n_neighbor_donor_residues_5A",
    "min_focal_neighbor_donor_dist_A",
    "mean_focal_neighbor_donor_dist_A",
    "n_focal_neighbor_pairs_le4p2A",
    "best_coord_n_tol035",
    "best_coord_n_tol050",
    "best_coord_rmse_A",
    "best_center_clearance_A",
    "has_empty_center_ge2",
    "has_empty_center_ge3",
    "best_min_donor_angle_deg",
    "best_mean_donor_angle_deg",
]

# Conservative, label-independent donor set for ATOM geometry.
ATOM_DONOR_ATOMS = {
    "CYS": ["SG"],
    "HIS": ["ND1", "NE2"],
    "ASP": ["OD1", "OD2"],
    "GLU": ["OE1", "OE2"],
}

# CHEM v1: donor-type chemistry + local electrostatic proxies.
# All counts exclude atoms belonging to the focal residue itself.
CHEM_DONOR_CATEGORIES = {
    "carboxylate_O": {
        "ASP": ["OD1", "OD2"],
        "GLU": ["OE1", "OE2"],
    },
    "imidazole_N": {"HIS": ["ND1", "NE2"]},
    "thiol_S": {"CYS": ["SG"]},
    "hydroxyl_O": {
        "SER": ["OG"],
        "THR": ["OG1"],
        "TYR": ["OH"],
    },
    "amide_O": {
        "ASN": ["OD1"],
        "GLN": ["OE1"],
    },
    "thioether_S": {"MET": ["SD"]},
    # Backbone carbonyl oxygen is a chemically distinct O donor category.
    "backbone_O": "BACKBONE_O",
}

CHEM_FEATURE_NAMES: List[str] = []
for radius in (4, 6):
    for cat in CHEM_DONOR_CATEGORIES:
        CHEM_FEATURE_NAMES.append(f"n_{cat}_{radius}A")
CHEM_FEATURE_NAMES += [
    "n_negative_residues_6A",       # Asp/Glu side-chain charge centers
    "n_positive_residues_6A",       # Lys/Arg side-chain charge centers
    "n_histidine_residues_6A",      # separated because His protonation is context dependent
    "signed_charge_potential_6A",   # sum(q/r), q=-1 D/E, +1 K/R
    "signed_charge_potential_8A",
    "negative_charge_potential_6A", # sum(1/r) over D/E
    "positive_charge_potential_6A", # sum(1/r) over K/R
    "O_donor_fraction_6A",
    "N_donor_fraction_6A",
    "S_donor_fraction_6A",
]
assert len(CHEM_FEATURE_NAMES) == 24

# Structure block already cached by spatial_revamp.
STRUCTURE_BLOCKS = ["SPATIAL", "LOCAL"]

FULL_REPRESENTATIONS: Dict[str, List[str]] = {
    # AA controls
    "AA": ["AA"],
    "AA+Structure": ["AA", "SPATIAL", "LOCAL"],
    "AA+Atomic": ["AA", "ATOM"],
    "AA+Chem": ["AA", "CHEM"],
    "AA+Atomic+Chem": ["AA", "ATOM", "CHEM"],
    # Full factorial of Structure / Atomic / Chem on top of ESM
    "ESM": ["ESM"],
    "ESM+Structure": ["ESM", "SPATIAL", "LOCAL"],
    "ESM+Atomic": ["ESM", "ATOM"],
    "ESM+Chem": ["ESM", "CHEM"],
    "ESM+Structure+Atomic": ["ESM", "SPATIAL", "LOCAL", "ATOM"],
    "ESM+Structure+Chem": ["ESM", "SPATIAL", "LOCAL", "CHEM"],
    "ESM+Atomic+Chem": ["ESM", "ATOM", "CHEM"],
    "ESM+Structure+Atomic+Chem": ["ESM", "SPATIAL", "LOCAL", "ATOM", "CHEM"],
}

CORE_REPRESENTATIONS: Dict[str, List[str]] = {
    k: FULL_REPRESENTATIONS[k]
    for k in [
        "AA",
        "AA+Atomic",
        "AA+Chem",
        "ESM",
        "ESM+Structure",
        "ESM+Atomic",
        "ESM+Chem",
        "ESM+Atomic+Chem",
        "ESM+Structure+Atomic+Chem",
    ]
}

PAIRED_COMPARISONS = [
    ("AA+Structure", "AA", "Structure beyond AA"),
    ("AA+Atomic", "AA", "Atomic beyond AA"),
    ("AA+Chem", "AA", "Chemistry beyond AA"),
    ("AA+Atomic+Chem", "AA+Atomic", "Chemistry after Atomic, AA control"),
    ("ESM+Structure", "ESM", "Structure beyond ESM"),
    ("ESM+Atomic", "ESM", "Atomic beyond ESM"),
    ("ESM+Chem", "ESM", "Chemistry beyond ESM"),
    ("ESM+Structure+Atomic", "ESM+Atomic", "Structure after Atomic"),
    ("ESM+Structure+Chem", "ESM+Chem", "Structure after Chemistry"),
    ("ESM+Atomic+Chem", "ESM+Atomic", "Chemistry after Atomic"),
    ("ESM+Atomic+Chem", "ESM+Chem", "Atomic after Chemistry"),
    ("ESM+Structure+Atomic+Chem", "ESM+Atomic+Chem", "Structure after Atomic+Chemistry"),
]


# =============================================================================
# GENERAL HELPERS
# =============================================================================

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def safe_seq1(resname: str) -> str:
    try:
        x = seq1(str(resname))
        return x if x in AA_TO_IDX else "X"
    except Exception:
        return "X"


def parse_label_list(v):
    if isinstance(v, str):
        return list(ast.literal_eval(v))
    return list(v)


def load_frame(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    for c in LABEL_COLUMNS:
        if c in df.columns:
            df[c] = df[c].apply(parse_label_list)
    df["prot_id"] = df["prot_id"].astype(str)
    return df.reset_index(drop=True)


def load_bindnode24_folds() -> List[List[str]]:
    root = (
        "https://raw.githubusercontent.com/erckert/bindNode24/main/"
        "dataset/cv_splits/predicted_structures"
    )
    folds = []
    for k in range(1, 6):
        url = f"{root}/ids_split{k}.txt"
        with urllib.request.urlopen(url, timeout=60) as r:
            ids = [line.decode().strip() for line in r if line.decode().strip()]
        folds.append(ids)
    return folds


def load_pickle(path: Path):
    with open(path, "rb") as f:
        obj = pickle.load(f)
    if isinstance(obj, dict):
        return {str(k): v for k, v in obj.items()}
    return obj


def save_pickle(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as f:
        pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
    tmp.replace(path)


def config_hash(cfg: Config, representations: Mapping[str, Sequence[str]]) -> str:
    payload = {
        "config": asdict(cfg),
        "representations": {k: list(v) for k, v in representations.items()},
        "atom_features": ATOM_GEOM_FEATURE_NAMES,
        "chem_features": CHEM_FEATURE_NAMES,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()[:12]


def class_pos_weight(store, ids: Sequence[str]) -> float:
    pos = sum(int(store[p]["y"].sum()) for p in ids)
    total = sum(len(store[p]["y"]) for p in ids)
    neg = total - pos
    return float(np.clip(neg / max(pos, 1), 1.0, 30.0))


def choose_f1_threshold(y, p) -> float:
    y = np.asarray(y)
    p = np.asarray(p)
    pr, rc, th = precision_recall_curve(y, p)
    if len(th) == 0:
        return 0.5
    f = 2 * pr[:-1] * rc[:-1] / (pr[:-1] + rc[:-1] + 1e-12)
    return float(th[np.nanargmax(f)])


def binary_metrics(y, p, threshold: float) -> Dict[str, float]:
    y = np.asarray(y, dtype=np.int64)
    p = np.asarray(p, dtype=float)
    pred = (p >= threshold).astype(np.int64)
    return {
        "threshold": float(threshold),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "mcc": float(matthews_corrcoef(y, pred)) if len(np.unique(pred)) > 1 else 0.0,
        "auprc": float(average_precision_score(y, p)) if len(np.unique(y)) > 1 else np.nan,
        "auroc": float(roc_auc_score(y, p)) if len(np.unique(y)) > 1 else np.nan,
    }


def confusion(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.int64)
    y_pred = np.asarray(y_pred, dtype=np.int64)
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    tn = int(np.sum((y_true == 0) & (y_pred == 0)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    return tp, fp, tn, fn


def mcc_from_counts(tp, fp, tn, fn):
    denom = ((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)) ** 0.5
    return (tp * tn - fp * fn) / denom if denom else 0.0


def bindnode95_ci(values) -> float:
    """Exact old-notebook / bindNode24-style CI convention for comparability."""
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 2:
        return np.nan
    return float(np.std(values) / np.sqrt(len(values)) * student_t.ppf(0.975, len(values)))


def macro_positive_metrics(store, ids, flat_probs, threshold: float) -> Dict[str, float]:
    cur = 0
    f1s, mccs = [], []
    false_alarm_only = 0
    included = 0
    for pid in ids:
        y = np.asarray(store[pid]["y"], dtype=np.int64)
        p = np.asarray(flat_probs[cur: cur + len(y)], dtype=float)
        cur += len(y)
        pred = (p >= threshold).astype(np.int64)
        tp, fp, tn, fn = confusion(y, pred)
        include = (tp + fp + fn) > 0
        if not include:
            continue
        included += 1
        if y.sum() == 0:
            false_alarm_only += 1
        pr = tp / (tp + fp) if tp + fp else 0.0
        rc = tp / (tp + fn) if tp + fn else 0.0
        f1v = 2 * pr * rc / (pr + rc) if pr + rc else 0.0
        f1s.append(f1v)
        mccs.append(mcc_from_counts(tp, fp, tn, fn))
    return {
        "macro_positive_f1": float(np.mean(f1s)) if f1s else np.nan,
        "macro_positive_f1_ci95": bindnode95_ci(f1s),
        "macro_positive_mcc": float(np.mean(mccs)) if mccs else np.nan,
        "macro_positive_mcc_ci95": bindnode95_ci(mccs),
        "n_macro_positive": int(included),
        "n_false_alarm_only": int(false_alarm_only),
    }


# =============================================================================
# PATHS / EXISTING CACHES
# =============================================================================

def make_paths(cfg: Config):
    base = Path(cfg.base)
    cache = base / "cache" / "spatial_revamp"
    run_root = base / "results" / cfg.run_version / cfg.label_column
    model_root = base / "trained_models" / cfg.run_version / cfg.label_column
    pred_root = run_root / "fold_predictions"
    ensemble_root = run_root / "ensemble_predictions"
    for p in [cache, run_root, model_root, pred_root, ensemble_root]:
        p.mkdir(parents=True, exist_ok=True)
    return {
        "base": base,
        "train_csv": base / "data/development_set/full_grouped_train_binding_sites_df.csv",
        "test300_csv": base / "data/development_set/full_grouped_test_binding_sites_df.csv",
        "test46_csv": base / "data/independent_set/grouped_test_46_new_binding_sites.csv",
        "cache": cache,
        "run_root": run_root,
        "model_root": model_root,
        "pred_root": pred_root,
        "ensemble_root": ensemble_root,
    }


def esm_cache_file(cache: Path, split: str) -> Path:
    return cache / f"{split}_ESM2_t33_mean_last2_1280_fp16.pkl"


def struct_cache_file(cache: Path, split: str) -> Path:
    candidates = [
        cache / f"{split}_spatial_local_v2.pkl",
        cache / f"{split}_spatial_local_v1.pkl",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(f"No structure cache for {split}: {candidates}")


def atom_cache_file(cache: Path, split: str) -> Path:
    return cache / f"{split}_atomic_coordination_v1.pkl"


def chem_cache_file(cache: Path, split: str) -> Path:
    return cache / f"{split}_chemistry_v1_24d.pkl"


def resolve_predicted_pdb(base: Path, pid: str, split: Optional[str] = None) -> Path:
    pid = str(pid)
    candidates = [
        base / "esmFold_pdb_files" / f"{pid}.pdb",
        base / "data" / "pdb_files" / f"{pid}.pdb",
        base / "pdb" / "all" / f"{pid}.pdb",
    ]
    if split:
        candidates += [
            base / "pdb" / split / f"{pid}.pdb",
            base / "data" / "pdb_files" / split / f"{pid}.pdb",
        ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(f"No predicted PDB for {pid}; checked: {candidates}")


# =============================================================================
# PDB PARSING + ATOM FEATURE EXTRACTION
# =============================================================================

def parse_protein_residues(pdb_path: Path, n_keep: int):
    parser = PDB.PDBParser(QUIET=True)
    structure = parser.get_structure(pdb_path.stem, str(pdb_path))
    model = next(structure.get_models())
    residues = []
    for chain in model:
        for res in chain:
            if res.id[0] != " " or "CA" not in res:
                continue
            residues.append(res)
            if len(residues) >= n_keep:
                break
        if len(residues) >= n_keep:
            break
    return residues


def parsed_sequence(residues) -> str:
    return "".join(safe_seq1(r.resname) for r in residues)


def sphere_pair_centers(a, b, cfg: Config):
    r = cfg.ideal_metal_donor_distance_A
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    v = b - a
    d = np.linalg.norm(v)
    if d < 1e-6 or d > 2 * r:
        return np.empty((0, 3), np.float32)
    u = v / d
    helper = np.array([1.0, 0.0, 0.0])
    if abs(u @ helper) > 0.9:
        helper = np.array([0.0, 1.0, 0.0])
    e1 = np.cross(u, helper)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(u, e1)
    mid = (a + b) / 2
    h = np.sqrt(max(r * r - (d / 2) ** 2, 0))
    if h < 1e-8:
        return mid.reshape(1, 3).astype(np.float32)
    ts = np.linspace(0, 2 * np.pi, cfg.candidate_circle_samples, endpoint=False)
    return np.asarray([mid + h * (np.cos(t) * e1 + np.sin(t) * e2) for t in ts], np.float32)


def angle_stats(center, coords):
    if len(coords) < 2:
        return 0.0, 0.0
    V = coords - center
    V = V / np.maximum(np.linalg.norm(V, axis=1, keepdims=True), 1e-8)
    ang = []
    for i, j in combinations(range(len(V)), 2):
        ang.append(np.degrees(np.arccos(np.clip(V[i] @ V[j], -1, 1))))
    return (float(np.min(ang)), float(np.mean(ang))) if ang else (0.0, 0.0)


def atomic_geometry_from_residues(residues, cfg: Config):
    """Compatible 15-d ATOM extractor. No labels are used."""
    n = len(residues)
    out = np.zeros((n, len(ATOM_GEOM_FEATURE_NAMES)), np.float32)
    donors, heavy, heavy_is_donor = [], [], []
    for ri, res in enumerate(residues):
        dn = set(ATOM_DONOR_ATOMS.get(str(res.resname).upper(), []))
        for atom in res:
            if str(atom.element).upper() == "H":
                continue
            xyz = np.asarray(atom.coord, np.float32)
            isdon = atom.name in dn
            heavy.append(xyz)
            heavy_is_donor.append(isdon)
            if isdon:
                donors.append((ri, atom.name, xyz))
    if not donors:
        out[:, 4:6] = 8.0
        out[:, 9] = 2.0
        return out
    dcoord = np.stack([x[2] for x in donors])
    dres = np.asarray([x[0] for x in donors], np.int32)
    dtree = cKDTree(dcoord)
    heavy = np.asarray(heavy, np.float32)
    heavy_is_donor = np.asarray(heavy_is_donor, bool)
    ndheavy = heavy[~heavy_is_donor]
    htree = cKDTree(ndheavy) if len(ndheavy) else None

    for i in range(n):
        fi = np.where(dres == i)[0]
        if len(fi) == 0:
            out[i, 4:6] = 8.0
            out[i, 9] = 2.0
            continue
        out[i, 0] = 1.0
        out[i, 1] = len(fi)
        fcoords = dcoord[fi]
        nbr = set()
        fd = []
        for fc in fcoords:
            for j in dtree.query_ball_point(fc, r=cfg.donor_search_radius_A):
                if dres[j] == i:
                    continue
                nbr.add(int(j))
                fd.append(float(np.linalg.norm(dcoord[j] - fc)))
        nbr = sorted(nbr)
        out[i, 2] = len(nbr)
        out[i, 3] = len(set(int(dres[j]) for j in nbr))
        if fd:
            out[i, 4] = np.min(fd)
            out[i, 5] = np.mean(fd)
            out[i, 6] = np.sum(np.asarray(fd) <= 4.2)
        else:
            out[i, 4:6] = 8.0

        centers = []
        for aidx in fi:
            for bidx in nbr:
                c = sphere_pair_centers(dcoord[aidx], dcoord[bidx], cfg)
                if len(c):
                    centers.append(c)
        if not centers:
            out[i, 9] = 2.0
            continue
        best = None
        for c in np.concatenate(centers):
            dist = np.linalg.norm(dcoord - c, axis=1)
            q35 = np.where(np.abs(dist - cfg.ideal_metal_donor_distance_A) <= cfg.center_distance_tol_A)[0]
            q50 = np.where(np.abs(dist - cfg.ideal_metal_donor_distance_A) <= cfg.center_distance_tol_loose_A)[0]
            if not np.any(dres[q50] == i):
                continue
            rmse = float(np.sqrt(np.mean((dist[q50] - cfg.ideal_metal_donor_distance_A) ** 2))) if len(q50) else 2.0
            clearance = float(htree.query(c, k=1)[0]) if htree is not None else 9.0
            mina, meana = angle_stats(c, dcoord[q50])
            rec = (len(q35), len(q50), clearance, -rmse, rmse, mina, meana)
            if best is None or rec[:4] > best[:4]:
                best = rec
        if best is None:
            out[i, 9] = 2.0
            continue
        n35, n50, clearance, _neg_rmse, rmse, mina, meana = best
        out[i, 7] = n35
        out[i, 8] = n50
        out[i, 9] = rmse
        out[i, 10] = clearance
        empty = clearance >= cfg.center_clearance_threshold_A
        out[i, 11] = float(empty and n35 >= 2)
        out[i, 12] = float(empty and n35 >= 3)
        out[i, 13] = mina
        out[i, 14] = meana
    return out


def chem_reference_point(res) -> np.ndarray:
    """Side-chain chemistry center if available, otherwise C-beta/C-alpha."""
    resname = str(res.resname).upper()
    atoms = []
    # Prefer atoms that can plausibly participate in metal coordination.
    for cat, spec in CHEM_DONOR_CATEGORIES.items():
        if spec == "BACKBONE_O":
            continue
        names = spec.get(resname, []) if isinstance(spec, dict) else []
        for name in names:
            if name in res:
                atoms.append(np.asarray(res[name].coord, np.float32))
    if atoms:
        return np.mean(np.stack(atoms), axis=0).astype(np.float32)
    if "CB" in res:
        return np.asarray(res["CB"].coord, np.float32)
    return np.asarray(res["CA"].coord, np.float32)


def chemistry_features_from_residues(residues, cfg: Config):
    """
    24-d chemistry/electrostatic descriptor.

    This deliberately avoids true metal identity and binding labels. It asks:
    what *types* of potential donor atoms and formal-charge centers surround the
    focal side-chain chemistry center?
    """
    n = len(residues)
    out = np.zeros((n, len(CHEM_FEATURE_NAMES)), np.float32)

    # donor atom records: (residue index, category, element, xyz)
    donor_records = []
    for ri, res in enumerate(residues):
        rn = str(res.resname).upper()
        for cat, spec in CHEM_DONOR_CATEGORIES.items():
            if spec == "BACKBONE_O":
                if "O" in res:
                    donor_records.append((ri, cat, "O", np.asarray(res["O"].coord, np.float32)))
                continue
            for atom_name in spec.get(rn, []):
                if atom_name in res:
                    elem = str(res[atom_name].element).upper() or atom_name[0]
                    donor_records.append((ri, cat, elem, np.asarray(res[atom_name].coord, np.float32)))

    if donor_records:
        donor_xyz = np.stack([z[3] for z in donor_records]).astype(np.float32)
        donor_res = np.asarray([z[0] for z in donor_records], np.int32)
        donor_cat = np.asarray([z[1] for z in donor_records], dtype=object)
        donor_elem = np.asarray([z[2] for z in donor_records], dtype=object)
        donor_tree = cKDTree(donor_xyz)
    else:
        donor_xyz = np.empty((0, 3), np.float32)
        donor_res = np.empty((0,), np.int32)
        donor_cat = np.empty((0,), dtype=object)
        donor_elem = np.empty((0,), dtype=object)
        donor_tree = None

    # Formal-charge centers at dominant near-neutral-pH states.
    charge_records = []  # (res index, q, class, xyz)
    histidine_centers = []
    for ri, res in enumerate(residues):
        rn = str(res.resname).upper()
        if rn == "ASP" and "OD1" in res and "OD2" in res:
            xyz = (np.asarray(res["OD1"].coord) + np.asarray(res["OD2"].coord)) / 2
            charge_records.append((ri, -1.0, "negative", xyz.astype(np.float32)))
        elif rn == "GLU" and "OE1" in res and "OE2" in res:
            xyz = (np.asarray(res["OE1"].coord) + np.asarray(res["OE2"].coord)) / 2
            charge_records.append((ri, -1.0, "negative", xyz.astype(np.float32)))
        elif rn == "LYS" and "NZ" in res:
            charge_records.append((ri, +1.0, "positive", np.asarray(res["NZ"].coord, np.float32)))
        elif rn == "ARG":
            names = [a for a in ["NE", "NH1", "NH2"] if a in res]
            if names:
                xyz = np.mean(np.stack([np.asarray(res[a].coord, np.float32) for a in names]), axis=0)
                charge_records.append((ri, +1.0, "positive", xyz.astype(np.float32)))
        if rn == "HIS":
            names = [a for a in ["ND1", "NE2"] if a in res]
            if names:
                histidine_centers.append((ri, np.mean(np.stack([np.asarray(res[a].coord, np.float32) for a in names]), axis=0)))

    if charge_records:
        charge_xyz = np.stack([z[3] for z in charge_records]).astype(np.float32)
        charge_res = np.asarray([z[0] for z in charge_records], np.int32)
        charge_q = np.asarray([z[1] for z in charge_records], np.float32)
        charge_cls = np.asarray([z[2] for z in charge_records], dtype=object)
        charge_tree = cKDTree(charge_xyz)
    else:
        charge_xyz = np.empty((0, 3), np.float32)
        charge_res = np.empty((0,), np.int32)
        charge_q = np.empty((0,), np.float32)
        charge_cls = np.empty((0,), dtype=object)
        charge_tree = None

    if histidine_centers:
        his_xyz = np.stack([z[1] for z in histidine_centers]).astype(np.float32)
        his_res = np.asarray([z[0] for z in histidine_centers], np.int32)
        his_tree = cKDTree(his_xyz)
    else:
        his_xyz = np.empty((0, 3), np.float32)
        his_res = np.empty((0,), np.int32)
        his_tree = None

    cat_names = list(CHEM_DONOR_CATEGORIES.keys())

    for i, res in enumerate(residues):
        ref = chem_reference_point(res)
        col = 0
        selected_outer = np.empty((0,), dtype=np.int64)

        # Donor-type counts at 4A and 6A, excluding focal residue atoms.
        for radius in (cfg.chem_radius_inner_A, cfg.chem_radius_outer_A):
            if donor_tree is None:
                idx = np.empty((0,), dtype=np.int64)
            else:
                idx = np.asarray(donor_tree.query_ball_point(ref, r=radius), dtype=np.int64)
                if len(idx):
                    idx = idx[donor_res[idx] != i]
            if math.isclose(radius, cfg.chem_radius_outer_A):
                selected_outer = idx
            for cat in cat_names:
                out[i, col] = float(np.sum(donor_cat[idx] == cat)) if len(idx) else 0.0
                col += 1

        # Charged side-chain environment.
        if charge_tree is not None:
            idx6 = np.asarray(charge_tree.query_ball_point(ref, r=cfg.chem_radius_outer_A), dtype=np.int64)
            idx8 = np.asarray(charge_tree.query_ball_point(ref, r=cfg.chem_charge_radius_outer_A), dtype=np.int64)
            if len(idx6):
                idx6 = idx6[charge_res[idx6] != i]
            if len(idx8):
                idx8 = idx8[charge_res[idx8] != i]
        else:
            idx6 = idx8 = np.empty((0,), dtype=np.int64)

        nneg = float(np.sum(charge_cls[idx6] == "negative")) if len(idx6) else 0.0
        npos = float(np.sum(charge_cls[idx6] == "positive")) if len(idx6) else 0.0

        if his_tree is not None:
            ih = np.asarray(his_tree.query_ball_point(ref, r=cfg.chem_radius_outer_A), dtype=np.int64)
            if len(ih):
                ih = ih[his_res[ih] != i]
            nhis = float(len(ih))
        else:
            nhis = 0.0

        def potentials(indices):
            if len(indices) == 0:
                return 0.0, 0.0, 0.0
            d = np.linalg.norm(charge_xyz[indices] - ref, axis=1)
            d = np.maximum(d, 1.0)  # avoid singular proxy at very short distance
            q = charge_q[indices]
            signed = float(np.sum(q / d))
            neg = float(np.sum((q < 0) / d))
            pos = float(np.sum((q > 0) / d))
            return signed, neg, pos

        signed6, negpot6, pospot6 = potentials(idx6)
        signed8, _neg8, _pos8 = potentials(idx8)

        out[i, col: col + 7] = [nneg, npos, nhis, signed6, signed8, negpot6, pospot6]
        col += 7

        # Element fractions among candidate donor atoms within 6A.
        if len(selected_outer):
            elems = donor_elem[selected_outer]
            denom = max(len(elems), 1)
            out[i, col: col + 3] = [
                float(np.sum(elems == "O") / denom),
                float(np.sum(elems == "N") / denom),
                float(np.sum(elems == "S") / denom),
            ]
        else:
            out[i, col: col + 3] = 0.0
        col += 3
        assert col == len(CHEM_FEATURE_NAMES)

    return out


def validate_feature_alignment(pid: str, csv_seq: str, residues, min_identity=0.95):
    pseq = parsed_sequence(residues)
    n = min(len(csv_seq), len(pseq))
    if n == 0:
        raise ValueError(f"{pid}: no aligned PDB residues")
    # Unknown residues are treated as mismatches, intentionally strict.
    identity = sum(a == b for a, b in zip(csv_seq[:n], pseq[:n])) / n
    if identity < min_identity:
        raise ValueError(
            f"{pid}: PDB/CSV sequence identity {identity:.3f} < {min_identity:.2f}; "
            "refusing silent row misalignment"
        )
    return n, identity


def ensure_atom_chem_caches(df: pd.DataFrame, split: str, paths, cfg: Config):
    atom_path = atom_cache_file(paths["cache"], split)
    chem_path = chem_cache_file(paths["cache"], split)
    atom = load_pickle(atom_path) if atom_path.exists() else {}
    chem = load_pickle(chem_path) if chem_path.exists() else {}

    need_atom = [str(p) for p in df.prot_id if str(p) not in atom]
    need_chem = [str(p) for p in df.prot_id if str(p) not in chem]
    need = sorted(set(need_atom) | set(need_chem))
    if not need:
        print(f"[{split}] Reused ATOM cache: {atom_path.name}")
        print(f"[{split}] Reused CHEM cache: {chem_path.name}")
        return atom, chem

    row_by_pid = {str(r.prot_id): r for r in df.itertuples()}
    alignment_rows = []
    print(f"[{split}] Need feature extraction for {len(need)} proteins")
    for pid in tqdm(need, desc=f"ATOM/CHEM {split}"):
        row = row_by_pid[pid]
        seq = str(row.sequence)[: cfg.max_residues]
        pdb_path = resolve_predicted_pdb(paths["base"], pid, split)
        residues = parse_protein_residues(pdb_path, len(seq))
        n, ident = validate_feature_alignment(pid, seq, residues)
        residues = residues[:n]
        alignment_rows.append({
            "split": split,
            "prot_id": pid,
            "csv_len": len(seq),
            "pdb_len_used": len(residues),
            "identity": ident,
            "pdb_path": str(pdb_path),
        })
        if pid not in atom:
            atom[pid] = atomic_geometry_from_residues(residues, cfg).astype(np.float32)
        if pid not in chem:
            chem[pid] = chemistry_features_from_residues(residues, cfg).astype(np.float32)

    save_pickle(atom, atom_path)
    save_pickle(chem, chem_path)
    pd.DataFrame(alignment_rows).to_csv(paths["run_root"] / f"{split}_atom_chem_alignment.csv", index=False)
    print("Saved:", atom_path)
    print("Saved:", chem_path)
    return atom, chem


# =============================================================================
# BUILD ALIGNED STORES FROM EXISTING CACHES
# =============================================================================

def build_store(df, split: str, paths, cfg: Config, atom, chem):
    epath = esm_cache_file(paths["cache"], split)
    if not epath.exists():
        raise FileNotFoundError(
            f"Missing ESM cache {epath}. Run the spatial_revamp notebook ESM extraction first."
        )
    spath = struct_cache_file(paths["cache"], split)
    esm = load_pickle(epath)
    st = load_pickle(spath)
    out = {}
    skipped = []

    for row in df.itertuples():
        pid = str(row.prot_id)
        if pid not in esm or pid not in st or pid not in atom or pid not in chem:
            skipped.append(pid)
            continue
        seq = str(row.sequence)[: cfg.max_residues]
        yfull = np.asarray(getattr(row, cfg.label_column)[: cfg.max_residues], dtype=np.int8)
        item_st = st[pid]
        n = min(
            len(seq), len(yfull),
            np.asarray(esm[pid]).shape[0],
            np.asarray(item_st["AA"]).shape[0],
            np.asarray(item_st["SPATIAL"]).shape[0],
            np.asarray(item_st["LOCAL"]).shape[0],
            np.asarray(atom[pid]).shape[0],
            np.asarray(chem[pid]).shape[0],
        )
        if n <= 0:
            skipped.append(pid)
            continue
        out[pid] = {
            "sequence": seq[:n],
            "y": yfull[:n],
            "AA": np.asarray(item_st["AA"][:n], dtype=np.float32),
            # Keep ESM compact in memory; concat_features converts to float32 on demand.
            "ESM": np.asarray(esm[pid][:n], dtype=np.float16),
            "SPATIAL": np.asarray(item_st["SPATIAL"][:n], dtype=np.float32),
            "LOCAL": np.asarray(item_st["LOCAL"][:n], dtype=np.float32),
            "ATOM": np.asarray(atom[pid][:n], dtype=np.float32),
            "CHEM": np.asarray(chem[pid][:n], dtype=np.float32),
        }

    if skipped:
        pd.DataFrame({"prot_id": skipped}).to_csv(paths["run_root"] / f"{split}_skipped_store_ids.csv", index=False)
        print(f"WARNING [{split}]: skipped {len(skipped)} proteins; see skipped_store_ids.csv")
    return out


def concat_features(item, blocks: Sequence[str]) -> np.ndarray:
    return np.concatenate([np.asarray(item[b], dtype=np.float32) for b in blocks], axis=1).astype(np.float32)


def stack_labels(store, ids: Sequence[str]) -> np.ndarray:
    return np.concatenate([np.asarray(store[p]["y"], dtype=np.int64) for p in ids])


def matrix_from_store(store, ids: Sequence[str], blocks: Sequence[str]):
    Xs, ys = [], []
    for pid in ids:
        Xs.append(concat_features(store[pid], blocks))
        ys.append(np.asarray(store[pid]["y"], dtype=np.int64))
    return np.concatenate(Xs, axis=0), np.concatenate(ys, axis=0)


def stratified_cap(X, y, max_rows: Optional[int], seed: int):
    if max_rows is None or len(y) <= max_rows:
        return X, y
    rng = np.random.default_rng(seed)
    idx0 = np.where(y == 0)[0]
    idx1 = np.where(y == 1)[0]
    frac1 = len(idx1) / max(len(y), 1)
    n1 = min(len(idx1), max(1, int(max_rows * frac1)))
    n0 = min(len(idx0), max_rows - n1)
    take = np.concatenate([
        rng.choice(idx0, n0, replace=False),
        rng.choice(idx1, n1, replace=False),
    ])
    rng.shuffle(take)
    return X[take], y[take]


# =============================================================================
# NEURAL DATA PIPELINE
# =============================================================================

def fit_streaming_standardizer(store, ids: Sequence[str], blocks: Sequence[str]):
    n = 0
    s = None
    ss = None
    for pid in ids:
        X = concat_features(store[pid], blocks).astype(np.float64)
        if s is None:
            s = np.zeros(X.shape[1], dtype=np.float64)
            ss = np.zeros(X.shape[1], dtype=np.float64)
        s += X.sum(0)
        ss += (X * X).sum(0)
        n += len(X)
    mean = s / max(n, 1)
    var = ss / max(n, 1) - mean * mean
    std = np.sqrt(np.maximum(var, 1e-8))
    return {"mean": mean.astype(np.float32), "std": std.astype(np.float32)}


class ProteinDataset(Dataset):
    def __init__(self, store, ids, blocks, scaler):
        self.store = store
        self.ids = list(ids)
        self.blocks = list(blocks)
        self.scaler = scaler

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, i):
        pid = self.ids[i]
        X = concat_features(self.store[pid], self.blocks)
        X = ((X - self.scaler["mean"]) / self.scaler["std"]).astype(np.float32)
        y = np.asarray(self.store[pid]["y"], dtype=np.int64)
        return pid, torch.from_numpy(X), torch.from_numpy(y)


def protein_collate(batch):
    pids, xs, ys = zip(*batch)
    lens = [len(y) for y in ys]
    return list(pids), torch.cat(xs, 0).float(), torch.cat(ys, 0).long(), lens


class ResidueMLP(nn.Module):
    def __init__(self, d: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d, 256),
            nn.GELU(),
            nn.LayerNorm(256),
            nn.Dropout(dropout),
            nn.Linear(256, 64),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


class ResidueKAN(nn.Module):
    def __init__(self, d: int, seed: int):
        super().__init__()
        # Same spirit as the original GEAR no-graph head: high-D representation
        # is compressed before the nonlinear KAN block.
        self.pre = nn.Linear(d, 32)
        self.kan = self._make_kan(seed)

    @staticmethod
    def _make_kan(seed: int):
        if not HAS_KAN:
            raise RuntimeError(f"KAN unavailable: {globals().get('KAN_IMPORT_ERROR', 'unknown import error')}")
        attempts = [
            lambda: KAN(width=[32, 8, 2], grid=2, k=2, seed=seed, auto_save=False),
            lambda: KAN(width=[32, 8, 2], grid=2, k=2, seed=seed),
            lambda: KAN([32, 8, 2], grid=2, k=2),
        ]
        err = None
        for fn in attempts:
            try:
                return fn()
            except TypeError as exc:
                err = exc
        raise err

    def forward(self, x):
        return self.kan(self.pre(x))


def count_params(model) -> int:
    return int(sum(p.numel() for p in model.parameters() if p.requires_grad))


@torch.no_grad()
def predict_neural(model, kind: str, store, ids, blocks, scaler, device, batch_size: int):
    loader = DataLoader(
        ProteinDataset(store, ids, blocks, scaler),
        batch_size=batch_size,
        shuffle=False,
        collate_fn=protein_collate,
        num_workers=0,
    )
    model.eval()
    ys, ps = [], []
    for _, X, y, _lens in loader:
        X = X.to(device=device, dtype=torch.float32)
        logits = model(X).float()
        if kind == "MLP":
            p = torch.sigmoid(logits)
        else:
            p = torch.softmax(logits, dim=-1)[:, 1]
        ys.append(y.numpy())
        ps.append(p.cpu().numpy())
    return np.concatenate(ys), np.concatenate(ps).astype(np.float32)


def train_neural(kind: str, store, tr_ids, va_ids, blocks, cfg: Config, seed: int, device):
    set_seed(seed)
    scaler = fit_streaming_standardizer(store, tr_ids, blocks)
    d = sum(np.asarray(store[tr_ids[0]][b]).shape[1] for b in blocks)
    if kind == "MLP":
        model = ResidueMLP(d, cfg.dropout).to(device=device, dtype=torch.float32)
        batch_size = cfg.proteins_per_batch_mlp
        posw = torch.tensor([class_pos_weight(store, tr_ids)], dtype=torch.float32, device=device)
        loss_fn = nn.BCEWithLogitsLoss(pos_weight=posw)
    elif kind == "KAN":
        model = ResidueKAN(d, seed).to(device=device, dtype=torch.float32)
        batch_size = cfg.proteins_per_batch_kan
        w = torch.tensor([1.0, class_pos_weight(store, tr_ids)], dtype=torch.float32, device=device)
        loss_fn = lambda logits, y: nn.functional.cross_entropy(logits, y.long(), weight=w)
    else:
        raise ValueError(kind)

    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    loader = DataLoader(
        ProteinDataset(store, tr_ids, blocks, scaler),
        batch_size=batch_size,
        shuffle=True,
        collate_fn=protein_collate,
        num_workers=0,
    )

    best_ap = -np.inf
    best_state = None
    best_epoch = 0
    bad = 0
    for epoch in range(1, cfg.neural_epochs + 1):
        model.train()
        for _, X, y, _ in loader:
            X = X.to(device=device, dtype=torch.float32)
            y = y.to(device=device)
            opt.zero_grad(set_to_none=True)
            logits = model(X).float()
            loss = loss_fn(logits, y.float() if kind == "MLP" else y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step()
        yv, pv = predict_neural(model, kind, store, va_ids, blocks, scaler, device, batch_size)
        ap = average_precision_score(yv, pv)
        if ap > best_ap + 1e-4:
            best_ap = float(ap)
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            bad = 0
        else:
            bad += 1
            if bad >= cfg.neural_patience:
                break
    if best_state is None:
        raise RuntimeError(f"{kind}: no valid checkpoint")
    model.load_state_dict(best_state)
    return model, scaler, {"best_epoch": best_epoch, "best_val_auprc": best_ap, "n_params": count_params(model)}


# =============================================================================
# XGBOOST
# =============================================================================

def train_xgboost(store, tr_ids, va_ids, blocks, cfg: Config, seed: int, device):
    Xtr, ytr = matrix_from_store(store, tr_ids, blocks)
    Xv, yv = matrix_from_store(store, va_ids, blocks)
    Xtr, ytr = stratified_cap(Xtr, ytr, cfg.xgb_train_max_residues, seed)
    scale_pos = float(np.clip((len(ytr) - int(ytr.sum())) / max(int(ytr.sum()), 1), 1.0, 30.0))
    kwargs = dict(
        n_estimators=cfg.xgb_estimators,
        max_depth=cfg.xgb_depth,
        learning_rate=cfg.xgb_lr,
        subsample=cfg.xgb_subsample,
        colsample_bytree=cfg.xgb_colsample,
        min_child_weight=cfg.xgb_min_child_weight,
        reg_lambda=cfg.xgb_reg_lambda,
        scale_pos_weight=scale_pos,
        eval_metric="aucpr",
        tree_method="hist",
        max_bin=cfg.xgb_max_bin,
        random_state=seed,
        n_jobs=-1,
        early_stopping_rounds=cfg.xgb_patience,
    )
    if device.type == "cuda":
        kwargs["device"] = "cuda"
    model = xgb.XGBClassifier(**kwargs)
    model.fit(Xtr, ytr, eval_set=[(Xv, yv)], verbose=False)
    meta = {
        "best_epoch": int(getattr(model, "best_iteration", cfg.xgb_estimators - 1)) + 1,
        "best_val_auprc": float(average_precision_score(yv, model.predict_proba(Xv)[:, 1])),
        "n_params": np.nan,
        "xgb_train_rows": int(len(ytr)),
    }
    del Xtr, ytr, Xv, yv
    gc.collect()
    return model, None, meta


def predict_xgboost(model, store, ids, blocks):
    X, y = matrix_from_store(store, ids, blocks)
    p = model.predict_proba(X)[:, 1].astype(np.float32)
    del X
    gc.collect()
    return y, p


# =============================================================================
# TRAIN / PREDICT ONE JOB
# =============================================================================

def get_fold_train_val_ids(fold_idx: int, fold_ids, train_store):
    va = [p for p in fold_ids[fold_idx] if p in train_store]
    vs = set(va)
    tr = [p for p in train_store if p not in vs]
    return tr, va


def job_pred_path(paths, model_name: str, rep_name: str, fold: int) -> Path:
    safe_rep = rep_name.replace("+", "__")
    return paths["pred_root"] / f"{model_name}__{safe_rep}__fold{fold+1}.pkl"


def job_model_path(paths, model_name: str, rep_name: str, fold: int) -> Path:
    safe_rep = rep_name.replace("+", "__")
    ext = ".json" if model_name == "XGBoost" else ".pt"
    return paths["model_root"] / f"{model_name}__{safe_rep}__fold{fold+1}{ext}"


def append_row_csv(row: dict, path: Path, unique_keys: Sequence[str]):
    if path.exists():
        df = pd.read_csv(path)
        mask = np.ones(len(df), dtype=bool)
        for k in unique_keys:
            if k in df.columns:
                mask &= df[k].astype(str).eq(str(row[k])).to_numpy()
            else:
                mask &= False
        df = df[~mask]
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    else:
        df = pd.DataFrame([row])
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False)
    tmp.replace(path)


def run_one_job(model_name, rep_name, blocks, fold, fold_ids, stores, paths, cfg, run_hash, device):
    pred_path = job_pred_path(paths, model_name, rep_name, fold)
    metrics_path = paths["run_root"] / "fold_metrics.csv"

    # Strict resume: skip only if prediction artifact has matching config hash.
    if pred_path.exists():
        try:
            old = load_pickle(pred_path)
            if old.get("config_hash") == run_hash:
                print(f"SKIP completed: {model_name} | {rep_name} | fold {fold+1}")
                return "skipped"
        except Exception:
            pass

    tr_ids, va_ids = get_fold_train_val_ids(fold, fold_ids, stores["train"])
    seed = cfg.seed + fold + 1000 * {"MLP": 1, "KAN": 2, "XGBoost": 3}[model_name]
    print(f"RUN {model_name} | {rep_name} | fold {fold+1}/5 | train={len(tr_ids)} val={len(va_ids)}")
    t0 = time.time()

    if model_name in ("MLP", "KAN"):
        model, scaler, meta = train_neural(model_name, stores["train"], tr_ids, va_ids, blocks, cfg, seed, device)
        yv, pv = predict_neural(
            model, model_name, stores["train"], va_ids, blocks, scaler, device,
            cfg.proteins_per_batch_mlp if model_name == "MLP" else cfg.proteins_per_batch_kan,
        )
        y300, p300 = predict_neural(
            model, model_name, stores["test300"], list(stores["test300"]), blocks, scaler, device,
            cfg.proteins_per_batch_mlp if model_name == "MLP" else cfg.proteins_per_batch_kan,
        )
        y46, p46 = predict_neural(
            model, model_name, stores["test46"], list(stores["test46"]), blocks, scaler, device,
            cfg.proteins_per_batch_mlp if model_name == "MLP" else cfg.proteins_per_batch_kan,
        )
        if cfg.save_models:
            torch.save({
                "state_dict": model.state_dict(),
                "scaler": scaler,
                "blocks": list(blocks),
                "config_hash": run_hash,
                "meta": meta,
            }, job_model_path(paths, model_name, rep_name, fold))
        del model, scaler
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    elif model_name == "XGBoost":
        model, _scaler, meta = train_xgboost(stores["train"], tr_ids, va_ids, blocks, cfg, seed, device)
        yv, pv = predict_xgboost(model, stores["train"], va_ids, blocks)
        y300, p300 = predict_xgboost(model, stores["test300"], list(stores["test300"]), blocks)
        y46, p46 = predict_xgboost(model, stores["test46"], list(stores["test46"]), blocks)
        if cfg.save_models:
            model.save_model(job_model_path(paths, model_name, rep_name, fold))
        del model
    else:
        raise ValueError(model_name)

    mf = binary_metrics(yv, pv, cfg.fixed_threshold)
    fold_thr = choose_f1_threshold(yv, pv)
    mt = binary_metrics(yv, pv, fold_thr)
    elapsed = time.time() - t0
    row = {
        "config_hash": run_hash,
        "model": model_name,
        "representation": rep_name,
        "blocks": "+".join(blocks),
        "fold": fold + 1,
        "n_train_proteins": len(tr_ids),
        "n_val_proteins": len(va_ids),
        "n_val_residues": len(yv),
        "val_positive_residues": int(yv.sum()),
        "AUPRC": mf["auprc"],
        "AUROC": mf["auroc"],
        "F1_at_0.5": mf["f1"],
        "MCC_at_0.5": mf["mcc"],
        "fold_tuned_threshold": fold_thr,
        "F1_at_fold_tuned": mt["f1"],
        "MCC_at_fold_tuned": mt["mcc"],
        "best_epoch": meta.get("best_epoch", np.nan),
        "best_val_auprc": meta.get("best_val_auprc", np.nan),
        "n_params": meta.get("n_params", np.nan),
        "xgb_train_rows": meta.get("xgb_train_rows", np.nan),
        "seconds": elapsed,
    }
    append_row_csv(row, metrics_path, ["config_hash", "model", "representation", "fold"])

    save_pickle({
        "config_hash": run_hash,
        "model": model_name,
        "representation": rep_name,
        "blocks": list(blocks),
        "fold": fold + 1,
        "val_ids": va_ids,
        "val_y": np.asarray(yv, dtype=np.int8),
        "val_p": np.asarray(pv, dtype=np.float32),
        "test300_y": np.asarray(y300, dtype=np.int8),
        "test300_p": np.asarray(p300, dtype=np.float32),
        "test46_y": np.asarray(y46, dtype=np.int8),
        "test46_p": np.asarray(p46, dtype=np.float32),
        "fold_tuned_threshold": fold_thr,
        "meta": meta,
    }, pred_path)

    print(
        f"DONE {model_name} | {rep_name} | fold {fold+1}: "
        f"AUPRC={mf['auprc']:.4f} AUROC={mf['auroc']:.4f} "
        f"F1@0.5={mf['f1']:.4f} ({elapsed/60:.1f} min)"
    )
    gc.collect()
    return "done"


# =============================================================================
# AGGREGATION / REPORTS
# =============================================================================

def paired_fold_effect(df: pd.DataFrame, model: str, better: str, reference: str, metric="AUPRC"):
    a = df[(df.model == model) & (df.representation == better)].set_index("fold")[metric]
    b = df[(df.model == model) & (df.representation == reference)].set_index("fold")[metric]
    common = a.index.intersection(b.index)
    d = (a.loc[common] - b.loc[common]).to_numpy(float)
    if not len(d):
        return None
    mean = float(d.mean())
    sd = float(d.std(ddof=1)) if len(d) > 1 else np.nan
    half = float(student_t.ppf(0.975, len(d)-1) * sd / np.sqrt(len(d))) if len(d) > 1 else np.nan
    return {
        "model": model,
        "comparison": f"{better} - {reference}",
        "metric": metric,
        "mean_delta": mean,
        "ci95_low": mean - half if np.isfinite(half) else np.nan,
        "ci95_high": mean + half if np.isfinite(half) else np.nan,
        "positive_folds": int((d > 0).sum()),
        "n_folds": len(d),
        "fold_deltas": json.dumps(d.tolist()),
    }


def aggregate_reports(paths, stores, representations, cfg: Config, run_hash: str):
    metrics_path = paths["run_root"] / "fold_metrics.csv"
    if not metrics_path.exists():
        print("No fold metrics yet.")
        return
    fold_df = pd.read_csv(metrics_path)
    fold_df = fold_df[fold_df.config_hash.astype(str) == str(run_hash)].copy()
    if fold_df.empty:
        print("No metrics matching current config hash.")
        return

    cv_summary = (
        fold_df.groupby(["model", "representation"], as_index=False)
        .agg(
            folds=("fold", "nunique"),
            CV_AUPRC=("AUPRC", "mean"),
            CV_AUPRC_SD=("AUPRC", "std"),
            CV_AUROC=("AUROC", "mean"),
            CV_F1_at_0_5=("F1_at_0.5", "mean"),
            CV_MCC_at_0_5=("MCC_at_0.5", "mean"),
            mean_best_epoch=("best_epoch", "mean"),
            n_params=("n_params", "mean"),
            mean_seconds=("seconds", "mean"),
        )
        .sort_values(["model", "CV_AUPRC"], ascending=[True, False])
    )
    cv_summary.to_csv(paths["run_root"] / "cv_summary.csv", index=False)

    # Paired effects, primary metric = AUPRC.
    paired_rows = []
    for model in cfg.models:
        for better, reference, _question in PAIRED_COMPARISONS:
            if better in representations and reference in representations:
                z = paired_fold_effect(fold_df, model, better, reference, "AUPRC")
                if z is not None:
                    z["question"] = _question
                    paired_rows.append(z)
    paired_df = pd.DataFrame(paired_rows)
    paired_df.to_csv(paths["run_root"] / "paired_AUPRC_effects.csv", index=False)

    ext_rows = []
    for model in cfg.models:
        for rep_name in representations:
            preds = []
            complete = True
            for fold in range(5):
                pp = job_pred_path(paths, model, rep_name, fold)
                if not pp.exists():
                    complete = False
                    break
                z = load_pickle(pp)
                if z.get("config_hash") != run_hash:
                    complete = False
                    break
                preds.append(z)
            if not complete:
                continue

            # OOF threshold uses DevSet1010 only.
            oof_y = np.concatenate([np.asarray(z["val_y"], dtype=np.int64) for z in preds])
            oof_p = np.concatenate([np.asarray(z["val_p"], dtype=float) for z in preds])
            oof_thr = choose_f1_threshold(oof_y, oof_p)
            fold_thr_mean = float(np.mean([z["fold_tuned_threshold"] for z in preds]))

            p300 = np.mean(np.stack([np.asarray(z["test300_p"], dtype=float) for z in preds]), axis=0)
            p46 = np.mean(np.stack([np.asarray(z["test46_p"], dtype=float) for z in preds]), axis=0)
            y300 = np.asarray(preds[0]["test300_y"], dtype=np.int64)
            y46 = np.asarray(preds[0]["test46_y"], dtype=np.int64)

            for dname, store, ids, y, p in [
                ("TestSet300", stores["test300"], list(stores["test300"]), y300, p300),
                ("TestSetNew46", stores["test46"], list(stores["test46"]), y46, p46),
            ]:
                m05 = binary_metrics(y, p, cfg.fixed_threshold)
                moof = binary_metrics(y, p, oof_thr)
                mmean = binary_metrics(y, p, fold_thr_mean)
                macro05 = macro_positive_metrics(store, ids, p, cfg.fixed_threshold)
                macro_oof = macro_positive_metrics(store, ids, p, oof_thr)
                ext_rows.append({
                    "model": model,
                    "representation": rep_name,
                    "dataset": dname,
                    "n_residues": len(y),
                    "positive_residues": int(y.sum()),
                    "AUPRC": m05["auprc"],
                    "AUROC": m05["auroc"],
                    "F1_at_0.5": m05["f1"],
                    "MCC_at_0.5": m05["mcc"],
                    "precision_at_0.5": m05["precision"],
                    "recall_at_0.5": m05["recall"],
                    "OOF_tuned_threshold": oof_thr,
                    "F1_at_OOF_threshold": moof["f1"],
                    "MCC_at_OOF_threshold": moof["mcc"],
                    "precision_at_OOF_threshold": moof["precision"],
                    "recall_at_OOF_threshold": moof["recall"],
                    "mean_fold_tuned_threshold": fold_thr_mean,
                    "F1_at_mean_fold_threshold": mmean["f1"],
                    "MCC_at_mean_fold_threshold": mmean["mcc"],
                    **{f"at_0.5_{k}": v for k, v in macro05.items()},
                    **{f"at_OOF_{k}": v for k, v in macro_oof.items()},
                })

            if cfg.save_ensemble_predictions:
                # Compact residue predictions for later error analysis.
                for dname, store, ids, y, p in [
                    ("TestSet300", stores["test300"], list(stores["test300"]), y300, p300),
                    ("TestSetNew46", stores["test46"], list(stores["test46"]), y46, p46),
                ]:
                    rows = []
                    cur = 0
                    for pid in ids:
                        n = len(store[pid]["y"])
                        seq = store[pid]["sequence"]
                        for j in range(n):
                            rows.append((pid, j, seq[j], int(y[cur+j]), float(p[cur+j])))
                        cur += n
                    safe_rep = rep_name.replace("+", "__")
                    pd.DataFrame(rows, columns=["prot_id", "residue_index", "AA", "label", "probability"]).to_csv(
                        paths["ensemble_root"] / f"{model}__{safe_rep}__{dname}.csv.gz",
                        index=False,
                        compression="gzip",
                    )

    ext_df = pd.DataFrame(ext_rows)
    ext_df.to_csv(paths["run_root"] / "external_summary.csv", index=False)

    # Automatically compare against original no_graph if its result file exists.
    old_candidates = [
        paths["base"] / "results" / "no_graph_final" / f"{cfg.label_column}_final_results.csv",
        paths["base"] / "results" / "no_graph_final" / "metal_binding_final_results.csv",
    ]
    old_path = next((p for p in old_candidates if p.exists()), None)
    if old_path is not None and not ext_df.empty:
        old = pd.read_csv(old_path)
        rows = []
        for _, r in ext_df.iterrows():
            q = old[old["dataset"].astype(str) == str(r["dataset"])]
            if q.empty:
                continue
            o = q.iloc[0]
            rows.append({
                "model": r["model"],
                "representation": r["representation"],
                "dataset": r["dataset"],
                "new_AUPRC": r["AUPRC"],
                "old_AUPRC": o.get("auprc", np.nan),
                "delta_AUPRC": r["AUPRC"] - o.get("auprc", np.nan),
                "new_AUROC": r["AUROC"],
                "old_AUROC": o.get("auroc", np.nan),
                "delta_AUROC": r["AUROC"] - o.get("auroc", np.nan),
                "new_F1_at_0.5": r["F1_at_0.5"],
                "old_F1_at_0.5": o.get("micro_f1", np.nan),
                "delta_F1_at_0.5": r["F1_at_0.5"] - o.get("micro_f1", np.nan),
                "new_MCC_at_0.5": r["MCC_at_0.5"],
                "old_MCC_at_0.5": o.get("micro_mcc", np.nan),
                "delta_MCC_at_0.5": r["MCC_at_0.5"] - o.get("micro_mcc", np.nan),
            })
        pd.DataFrame(rows).to_csv(paths["run_root"] / "vs_original_no_graph.csv", index=False)

    # Track the CV-selected winner without using external performance.
    completed_cv = cv_summary[cv_summary.folds == 5].copy()
    winners = []
    for model in cfg.models:
        q = completed_cv[completed_cv.model == model].sort_values("CV_AUPRC", ascending=False)
        if len(q):
            winners.append(q.iloc[0].to_dict())
    with open(paths["run_root"] / "cv_selected_winners.json", "w") as f:
        json.dump(winners, f, indent=2, default=str)

    print("\n=== CV SUMMARY (selection should be based here) ===")
    print(cv_summary.to_string(index=False, max_rows=100))
    if not paired_df.empty:
        print("\n=== PAIRED AUPRC EFFECTS ===")
        print(paired_df.to_string(index=False, max_rows=200))
    if not ext_df.empty:
        cols = [
            "model", "representation", "dataset", "AUPRC", "AUROC",
            "F1_at_0.5", "MCC_at_0.5", "OOF_tuned_threshold",
            "F1_at_OOF_threshold", "MCC_at_OOF_threshold",
        ]
        print("\n=== EXTERNAL SUMMARY ===")
        print(ext_df[cols].sort_values(["dataset", "model", "AUPRC"], ascending=[True, True, False]).to_string(index=False, max_rows=300))


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=Config.base)
    parser.add_argument("--label", default=Config.label_column, choices=LABEL_COLUMNS)
    parser.add_argument("--preset", default="full", choices=["full", "core"])
    parser.add_argument("--models", nargs="+", default=["MLP", "KAN", "XGBoost"], choices=["MLP", "KAN", "XGBoost"])
    parser.add_argument("--features-only", action="store_true", help="Build/reuse ATOM/CHEM caches and stop")
    parser.add_argument("--aggregate-only", action="store_true", help="Do not train; rebuild summaries from completed jobs")
    parser.add_argument("--save-models", action="store_true")
    args = parser.parse_args()

    cfg = Config(
        base=args.base,
        label_column=args.label,
        preset=args.preset,
        models=tuple(args.models),
        save_models=args.save_models,
    )
    if cfg.label_column != "metal_binding":
        print(
            "WARNING: ATOM/CHEM v1 are metal-coordination-inspired features. "
            f"You selected {cfg.label_column}. Treat this as a specificity/control experiment, "
            "not as a task-optimized chemistry descriptor."
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.set_float32_matmul_precision("high")
    print("DEVICE:", device)
    print("Torch:", torch.__version__)
    print("XGBoost:", xgb.__version__)
    print("KAN available:", HAS_KAN)
    if "KAN" in cfg.models and not HAS_KAN:
        print("KAN import error:", globals().get("KAN_IMPORT_ERROR"))
        raise RuntimeError("KAN requested but pykan is unavailable")

    paths = make_paths(cfg)
    for k in ["train_csv", "test300_csv", "test46_csv"]:
        if not paths[k].exists():
            raise FileNotFoundError(paths[k])

    representations = FULL_REPRESENTATIONS if cfg.preset == "full" else CORE_REPRESENTATIONS
    run_hash = config_hash(cfg, representations)
    print("RUN HASH:", run_hash)
    print("RUN ROOT:", paths["run_root"])
    print("Preset:", cfg.preset, "| representations:", len(representations), "| models:", cfg.models)
    print("Planned fits:", len(representations) * len(cfg.models) * 5)

    # Manifest makes accidental protocol drift obvious.
    manifest = {
        "config_hash": run_hash,
        "config": asdict(cfg),
        "representations": representations,
        "ATOM_feature_names": ATOM_GEOM_FEATURE_NAMES,
        "CHEM_feature_names": CHEM_FEATURE_NAMES,
        "notes": [
            "Primary representation/model selection: DevSet1010 CV AUPRC.",
            "External Test300/Test46: confirmation/reporting only; do not tune against them.",
            "F1/MCC@0.5 retained for benchmark compatibility.",
            "OOF-selected threshold is derived only from DevSet1010 and locked for external evaluation.",
            "Existing feature caches are reused; older model result CSVs are not reused unless config hash matches this runner.",
        ],
    }
    with open(paths["run_root"] / "experiment_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2, default=str)

    train_df = load_frame(paths["train_csv"])
    test300_df = load_frame(paths["test300_csv"])
    test46_df = load_frame(paths["test46_csv"])
    fold_ids = load_bindnode24_folds()
    official = set().union(*map(set, fold_ids))
    train_df = train_df[train_df.prot_id.isin(official)].reset_index(drop=True)

    # Validate one-to-one official universe.
    assignments = pd.Series([p for f in fold_ids for p in f]).value_counts()
    if not (assignments == 1).all():
        raise ValueError("Official fold IDs are not a one-to-one partition")
    if len(train_df) != len(official):
        missing = sorted(official - set(train_df.prot_id))
        raise ValueError(f"DevSet1010 missing official IDs: {missing[:20]}")

    for split, df in [("DevSet1010", train_df), ("TestSet300", test300_df), ("TestSetNew46", test46_df)]:
        bad = df.apply(lambda r: len(r["sequence"]) != len(r[cfg.label_column]), axis=1)
        if bad.any():
            raise ValueError(f"{split}: {int(bad.sum())} sequence/label length mismatches")
        print(split, "proteins=", len(df))

    # Reuse/build ATOM and CHEM caches.
    train_atom, train_chem = ensure_atom_chem_caches(train_df, "DevSet1010", paths, cfg)
    t300_atom, t300_chem = ensure_atom_chem_caches(test300_df, "TestSet300", paths, cfg)
    t46_atom, t46_chem = ensure_atom_chem_caches(test46_df, "TestSetNew46", paths, cfg)

    if args.features_only:
        print("Feature-cache step complete.")
        return

    stores = {
        "train": build_store(train_df, "DevSet1010", paths, cfg, train_atom, train_chem),
        "test300": build_store(test300_df, "TestSet300", paths, cfg, t300_atom, t300_chem),
        "test46": build_store(test46_df, "TestSetNew46", paths, cfg, t46_atom, t46_chem),
    }
    for name, st in stores.items():
        print(
            name,
            "proteins=", len(st),
            "residues=", sum(len(v["y"]) for v in st.values()),
            "positives=", sum(int(v["y"].sum()) for v in st.values()),
        )

    # Feature dimension audit.
    probe = next(iter(stores["train"].values()))
    dims = {k: int(np.asarray(probe[k]).shape[1]) for k in ["AA", "ESM", "SPATIAL", "LOCAL", "ATOM", "CHEM"]}
    print("Feature dimensions:", dims)
    if dims["ESM"] != 1280 or dims["ATOM"] != 15 or dims["CHEM"] != 24:
        raise ValueError(f"Unexpected feature dimensions: {dims}")

    if not args.aggregate_only:
        errors_path = paths["run_root"] / "errors.csv"
        for model_name in cfg.models:
            for rep_name, blocks in representations.items():
                for fold in range(5):
                    try:
                        run_one_job(
                            model_name, rep_name, blocks, fold, fold_ids,
                            stores, paths, cfg, run_hash, device,
                        )
                    except Exception as exc:
                        row = {
                            "config_hash": run_hash,
                            "model": model_name,
                            "representation": rep_name,
                            "fold": fold + 1,
                            "error": repr(exc),
                            "traceback": traceback.format_exc(),
                        }
                        append_row_csv(row, errors_path, ["config_hash", "model", "representation", "fold"])
                        print("ERROR:", row["model"], row["representation"], row["fold"], row["error"])
                    gc.collect()
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()

    aggregate_reports(paths, stores, representations, cfg, run_hash)
    print("\nALL DONE / CURRENT PROGRESS AGGREGATED")
    print("Results:", paths["run_root"])


if __name__ == "__main__":
    main()
