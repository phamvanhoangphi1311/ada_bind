"""Base feature cache construction for GEAR Ultimate.

Creates/reuses:
- ESM2-t33 mean(last two hidden layers): 1280-d per residue
- AA: 20-d one-hot
- SPATIAL: 112-d explicit 3D microenvironment
- LOCAL: 8-d DSSP/torsion/exposure

The structural extractor follows the patched spatial-revamp notebook, including
PDB/CSV alignment checks and the v2 local-feature cache.
"""
from __future__ import annotations
import gc, pickle
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from Bio import PDB
from Bio.SeqUtils import seq1
from scipy.spatial import cKDTree
from tqdm.auto import tqdm
from . import gear_core as core

ESM_MODEL = "facebook/esm2_t33_650M_UR50D"
ESM_LAST_N_LAYERS = 2
SHELL_EDGES = [0.0, 4.0, 6.0, 8.0, 10.0]
SPATIAL_MAX_RADIUS = SHELL_EDGES[-1]
LONG_RANGE_SEQ_SEP = 12
NEAREST_DISTANCE_CAP = 12.0

AA_FEATURE_NAMES = [f"focal_AA_{a}" for a in core.AA20]
SHELL_PAIRS = list(zip(SHELL_EDGES[:-1], SHELL_EDGES[1:]))
SPATIAL_FEATURE_NAMES = []
for lo, hi in SHELL_PAIRS:
    SPATIAL_FEATURE_NAMES += [f"n_{a}_{lo:g}_{hi:g}A" for a in core.AA20]
    SPATIAL_FEATURE_NAMES += [f"n_total_{lo:g}_{hi:g}A", f"n_longrange_{lo:g}_{hi:g}A"]
SPATIAL_FEATURE_NAMES += [f"nearest_{a}_A" for a in core.AA20]
SPATIAL_FEATURE_NAMES += ["neighbor_mean_distance", "neighbor_std_distance", "neighbor_mean_seqsep", "neighbor_max_seqsep"]
LOCAL_FEATURE_NAMES = ["SS_H","SS_E","SS_C","sin_phi","cos_phi","sin_psi","cos_psi","rel_sasa_proxy"]
assert len(SPATIAL_FEATURE_NAMES) == 112
assert len(LOCAL_FEATURE_NAMES) == 8


def safe_seq1(resname):
    try:
        x = seq1(str(resname))
        return x if x in core.AA_TO_IDX else "X"
    except Exception:
        return "X"


def parse_residues_and_coords(pdb_path, n_keep):
    parser = PDB.PDBParser(QUIET=True)
    structure = parser.get_structure(Path(pdb_path).stem, str(pdb_path))
    model = next(structure.get_models())
    aa, ca, cb = [], [], []
    for chain in model:
        for res in chain:
            if res.id[0] != " " or "CA" not in res:
                continue
            aa.append(safe_seq1(res.resname))
            ca_coord = np.asarray(res["CA"].coord, dtype=np.float32)
            ca.append(ca_coord)
            cb.append(np.asarray(res["CB"].coord, dtype=np.float32) if "CB" in res else ca_coord.copy())
            if len(aa) >= n_keep:
                break
        if len(aa) >= n_keep:
            break
    return "".join(aa), np.asarray(ca,np.float32), np.asarray(cb,np.float32)


def focal_aa_onehot(seq):
    x = np.zeros((len(seq),20), dtype=np.float32)
    for i,a in enumerate(seq):
        if a in core.AA_TO_IDX:
            x[i,core.AA_TO_IDX[a]] = 1.0
    return x


def spatial_microenvironment(seq_struct, cb):
    n = len(seq_struct)
    out = np.zeros((n,len(SPATIAL_FEATURE_NAMES)), dtype=np.float32)
    if n == 0:
        return out
    tree = cKDTree(cb)
    shell_block = 22
    nearest_offset = len(SHELL_PAIRS)*shell_block
    summary_offset = nearest_offset + 20
    for i in range(n):
        nbrs = [j for j in tree.query_ball_point(cb[i], r=SPATIAL_MAX_RADIUS) if j != i]
        if not nbrs:
            out[i,nearest_offset:nearest_offset+20] = NEAREST_DISTANCE_CAP
            continue
        idx = np.asarray(nbrs,dtype=np.int32)
        dists = np.linalg.norm(cb[idx]-cb[i],axis=1)
        seqseps = np.abs(idx-i)
        for sidx,(lo,hi) in enumerate(SHELL_PAIRS):
            mask = ((dists>=lo)&(dists<=hi)) if sidx == len(SHELL_PAIRS)-1 else ((dists>=lo)&(dists<hi))
            base = sidx*shell_block
            for j in idx[mask]:
                a = seq_struct[j]
                if a in core.AA_TO_IDX:
                    out[i,base+core.AA_TO_IDX[a]] += 1.0
            out[i,base+20] = float(np.sum(mask))
            out[i,base+21] = float(np.sum(seqseps[mask] >= LONG_RANGE_SEQ_SEP))
        nearest = np.full(20,NEAREST_DISTANCE_CAP,dtype=np.float32)
        for j,d in zip(idx,dists):
            a=seq_struct[j]
            if a in core.AA_TO_IDX:
                k=core.AA_TO_IDX[a]
                if d < nearest[k]: nearest[k] = min(float(d),NEAREST_DISTANCE_CAP)
        out[i,nearest_offset:nearest_offset+20] = nearest
        out[i,summary_offset+0] = float(np.mean(dists))
        out[i,summary_offset+1] = float(np.std(dists))
        out[i,summary_offset+2] = float(np.mean(seqseps))
        out[i,summary_offset+3] = float(np.max(seqseps))
    return out


def local_structure_features(pdb_path, n_keep):
    import mdtraj as md
    traj = md.load(str(pdb_path))
    all_res = list(traj.topology.residues)
    protein_res = []
    for r in all_res:
        atoms = list(r.atoms)
        has_ca = any(a.name == "CA" for a in atoms)
        is_protein = getattr(r,"is_protein",has_ca)
        if is_protein and has_ca:
            protein_res.append(r)
    n = min(n_keep,len(protein_res))
    if n == 0:
        raise ValueError(f"No protein residues found by MDTraj in {pdb_path}")
    protein_res = protein_res[:n]
    topres_to_row = {r.index:i for i,r in enumerate(protein_res)}
    out = np.zeros((n,8),dtype=np.float32)
    dssp = md.compute_dssp(traj,simplified=True)[0]
    ss_map={"H":0,"E":1,"C":2,"NA":2}
    for row,r in enumerate(protein_res):
        s = str(dssp[r.index]) if r.index < len(dssp) else "C"
        out[row,ss_map.get(s,2)] = 1.0
    phi_idx,phi_val = md.compute_phi(traj)
    psi_idx,psi_val = md.compute_psi(traj)
    if phi_val.size:
        for k,q in enumerate(phi_idx):
            ri = traj.topology.atom(int(q[1])).residue.index
            if ri in topres_to_row:
                row=topres_to_row[ri]; angle=float(phi_val[0,k]); out[row,3]=np.sin(angle); out[row,4]=np.cos(angle)
    if psi_val.size:
        for k,q in enumerate(psi_idx):
            ri = traj.topology.atom(int(q[0])).residue.index
            if ri in topres_to_row:
                row=topres_to_row[ri]; angle=float(psi_val[0,k]); out[row,5]=np.sin(angle); out[row,6]=np.cos(angle)
    sasa_all = md.shrake_rupley(traj,mode="residue")[0]
    max_asa={"A":1.29,"R":2.74,"N":1.95,"D":1.93,"C":1.67,"E":2.23,"Q":2.25,"G":1.04,"H":2.24,"I":1.97,"L":2.01,"K":2.36,"M":2.24,"F":2.40,"P":1.59,"S":1.55,"T":1.72,"W":2.85,"Y":2.63,"V":1.74}
    md_seq="".join(safe_seq1(r.name) for r in protein_res)
    sasa=np.asarray([sasa_all[r.index] for r in protein_res],dtype=np.float32)
    denom=np.asarray([max_asa.get(a,2.0) for a in md_seq],dtype=np.float32)
    out[:,7]=np.clip(sasa/np.maximum(denom,1e-6),0.0,2.0)
    return out


def ensure_esm_cache(df, split: str, paths, cfg, device=None, batch_size=8, model_name=ESM_MODEL):
    """Create/reuse the standardized fp16 ESM2 t33 mean-last-two cache."""
    from transformers import EsmModel, EsmTokenizer
    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    path = core.esm_cache_file(paths["cache"],split)
    expected = {str(r.prot_id):str(r.sequence)[:cfg.max_residues] for r in df.itertuples()}
    if path.exists():
        store=core.load_pickle(path)
        if set(store)==set(expected) and all(np.asarray(store[p]).shape == (len(expected[p]),1280) for p in expected):
            print(f"[{split}] Reused ESM cache: {path.name}")
            return store
        print(f"[{split}] ESM cache incompatible; rebuilding: {path.name}")
    tok=EsmTokenizer.from_pretrained(model_name)
    model=EsmModel.from_pretrained(model_name,output_hidden_states=True).to(device).eval()
    items=list(expected.items()); store={}
    for start in tqdm(range(0,len(items),batch_size),desc=f"ESM {split}"):
        batch=items[start:start+batch_size]; seqs=[s for _,s in batch]
        t=tok(seqs,return_tensors="pt",padding=True,truncation=True,max_length=cfg.max_residues+2).to(device)
        with torch.inference_mode():
            hidden=model(**t).hidden_states
            h=torch.stack(hidden[-2:],dim=0).mean(0)
        for bi,(pid,seq) in enumerate(batch):
            # Use the known sequence length, excluding BOS/EOS.
            arr=h[bi,1:len(seq)+1].float().cpu().numpy().astype(np.float16)
            if arr.shape != (len(seq),1280): raise ValueError(f"{pid}: ESM alignment mismatch {arr.shape}")
            store[pid]=arr
        del t,hidden,h
    del model; gc.collect()
    if torch.cuda.is_available(): torch.cuda.empty_cache()
    core.save_pickle(store,path); print("Saved:",path)
    return store


def ensure_structure_cache(df, split: str, paths, cfg):
    path = paths["cache"] / f"{split}_spatial_local_v2.pkl"
    expected_ids=set(df.prot_id.astype(str))
    if path.exists():
        try:
            st=core.load_pickle(path)
            ok=(set(st)==expected_ids and all(np.asarray(v["AA"]).shape[1]==20 and np.asarray(v["SPATIAL"]).shape[1]==112 and np.asarray(v["LOCAL"]).shape[1]==8 for v in st.values()))
            if ok:
                print(f"[{split}] Reused structure cache: {path.name}")
                return st
        except Exception as exc:
            print("Structure cache load failed:",repr(exc))
    store={}; mismatch=[]
    for row in tqdm(df.itertuples(),total=len(df),desc=f"3D {split}"):
        pid=str(row.prot_id); seq=str(row.sequence)[:cfg.max_residues]
        pdb=core.resolve_predicted_pdb(paths["base"],pid,split)
        seq_struct,ca,cb=parse_residues_and_coords(pdb,len(seq))
        if not seq_struct: raise ValueError(f"{pid}: no residues parsed")
        nc=min(len(seq),len(seq_struct))
        ident=float(np.mean([a==b for a,b in zip(seq[:nc],seq_struct[:nc])])) if nc else 0.0
        if len(seq_struct)!=len(seq) or ident<0.98:
            mismatch.append((pid,len(seq),len(seq_struct),ident,str(pdb)))
        n=min(len(seq),len(seq_struct))
        aa=focal_aa_onehot(seq[:n]); spatial=spatial_microenvironment(seq_struct[:n],cb[:n]); local=local_structure_features(pdb,n)
        n2=min(n,len(local))
        store[pid]={"AA":aa[:n2].astype(np.float32),"SPATIAL":spatial[:n2].astype(np.float32),"LOCAL":local[:n2].astype(np.float32),"n":int(n2),"sequence_identity_to_csv":ident,"csv_length":len(seq),"pdb_length":len(seq_struct),"pdb_path":str(pdb)}
    if mismatch:
        mdf=pd.DataFrame(mismatch,columns=["prot_id","csv_length","pdb_length","sequence_identity","pdb_path"])
        report=paths["run_root"]/f"{split}_PDB_alignment_issues.csv"; mdf.to_csv(report,index=False)
        severe=mdf[mdf.sequence_identity<0.95]
        if len(severe): raise ValueError(f"{split}: {len(severe)} PDB/CSV alignments <95%; see {report}")
    core.save_pickle(store,path); print("Saved:",path)
    return store


def ensure_base_caches(frames, paths, cfg, device=None, esm_batch_size=8):
    """Ensure ESM + structure caches for train/test300/test46 from scratch."""
    names={"train":"DevSet1010","test300":"TestSet300","test46":"TestSetNew46"}
    for key,split in names.items():
        ensure_esm_cache(frames[key],split,paths,cfg,device=device,batch_size=esm_batch_size)
        ensure_structure_cache(frames[key],split,paths,cfg)
