"""Exact historical GEAR no_graph KAN baseline.

This preserves the original protocol separately from the later standardized suite:
- ESM2 t33 1280-d mean of last two hidden layers
- DSSP H/E/C + raw phi + raw psi => 1285 node dimensions
- Linear(1285,32) -> KAN([32,8,2], grid=2, k=2)
- weighted focal cross-entropy + label-aware spatial smoothness
- fixed threshold 0.5
- early stopping on validation micro F1@0.5

Important: although classifier forward has no graph message passing, the historical loss
uses C-alpha edges and same-class labels for the smoothness term. It must therefore be
reported as the historical protocol, not as a strictly structure-free/no-graph training control.
"""
from __future__ import annotations
import gc, os, pickle, random
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from Bio import PDB
from Bio.SeqUtils import seq1
from scipy.stats import t as student_t
from sklearn.metrics import average_precision_score, roc_auc_score
from tqdm.auto import tqdm
from . import gear_core as core

@dataclass
class HistoricalConfig:
    base: str = "/content/drive/MyDrive/Protein-binding"
    label_column: str = "metal_binding"
    max_residues: int = 1000
    esm_model: str = "facebook/esm2_t33_650M_UR50D"
    esm_last_n_layers: int = 2
    esm_batch_size: int = 16
    smoothness_cutoff: float = 17.0
    kmax: int = 64
    seed: int = 15
    num_epochs: int = 50
    batch_size: int = 64
    lr: float = 1e-4
    weight_decay: float = 0.015
    pos_weight: float = 9.0
    position_weight: float = 1.5
    focal_gamma: float = 2.0
    grad_clip: float = 1.0
    patience: int = 10
    early_stop_delta: float = 0.01
    fixed_threshold: float = 0.5


def _seed(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); os.environ["PYTHONHASHSEED"]=str(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic=True; torch.backends.cudnn.benchmark=False


def historical_paths(cfg):
    base=Path(cfg.base)
    out={"base":base,"train_csv":base/"data/development_set/full_grouped_train_binding_sites_df.csv","test300_csv":base/"data/development_set/full_grouped_test_binding_sites_df.csv","test46_csv":base/"data/independent_set/grouped_test_46_new_binding_sites.csv","pdb":base/"esmFold_pdb_files","cache":base/"cache/no_graph_final","models":base/"trained_models/no_graph_final","results":base/"results/no_graph_final"}
    for k in ("cache","models","results"): out[k].mkdir(parents=True,exist_ok=True)
    return out


def compute_or_load_embeddings(frame, split_name, cfg, paths, device):
    from transformers import EsmModel,EsmTokenizer
    p=paths["cache"]/f"{split_name}_esm2_t33_last{cfg.esm_last_n_layers}.pkl"
    expected={str(r.prot_id):str(r.sequence)[:cfg.max_residues] for r in frame.itertuples()}
    if p.exists():
        z=pickle.load(open(p,"rb"))
        if set(z)==set(expected) and all(len(z[k])==len(expected[k]) for k in expected):
            print("loaded historical embedding cache:",p.name); return z
    tok=EsmTokenizer.from_pretrained(cfg.esm_model); model=EsmModel.from_pretrained(cfg.esm_model).to(device).eval(); out={}
    records=list(expected.items())
    for s in tqdm(range(0,len(records),cfg.esm_batch_size),desc=f"historical ESM [{split_name}]"):
        batch=records[s:s+cfg.esm_batch_size]; ids=[x[0] for x in batch]; seqs=[x[1] for x in batch]
        t=tok(seqs,padding=True,truncation=True,max_length=cfg.max_residues+2,return_tensors="pt")
        input_ids=t["input_ids"].to(device); mask=t["attention_mask"].to(device)
        with torch.inference_mode():
            hidden=model(input_ids=input_ids,attention_mask=mask,output_hidden_states=True).hidden_states
            emb=torch.stack(hidden[-cfg.esm_last_n_layers:]).mean(0)
        for bi,(pid,seq) in enumerate(zip(ids,seqs)):
            valid=emb[bi][mask[bi].bool()]; arr=valid[1:-1]
            if len(arr)!=len(seq): raise ValueError(f"ESM alignment mismatch: {pid}")
            out[pid]=arr.float().cpu().numpy()
    del model; gc.collect()
    if torch.cuda.is_available(): torch.cuda.empty_cache()
    pickle.dump(out,open(p,"wb"),protocol=pickle.HIGHEST_PROTOCOL); return out


def extract_ca_trace(pdb_file):
    structure=PDB.PDBParser(QUIET=True).get_structure(Path(pdb_file).stem,str(pdb_file)); model=next(structure.get_models())
    coords,res=[],[]
    for chain in model:
        for r in chain:
            if r.id[0]!=" " or "CA" not in r: continue
            try: aa=seq1(r.resname)
            except Exception: aa="X"
            coords.append(r["CA"].get_coord()); res.append(aa)
    return np.asarray(coords,dtype=np.float32),"".join(res)


def get_secondary_structure(pdb_file):
    import mdtraj as md
    ss=md.compute_dssp(md.load(str(pdb_file)),simplified=True)[0]; mapping={"H":0,"E":1,"C":2,"NA":2}; x=torch.zeros((len(ss),3),dtype=torch.float32)
    for i,s in enumerate(ss): x[i,mapping.get(str(s),2)]=1.0
    return x


def get_dihedral_angles(pdb_file,n_residues):
    import mdtraj as md
    tr=md.load(str(pdb_file)); _,ph=md.compute_phi(tr); _,ps=md.compute_psi(tr); phi=torch.zeros(n_residues); psi=torch.zeros(n_residues)
    if ph.size:
        v=torch.as_tensor(ph[0],dtype=torch.float32); phi[1:1+min(len(v),n_residues-1)]=v[:n_residues-1]
    if ps.size:
        v=torch.as_tensor(ps[0],dtype=torch.float32); psi[:min(len(v),n_residues-1)]=v[:n_residues-1]
    return phi[:,None],psi[:,None]


def make_smoothness_edges(coordinates,cutoff=17.0,kmax=64):
    c=torch.as_tensor(coordinates,dtype=torch.float32); n=len(c)
    if n<=1:return torch.empty((2,0),dtype=torch.long)
    d=torch.cdist(c,c); srcs,dsts=[],[]
    for dst in range(n):
        cand=torch.where((d[dst]>0)&(d[dst]<cutoff))[0]
        if cand.numel()==0:
            row=d[dst].clone(); row[dst]=torch.inf; cand=row.argmin().view(1)
        if kmax is not None and cand.numel()>kmax:
            cand=cand[torch.topk(d[dst,cand],k=kmax,largest=False).indices]
        srcs.append(cand); dsts.append(torch.full_like(cand,dst))
    return torch.stack([torch.cat(srcs),torch.cat(dsts)],dim=0).long()


def build_residue_data(frame,embeddings,split_name,cfg,paths):
    from torch_geometric.data import Data
    out=[]
    for idx,row in tqdm(list(frame.iterrows()),desc=f"historical features [{split_name}]"):
        pid=str(row["prot_id"]); seq=str(row["sequence"])[:cfg.max_residues]; labels=row[cfg.label_column][:cfg.max_residues]; pdb=paths["pdb"]/f"{pid}.pdb"
        coords,pseq=extract_ca_trace(pdb); coords=coords[:len(seq)]; pseq=pseq[:len(seq)]; emb=torch.as_tensor(embeddings[pid],dtype=torch.float32); ss=get_secondary_structure(pdb)[:len(seq)]
        lengths=[len(seq),len(labels),len(coords),len(emb),len(ss)]
        if len(set(lengths))!=1 or pseq!=seq: raise ValueError(f"alignment failure for {pid}: lengths={lengths}")
        phi,psi=get_dihedral_angles(pdb,len(seq)); x=torch.cat([emb,ss,phi,psi],dim=1); edges=make_smoothness_edges(coords,cfg.smoothness_cutoff,cfg.kmax)
        data=Data(x=x,y=torch.as_tensor(labels,dtype=torch.long),edge_index=edges); data.prot_idx=torch.tensor([idx]); data.prot_id=pid; out.append(data)
    return out


def _kan():
    try:
        from kan import KAN
    except Exception as exc:
        raise RuntimeError("pykan is required for historical KAN. pip install pykan") from exc
    return KAN

class NoGraphBindingModel(nn.Module):
    def __init__(self,node_dim):
        super().__init__(); self.pre_fc=nn.Linear(node_dim,32); self.head=_kan()([32,8,2],grid=2,k=2)
    def forward(self,batch): return self.head(self.pre_fc(batch.x))

class WeightedFocalPositionLoss(nn.Module):
    def __init__(self,pos_weight=9.0,gamma=2.0,position_weight=1.5): super().__init__(); self.pos_weight=float(pos_weight); self.gamma=float(gamma); self.position_weight=float(position_weight)
    def forward(self,logits,labels,edge_index):
        weights=torch.tensor([1.0,self.pos_weight],device=logits.device,dtype=logits.dtype); ce=F.cross_entropy(logits,labels,weight=weights,reduction="none"); true_prob=torch.softmax(logits,dim=-1).gather(1,labels[:,None]).squeeze(1); loss=(((1-true_prob)**self.gamma)*ce).mean()
        if self.position_weight>0 and edge_index.numel()>0:
            p=torch.softmax(logits,dim=-1)[:,1]; src,dst=edge_index; same=labels[src]==labels[dst]
            if same.any(): loss=loss+self.position_weight*(p[src[same]]-p[dst[same]]).pow(2).mean()
        return loss

def confusion(y,p):
    y=np.asarray(y,int); p=np.asarray(p,int); return int(((y==1)&(p==1)).sum()),int(((y==0)&(p==1)).sum()),int(((y==0)&(p==0)).sum()),int(((y==1)&(p==0)).sum())
def _metrics(y,p):
    tp,fp,tn,fn=confusion(y,p); precision=tp/(tp+fp) if tp+fp else 0.; recall=tp/(tp+fn) if tp+fn else 0.; f1=2*precision*recall/(precision+recall) if precision+recall else 0.; den=((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))**0.5; mcc=(tp*tn-fp*fn)/den if den else 0.; return {"precision":precision,"recall":recall,"f1":f1,"mcc":mcc,"accuracy":(tp+tn)/max(tp+tn+fp+fn,1)}
def bindnode95_ci(v):
    v=np.asarray(v,float); return float(student_t.ppf(.975,len(v))*np.std(v,ddof=0)/np.sqrt(len(v))) if len(v)>1 else 0.

def collect_probabilities(model,loader,device):
    labels=[]; probs=[]; groups=[]; model.eval()
    with torch.inference_mode():
        for batch in loader:
            batch=batch.to(device); p=torch.softmax(model(batch),dim=-1)[:,1]; labels.append(batch.y.cpu().numpy()); probs.append(p.cpu().numpy()); groups.append(batch.batch.cpu().numpy())
    # batch.batch restarts per loader batch, so build global protein groups by data order separately is safer for micro only.
    return np.concatenate(labels),np.concatenate(probs)


def train_one_fold(training_data,validation_data,node_dim,cfg,device):
    from torch_geometric.loader import DataLoader
    model=NoGraphBindingModel(node_dim).to(device); opt=torch.optim.AdamW(model.parameters(),lr=cfg.lr,weight_decay=cfg.weight_decay); crit=WeightedFocalPositionLoss(cfg.pos_weight,cfg.focal_gamma,cfg.position_weight)
    tr=DataLoader(training_data,batch_size=cfg.batch_size,shuffle=True); va=DataLoader(validation_data,batch_size=cfg.batch_size,shuffle=False); best=-np.inf; state=None; best_ep=0; patience=0
    for ep in range(1,cfg.num_epochs+1):
        model.train()
        for b in tr:
            b=b.to(device); opt.zero_grad(set_to_none=True); loss=crit(model(b),b.y,b.edge_index); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),cfg.grad_clip); opt.step()
        y,p=collect_probabilities(model,va,device); f1=_metrics(y,p>=cfg.fixed_threshold)["f1"]
        if f1>best+cfg.early_stop_delta:
            best=f1; best_ep=ep; state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}; patience=0
        else:
            patience+=1
            if patience>=cfg.patience: break
    model.load_state_dict(state); return model,best_ep,best


def _ensemble(models,data,cfg,device):
    from torch_geometric.loader import DataLoader
    loader=DataLoader(data,batch_size=cfg.batch_size,shuffle=False); acc=None; y=None
    for m in models:
        yy,p=collect_probabilities(m,loader,device); y=yy; acc=p if acc is None else acc+p
    return y,acc/len(models)


def _summary_from_data(data,y,p,thr):
    pred=(p>=thr).astype(int); micro=_metrics(y,pred); micro["auprc"]=float(average_precision_score(y,p)); micro["auroc"]=float(roc_auc_score(y,p))
    rows=[]; cur=0
    for d in data:
        n=len(d.y); yy=y[cur:cur+n]; pp=pred[cur:cur+n]; cur+=n; tp,fp,tn,fn=confusion(yy,pp)
        if tp+fp+fn>0: rows.append(_metrics(yy,pp))
    macro={"n_proteins":len(rows)}
    for k in ("precision","recall","f1","mcc","accuracy"):
        vals=np.asarray([r[k] for r in rows],float); macro[k]=float(vals.mean()) if len(vals) else np.nan; macro[k+"_ci95"]=bindnode95_ci(vals) if len(vals) else np.nan
    return micro,macro


def run_historical_baseline(cfg=None, device=None):
    """Run/resume the exact five-fold historical KAN protocol and external ensemble."""
    cfg=cfg or HistoricalConfig(); paths=historical_paths(cfg); device=device or torch.device("cuda" if torch.cuda.is_available() else "cpu"); _seed(cfg.seed)
    train=core.load_frame(paths["train_csv"]); t300=core.load_frame(paths["test300_csv"]); t46=core.load_frame(paths["test46_csv"]); folds=core.load_bindnode24_folds(); official=set().union(*map(set,folds)); train=train[train.prot_id.astype(str).isin(official)].reset_index(drop=True)
    embs={"train":compute_or_load_embeddings(train,"DevSet1010",cfg,paths,device),"test300":compute_or_load_embeddings(t300,"TestSet300",cfg,paths,device),"test46":compute_or_load_embeddings(t46,"TestSetNew46",cfg,paths,device)}
    data={"train":build_residue_data(train,embs["train"],"DevSet1010",cfg,paths),"test300":build_residue_data(t300,embs["test300"],"TestSet300",cfg,paths),"test46":build_residue_data(t46,embs["test46"],"TestSetNew46",cfg,paths)}; node_dim=data["train"][0].x.shape[1]
    by_id={str(train.iloc[d.prot_idx.item()].prot_id):d for d in data["train"]}; models=[]; cv=[]
    for fi,val_ids in enumerate(folds):
        ck=paths["models"]/f"{cfg.label_column}_fold{fi+1}.pt"; model=NoGraphBindingModel(node_dim).to(device)
        if ck.exists():
            z=torch.load(ck,map_location=device,weights_only=False); model.load_state_dict(z["model_state"]); best_ep=z.get("best_epoch",np.nan); best_f1=z.get("best_f1",np.nan); print("REUSE historical fold",fi+1)
        else:
            vs=[by_id[p] for p in val_ids]; s=set(val_ids); ts=[d for pid,d in by_id.items() if pid not in s]; model,best_ep,best_f1=train_one_fold(ts,vs,node_dim,cfg,device); torch.save({"model_state":model.state_dict(),"node_dim":node_dim,"best_epoch":best_ep,"best_f1":best_f1,"protocol":"historical_no_graph_KAN","config":cfg.__dict__},ck)
        models.append(model); cv.append({"fold":fi+1,"best_epoch":best_ep,"validation_micro_f1":best_f1})
    pd.DataFrame(cv).to_csv(paths["results"]/f"{cfg.label_column}_cv_results.csv",index=False)
    rows=[]
    for name,key in (("TestSet300","test300"),("TestSetNew46","test46")):
        y,p=_ensemble(models,data[key],cfg,device); micro,macro=_summary_from_data(data[key],y,p,cfg.fixed_threshold); rows.append({"dataset":name,"label":cfg.label_column,"threshold":cfg.fixed_threshold,"macro_positive_f1":macro["f1"],"macro_positive_f1_std":macro["f1_ci95"],"macro_positive_mcc":macro["mcc"],"macro_positive_mcc_std":macro["mcc_ci95"],"micro_f1":micro["f1"],"micro_mcc":micro["mcc"],"auprc":micro["auprc"],"auroc":micro["auroc"],"n_params":sum(x.numel() for x in models[0].parameters() if x.requires_grad)})
    out=pd.DataFrame(rows); out.to_csv(paths["results"]/f"{cfg.label_column}_final_results.csv",index=False); return pd.DataFrame(cv),out
