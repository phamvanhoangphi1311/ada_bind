"""GEAR Ultimate: modular metal-binding residue prediction experiments."""
__version__ = "1.0.0"
