"""MSA/Evolutionary features for GEAR Ultimate.

EVO v1 = 48 label-independent residue features:
20 AA frequencies, 20 uniform-background log odds, normalized entropy, gap fraction,
log homolog depth, focal-AA frequency, HCDE donor-group frequency, DE frequency,
HC frequency, and a has-homologs flag.

The public ColabFold/MMseqs2 server is rate-limited. The runner therefore uses small
resume-safe batches and never deletes completed A3M outputs.
"""
from __future__ import annotations
import hashlib, pickle, shutil, subprocess, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
from . import gear_core as core

AA="ACDEFGHIKLMNPQRSTVWY"; AA_I={a:i for i,a in enumerate(AA)}
EVO_DIM=48; MAX_MSA_SEQS=1024; PSEUDOCOUNT=0.5

def seq_hash(seq): return hashlib.sha1(str(seq).encode()).hexdigest()[:16]

def clean_a3m_sequence(s): return "".join(c for c in s if not c.islower()).replace(" ","")

def parse_a3m(path):
    seqs=[]; cur=[]
    with open(path,"r",errors="ignore") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            if line.startswith(">"):
                if cur: seqs.append(clean_a3m_sequence("".join(cur))); cur=[]
            else: cur.append(line)
    if cur: seqs.append(clean_a3m_sequence("".join(cur)))
    return seqs

def collect_sequences(stores, splits=("train","test300","test46")):
    out={}
    for s in splits:
        for item in stores[s].values():
            seq=str(item["sequence"]); out[seq_hash(seq)]=seq
    return out

def scan_completed_msas(msa_root, sequence_map):
    """Return hash->best A3M path. Largest valid A3M wins when ColabFold emits variants."""
    msa_root=Path(msa_root); done={}
    for p in msa_root.rglob("*.a3m"):
        try:
            seqs=parse_a3m(p)
            if not seqs: continue
            q=seqs[0].replace("-",""); h=seq_hash(q)
            if h in sequence_map and sequence_map[h]==q:
                old=done.get(h)
                if old is None or p.stat().st_size>old.stat().st_size: done[h]=p
        except Exception: pass
    return done

def install_colabfold_if_needed():
    if shutil.which("colabfold_batch") is None:
        subprocess.check_call([sys.executable,"-m","pip","install","-q","colabfold[alphafold]"])
    # colabfold may be installed without alphafold extra; verify import.
    r=subprocess.run([sys.executable,"-c","import alphafold, colabfold"],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if r.returncode!=0:
        subprocess.check_call([sys.executable,"-m","pip","install","-q","-U","colabfold[alphafold]"])
    return shutil.which("colabfold_batch")

def run_msa_batches(stores, base, splits=("train",), batch_size=25, max_retries=4, sleep_between=8, msa_mode="mmseqs2_uniref_env", max_batches=None):
    """Resume-safe ColabFold MSA search. For hypothesis testing use splits=('train',) first."""
    install_colabfold_if_needed(); base=Path(base); evo_root=base/"cache/evolution_v1"; msa_root=evo_root/"msa"; batch_root=msa_root/"batches"; batch_root.mkdir(parents=True,exist_ok=True)
    seqs=collect_sequences(stores,splits); done=scan_completed_msas(msa_root,seqs); missing=[(h,s) for h,s in seqs.items() if h not in done]
    batches=[missing[i:i+batch_size] for i in range(0,len(missing),batch_size)]
    if max_batches is not None: batches=batches[:int(max_batches)]
    print(f"Unique sequences={len(seqs)} | completed={len(done)} | missing={len(missing)} | batches this run={len(batches)}")
    failed=[]
    for bi,batch in enumerate(batches,1):
        # Stable name based on first/last hash prevents overwriting previous resumable batches.
        tag=f"batch_{batch[0][0]}_{batch[-1][0]}"; out=batch_root/tag; out.mkdir(parents=True,exist_ok=True); fasta=evo_root/f"{tag}.fasta"
        with open(fasta,"w") as f:
            for h,seq in batch: f.write(f">q_{h}\n{seq}\n")
        print("\n"+"="*80+f"\nMSA {bi}/{len(batches)} | n={len(batch)} | {tag}\n"+"="*80)
        ok=False
        for attempt in range(1,max_retries+1):
            cmd=["colabfold_batch",str(fasta),str(out),"--msa-only","--msa-mode",msa_mode]
            r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            tail="\n".join(r.stdout.splitlines()[-30:]); print(tail)
            if r.returncode==0: ok=True; break
            wait=15*attempt; print(f"Retry in {wait}s"); time.sleep(wait)
        if not ok: failed.append(tag)
        else: print("SUCCESS",tag,"A3M files=",len(list(out.rglob("*.a3m"))))
        time.sleep(sleep_between)
    return {"failed":failed,"msa_root":str(msa_root),"remaining_before_run":len(missing)}

def evo_from_msa(query, msa_sequences, max_msa_seqs=MAX_MSA_SEQS, pseudocount=PSEUDOCOUNT):
    L=len(query); rows=[]
    for s in msa_sequences:
        if len(s)==L: rows.append(s)
        if len(rows)>=max_msa_seqs: break
    if not rows: rows=[query]
    rows=list(dict.fromkeys(rows))
    if query not in rows: rows.insert(0,query)
    M=len(rows); X=np.zeros((L,EVO_DIM),dtype=np.float32); has=float(M>1); log_depth=float(np.log1p(max(M-1,0)))
    for pos in range(L):
        counts=np.zeros(20,dtype=float); valid=0
        for s in rows:
            a=s[pos]
            if a in AA_I: counts[AA_I[a]]+=1; valid+=1
        gap=1-valid/max(M,1); freq=counts+pseudocount/20.; freq/=freq.sum(); lod=np.log2(np.maximum(freq,1e-8)/0.05); lod=np.clip(lod,-5,5); entropy=-np.sum(freq*np.log(np.maximum(freq,1e-8)))/np.log(20)
        qa=query[pos]; focal=float(freq[AA_I[qa]]) if qa in AA_I else 0.; donor=sum(float(freq[AA_I[a]]) for a in "HCDE"); acidic=sum(float(freq[AA_I[a]]) for a in "DE"); hc=sum(float(freq[AA_I[a]]) for a in "HC")
        X[pos,0:20]=freq; X[pos,20:40]=lod; X[pos,40]=entropy; X[pos,41]=gap; X[pos,42]=log_depth; X[pos,43]=focal; X[pos,44]=donor; X[pos,45]=acidic; X[pos,46]=hc; X[pos,47]=has
    return X,M

def build_evo_cache(stores, base, splits=("train","test300","test46"), require_msa=False):
    base=Path(base); root=base/"cache/evolution_v1"; msa_root=root/"msa"; root.mkdir(parents=True,exist_ok=True); cache_file=root/"evo_features_v1_48d.pkl"; cache=pickle.load(open(cache_file,"rb")) if cache_file.exists() else {}
    seqs=collect_sequences(stores,splits); a3m=scan_completed_msas(msa_root,seqs); missing=[]; new=0
    for h,seq in tqdm(seqs.items(),desc="EVO cache"):
        # Recompute fallback rows later when a real MSA appears.
        old=cache.get(h)
        if old is not None and (old.get("a3m") is not None or h not in a3m):
            continue
        p=a3m.get(h)
        if p is None:
            if require_msa: missing.append(h); continue
            msa=[seq]; source=None
        else:
            msa=parse_a3m(p); source=str(p)
        X,depth=evo_from_msa(seq,msa); cache[h]={"X":X,"msa_depth":int(depth),"a3m":source}; new+=1
        if new%50==0: pickle.dump(cache,open(cache_file,"wb"),protocol=pickle.HIGHEST_PROTOCOL)
    pickle.dump(cache,open(cache_file,"wb"),protocol=pickle.HIGHEST_PROTOCOL)
    if missing: print(f"WARNING: {len(missing)} sequences have no MSA and were not cached (require_msa=True)")
    return cache

def attach_evo(stores, base, splits=("train","test300","test46"), require_msa=False):
    cache=build_evo_cache(stores,base,splits=splits,require_msa=require_msa); rows=[]
    for s in splits:
        for pid,item in stores[s].items():
            h=seq_hash(item["sequence"])
            if h not in cache:
                if require_msa: continue
                raise RuntimeError(f"EVO cache missing {pid}")
            X=np.asarray(cache[h]["X"],np.float32); n=len(item["y"])
            if X.shape[0]!=n: raise RuntimeError(f"{pid}: EVO length {X.shape[0]} != {n}")
            item["EVO"]=X; rows.append({"split":s,"protein":pid,"msa_depth":cache[h]["msa_depth"],"has_real_msa":cache[h].get("a3m") is not None})
    return pd.DataFrame(rows)
