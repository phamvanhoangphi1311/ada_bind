"""High-level orchestration for the GEAR Ultimate notebook."""
from __future__ import annotations
import json, math
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence
import numpy as np
import pandas as pd
import torch
from scipy.stats import ttest_rel, t as student_t
from . import gear_core as core
from . import gear_structure as structure
from . import gear_mechanistic as mech

STANDARDIZED_13 = dict(core.FULL_REPRESENTATIONS)
MECH1 = ["ACCESS","SHELL2","ENV","CONF"]
MULTI2 = ["METALSPEC","ELEC3D","TOPO","SOLV","SEQMOTIF"]
MECHANISTIC_GRID = {
    "BASE_ESM+Atomic+Chem":["ESM","ATOM","CHEM"],
    "BASE+Access":["ESM","ATOM","CHEM","ACCESS"],
    "BASE+Shell2":["ESM","ATOM","CHEM","SHELL2"],
    "BASE+Env":["ESM","ATOM","CHEM","ENV"],
    "BASE+Conf":["ESM","ATOM","CHEM","CONF"],
    "BASE+MetalSpec":["ESM","ATOM","CHEM","METALSPEC"],
    "BASE+Elec3D":["ESM","ATOM","CHEM","ELEC3D"],
    "BASE+Topology":["ESM","ATOM","CHEM","TOPO"],
    "BASE+Solvation":["ESM","ATOM","CHEM","SOLV"],
    "BASE+SeqMotif":["ESM","ATOM","CHEM","SEQMOTIF"],
    "BASE+MECH1":["ESM","ATOM","CHEM",*MECH1],
    "BASE+MULTI2":["ESM","ATOM","CHEM",*MULTI2],
    "BASE+ALL9":["ESM","ATOM","CHEM",*MECH1,*MULTI2],
}
FINAL_COMPARISON_REPS = {
    "ESM":["ESM"],
    "ESM+Atomic":["ESM","ATOM"],
    "ESM+Chem":["ESM","CHEM"],
    "ESM+Atomic+Chem":["ESM","ATOM","CHEM"],
    "ESM+MULTI2":["ESM",*MULTI2],
    "ESM+Atomic+Chem+MULTI2":["ESM","ATOM","CHEM",*MULTI2],
}
NO_ESM_GRID = {
    "AA+Atomic+Chem":["AA","ATOM","CHEM"],
    "AA+Atomic+Chem+MULTI2":["AA","ATOM","CHEM",*MULTI2],
    "SEQCTX+Atomic+Chem+MULTI2":["SEQCTX","ATOM","CHEM",*MULTI2],
    "AA+SEQCTX+Atomic+Chem+MULTI2":["AA","SEQCTX","ATOM","CHEM",*MULTI2],
    "CompactFull":["AA","SEQCTX","ATOM","CHEM",*MULTI2,"ACCESS","SHELL2"],
    "ESM+Atomic+Chem+MULTI2_REF":["ESM","ATOM","CHEM",*MULTI2],
}
EVO_GRID = {
    "AA+EVO":["AA","EVO"],
    "AA+Chem+EVO":["AA","CHEM","EVO"],
    "AA+Atomic+Chem+EVO":["AA","ATOM","CHEM","EVO"],
    "AA+Atomic+Chem+MULTI2+EVO":["AA","ATOM","CHEM",*MULTI2,"EVO"],
    "ESM+Atomic+Chem+MULTI2_REF":["ESM","ATOM","CHEM",*MULTI2],
}

@dataclass
class Context:
    cfg: core.Config
    paths: dict
    frames: dict
    fold_ids: list
    stores: dict
    device: torch.device


def prepare_context(base="/content/drive/MyDrive/Protein-binding", run_version="ultimate_context_v1", models=("MLP","KAN","XGBoost"), ensure_base=True, add_mech=True, add_multi=True, add_seqctx=True, esm_batch_size=8, device=None):
    device=device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cfg=core.Config(base=str(base),label_column="metal_binding",run_version=run_version,models=tuple(models)); paths=core.make_paths(cfg)
    frames={"train":core.load_frame(paths["train_csv"]),"test300":core.load_frame(paths["test300_csv"]),"test46":core.load_frame(paths["test46_csv"])}; folds=core.load_bindnode24_folds(); official=set().union(*map(set,folds)); frames["train"]=frames["train"][frames["train"].prot_id.astype(str).isin(official)].reset_index(drop=True)
    if ensure_base: structure.ensure_base_caches(frames,paths,cfg,device=device,esm_batch_size=esm_batch_size)
    caches={}
    for key,split in (("train","DevSet1010"),("test300","TestSet300"),("test46","TestSetNew46")):
        atom,chem=core.ensure_atom_chem_caches(frames[key],split,paths,cfg); caches[key]=(atom,chem)
    stores={key:core.build_store(frames[key],split,paths,cfg,*caches[key]) for key,split in (("train","DevSet1010"),("test300","TestSet300"),("test46","TestSetNew46"))}
    if add_mech or add_multi: mech.ensure_and_attach_all(stores,frames,paths,cfg,mech1=add_mech,multi2=add_multi)
    if add_seqctx: mech.attach_seqctx(stores)
    print("Store sizes:",{k:len(v) for k,v in stores.items()}); print("Feature dims:",{k:np.asarray(next(iter(stores["train"].values()))[k]).shape[1] for k in next(iter(stores["train"].values())) if isinstance(next(iter(stores["train"].values()))[k],np.ndarray) and next(iter(stores["train"].values()))[k].ndim==2})
    return Context(cfg,paths,frames,folds,stores,device)


def clone_context_for_run(ctx: Context, run_version: str, models=("MLP",), **cfg_overrides):
    data=dict(ctx.cfg.__dict__); data.update(cfg_overrides); data["run_version"]=run_version; data["models"]=tuple(models); cfg=core.Config(**data); return Context(cfg,core.make_paths(cfg),ctx.frames,ctx.fold_ids,ctx.stores,ctx.device)


def holm_adjust(pvals):
    p=np.asarray(pvals,float); m=len(p); order=np.argsort(p); adj=np.empty(m,float); running=0.
    for rank,idx in enumerate(order):
        val=(m-rank)*p[idx]; running=max(running,val); adj[idx]=min(running,1.)
    return adj


def paired_effects(fold_df, comparisons, model="MLP", metric="AUPRC", holm=True):
    rows=[]
    for better,ref,label in comparisons:
        a=fold_df[(fold_df.model==model)&(fold_df.representation==better)].set_index("fold")[metric]; b=fold_df[(fold_df.model==model)&(fold_df.representation==ref)].set_index("fold")[metric]; common=a.index.intersection(b.index); d=(a.loc[common]-b.loc[common]).to_numpy(float)
        if len(d)<2: continue
        mean=float(d.mean()); half=float(student_t.ppf(.975,len(d)-1)*d.std(ddof=1)/np.sqrt(len(d))); stat,p=ttest_rel(a.loc[common],b.loc[common]); rows.append({"model":model,"comparison":label,"better":better,"reference":ref,"mean_delta":mean,"ci95_low":mean-half,"ci95_high":mean+half,"positive_folds":int((d>0).sum()),"n_folds":len(d),"p_raw":float(p),"fold_deltas":json.dumps(d.tolist())})
    out=pd.DataFrame(rows)
    if holm and len(out): out["p_holm"]=holm_adjust(out.p_raw.to_numpy())
    return out


def run_grid(ctx: Context, representations: Mapping[str,Sequence[str]], models=None, comparisons=None):
    models=tuple(models or ctx.cfg.models); ctx.cfg.models=models; run_hash=core.config_hash(ctx.cfg,representations); print("RUN HASH:",run_hash); print("RUN ROOT:",ctx.paths["run_root"])
    for model in models:
        if model=="KAN" and not core.HAS_KAN:
            print("SKIP KAN: pykan import unavailable:",getattr(core,"KAN_IMPORT_ERROR","unknown")); continue
        for rep,blocks in representations.items():
            missing=[b for b in blocks if b not in next(iter(ctx.stores["train"].values()))]
            if missing: raise KeyError(f"{rep}: missing blocks {missing}")
            for fold in range(5): core.run_one_job(model,rep,blocks,fold,ctx.fold_ids,ctx.stores,ctx.paths,ctx.cfg,run_hash,ctx.device)
    core.aggregate_reports(ctx.paths,ctx.stores,representations,ctx.cfg,run_hash)
    fold_path=ctx.paths["run_root"]/"fold_metrics.csv"; fold=pd.read_csv(fold_path); fold=fold[fold.config_hash.astype(str)==str(run_hash)].copy()
    if comparisons:
        pieces=[]
        for m in models:
            z=paired_effects(fold,comparisons,model=m)
            if len(z): pieces.append(z)
        paired=pd.concat(pieces,ignore_index=True) if pieces else pd.DataFrame(); paired.to_csv(ctx.paths["run_root"]/"paired_custom_AUPRC.csv",index=False)
    else: paired=pd.DataFrame()
    cv=pd.read_csv(ctx.paths["run_root"]/"cv_summary.csv") if (ctx.paths["run_root"]/"cv_summary.csv").exists() else pd.DataFrame(); ext=pd.read_csv(ctx.paths["run_root"]/"external_summary.csv") if (ctx.paths["run_root"]/"external_summary.csv").exists() else pd.DataFrame(); return cv,ext,paired

MECHANISTIC_COMPARISONS = [(x,"BASE_ESM+Atomic+Chem",f"{x} vs BASE") for x in ["BASE+Access","BASE+Shell2","BASE+Env","BASE+Conf","BASE+MetalSpec","BASE+Elec3D","BASE+Topology","BASE+Solvation","BASE+SeqMotif"]] + [("BASE+MECH1","BASE_ESM+Atomic+Chem","MECH1 vs BASE"),("BASE+MULTI2","BASE_ESM+Atomic+Chem","MULTI2 vs BASE"),("BASE+ALL9","BASE_ESM+Atomic+Chem","ALL9 vs BASE"),("BASE+ALL9","BASE+MULTI2","Additional MECH1 after MULTI2")]


def audit_context(ctx):
    rows=[]
    for k,store in ctx.stores.items():
        nres=sum(len(x["y"]) for x in store.values()); pos=sum(int(np.asarray(x["y"]).sum()) for x in store.values()); rows.append({"split":k,"proteins":len(store),"residues":nres,"positives":pos,"prevalence":pos/max(nres,1)})
    return pd.DataFrame(rows)


def known_result_history():
    """Frozen checkpoints from the experiment lineage; for reference, not substituted for reruns."""
    return pd.DataFrame([
        ["Historical KAN","Test300",.3110,.7965,.3902,.4048],["Historical KAN","Test46",.5634,.9529,.6713,.6696],
        ["ESM+Atomic","Test300",.3578,.8275,.3214,.3256],["ESM+Atomic","Test46",.6520,.9634,.4552,.4942],
        ["ESM+Chem","Test300",.3525,.8297,.2963,.3093],["ESM+Chem","Test46",.6784,.9719,.3743,.4372],
        ["ESM+Atomic+Chem","Test300",.3694,.8342,.2905,.3045],["ESM+Atomic+Chem","Test46",.6655,.9659,.4172,.4689],
        ["ESM+MULTI2","Test300",.3718,.8384,.2987,.3130],["ESM+MULTI2","Test46",.6641,.9655,.4013,.4537],
        ["FINAL ESM+Atomic+Chem+MULTI2","Test300",.3842,.8315,.3830,.3773],["FINAL ESM+Atomic+Chem+MULTI2","Test46",.6936,.9670,.5577,.5709],
    ],columns=["representation","dataset","AUPRC","AUROC","F1@0.5","MCC@0.5"])


def run_dev_cv_only(ctx: Context, representations: Mapping[str,Sequence[str]], models=("MLP",), run_version="ultimate_dev_only_v1"):
    """Run official 5-fold Dev CV without touching external labels/predictions.

    Useful for EVO while only DevSet1010 MSAs are available. Results are independently
    resumable under `results/<run_version>/metal_binding/dev_only_predictions`.
    """
    root=Path(ctx.cfg.base)/"results"/run_version/ctx.cfg.label_column; pred=root/"dev_only_predictions"; pred.mkdir(parents=True,exist_ok=True); rows=[]
    for model_name in models:
        for rep,blocks in representations.items():
            for fold in range(5):
                pp=pred/f"{model_name}__{rep.replace('+','__')}__fold{fold+1}.pkl"
                if pp.exists():
                    z=core.load_pickle(pp); m=core.binary_metrics(z["y"],z["p"],.5); rows.append({"model":model_name,"representation":rep,"fold":fold+1,**{"AUPRC":m["auprc"],"AUROC":m["auroc"],"F1@0.5":m["f1"],"MCC@0.5":m["mcc"]}}); print("REUSE",model_name,rep,fold+1); continue
                tr,va=core.get_fold_train_val_ids(fold,ctx.fold_ids,ctx.stores["train"]); missing=[pid for pid in tr+va if any(b not in ctx.stores["train"][pid] for b in blocks)]
                if missing: raise RuntimeError(f"{rep}: {len(missing)} Dev proteins lack required blocks; first examples {missing[:5]}")
                seed=ctx.cfg.seed+fold+1000*{"MLP":1,"KAN":2,"XGBoost":3}[model_name]
                if model_name in ("MLP","KAN"):
                    model,scaler,meta=core.train_neural(model_name,ctx.stores["train"],tr,va,blocks,ctx.cfg,seed,ctx.device); y,p=core.predict_neural(model,model_name,ctx.stores["train"],va,blocks,scaler,ctx.device,ctx.cfg.proteins_per_batch_mlp if model_name=="MLP" else ctx.cfg.proteins_per_batch_kan)
                else:
                    model,_,meta=core.train_xgboost(ctx.stores["train"],tr,va,blocks,ctx.cfg,seed,ctx.device); y,p=core.predict_xgboost(model,ctx.stores["train"],va,blocks)
                core.save_pickle({"model":model_name,"representation":rep,"fold":fold+1,"y":y,"p":p,"meta":meta},pp); m=core.binary_metrics(y,p,.5); rows.append({"model":model_name,"representation":rep,"fold":fold+1,"AUPRC":m["auprc"],"AUROC":m["auroc"],"F1@0.5":m["f1"],"MCC@0.5":m["mcc"]}); print("DONE",model_name,rep,fold+1,"AUPRC",m["auprc"])
    fold_df=pd.DataFrame(rows); fold_df.to_csv(root/"fold_metrics.csv",index=False); cv=fold_df.groupby(["model","representation"],as_index=False).agg(CV_AUPRC=("AUPRC","mean"),CV_AUPRC_SD=("AUPRC","std"),CV_AUROC=("AUROC","mean")); cv.to_csv(root/"cv_summary.csv",index=False); return cv,fold_df
