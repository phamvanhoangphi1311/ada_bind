# GEAR Ultimate — metal-binding residue prediction

This bundle consolidates the entire GEAR experiment lineage into one modular, resumable Colab workflow. The notebook is intentionally small; scientific logic lives in `gear_ultimate/*.py` so caches, models, feature definitions, graph construction, MSA processing, and reporting can be versioned separately.

## Folder layout

```text
GEAR_ULTIMATE/
├── GEAR_ULTIMATE_METAL_BINDING.ipynb   # orchestrator notebook
├── gear_ultimate/
│   ├── gear_core.py                    # standardized MLP / KAN / XGBoost protocol
│   ├── gear_structure.py               # ESM + SPATIAL112 + LOCAL8 cache generation
│   ├── gear_mechanistic.py             # ATOM/CHEM-compatible MECH1 + MULTI2 + SEQCTX
│   ├── gear_legacy.py                  # historical KAN baseline protocol
│   ├── gear_graph.py                   # maximal + clean/residual graph experiments
│   ├── gear_evolution.py               # ColabFold MSA + EVO48
│   ├── gear_suite.py                   # experiment grids and orchestration
│   └── gear_reporting.py               # final tables and error-overlap helpers
├── requirements.txt
├── requirements_evolution.txt
└── EXPERIMENT_HISTORY.md
```

## Recommended Drive location

Upload/extract this whole folder to:

```text
/content/drive/MyDrive/Protein-binding/GEAR_ULTIMATE
```

The existing project data are expected under:

```text
/content/drive/MyDrive/Protein-binding/
  data/development_set/full_grouped_train_binding_sites_df.csv
  data/development_set/full_grouped_test_binding_sites_df.csv
  data/independent_set/grouped_test_46_new_binding_sites.csv
  esmFold_pdb_files/*.pdb
```

All new caches and results are written below the existing project root. Existing standardized caches are reused when compatible.

## Scientific protocol

Primary development selection is **official bindNode24 protein-level 5-fold CV on DevSet1010**. External TestSet300 and TestSetNew46 are confirmation sets. OOF thresholds are selected on Dev only and then locked before external evaluation. Primary metric is residue-level AUPRC; MCC/F1 are secondary and AUROC is reported for context.

The historical KAN baseline is preserved as a separate protocol because its early-stopping objective and loss differ from the later standardized suite. In particular, the historical `no_graph` classifier has no graph message passing in the forward pass, but its training loss contains label-aware spatial smoothness over Cα edges. It should not be described as a strictly structure-free control.

## Main representation blocks

| Block | Dim | Meaning |
|---|---:|---|
| AA | 20 | focal residue identity |
| ESM | 1280 | ESM-2 t33 mean last two hidden layers |
| SPATIAL | 112 | explicit radial 3D microenvironment |
| LOCAL | 8 | DSSP, circular phi/psi, relative SASA proxy |
| ATOM | 15 | candidate coordination geometry |
| CHEM | 24 | donor chemistry + local electrostatic proxies |
| ACCESS | 10 | accessibility / packing / openness |
| SHELL2 | 12 | second-shell support |
| ENV | 8 | physicochemical microenvironment |
| CONF | 4 | ESMFold confidence proxies |
| METALSPEC | 18 | heuristic metal-family compatibility |
| ELEC3D | 8 | directional electrostatic proxies |
| TOPO | 12 | donor-network topology |
| SOLV | 10 | local solvation / polarity organization |
| SEQMOTIF | 10 | explicit sequence donor motifs |
| SEQCTX | 182 | explicit local sequence context control |
| EVO | 48 | MSA profile / conservation features |

`MULTI2 = METALSPEC + ELEC3D + TOPO + SOLV + SEQMOTIF = 58 d`.

## What to run first

1. `prepare_context(...)` — checks data/folds and creates/reuses ESM, structure, ATOM, CHEM, MECH1, MULTI2 and SEQCTX caches.
2. Historical baseline only if you need exact reproduction of the original paper/notebook.
3. Standardized grid with MLP first; enable KAN/XGBoost when required.
4. Final focused representation grid.
5. No-ESM compact and graph diagnostics.
6. EVO: run MSA on **DevSet1010 first**. Only request external MSAs if EVO improves Dev CV enough to justify the cost.

## MSA warning

The public ColabFold/MMseqs2 service is rate-limited. The included MSA runner uses small batches, retries, sleeps, and persistent Drive outputs. Do not launch many parallel public-server workers. For large final-scale production, a local MMseqs2 database is preferable.

## Reproducibility notes

- Feature caches are label-independent.
- Train-fold scalers and class weights are fit on training proteins only.
- External labels are not used for early stopping or threshold selection.
- Model artifacts are keyed by configuration hash where the standardized runner is used.
- Multiple external peeks during development mean those external sets should be treated as confirmation rather than pristine blind test sets for future tuning. A new blind external cohort is preferred for a final locked claim.
- ESMFold-derived PDBs mean a “no ESM embedding” experiment is not fully PLM-free at the structure-generation level.

See `EXPERIMENT_HISTORY.md` for the full experiment lineage and frozen results observed before this bundle was generated.

## Convenience installer

If you first upload/extract the bundle under `/content/GEAR_ULTIMATE`, you can copy it into the recommended Drive location with:

```bash
python /content/GEAR_ULTIMATE/install_to_drive.py --overwrite
```

See `SOURCE_LINEAGE.md` for which modules are source-faithful consolidations and which graph component is a specification-faithful reconstruction.
