# GEAR experiment lineage — frozen checkpoints before Ultimate bundle

This file records the results observed during development. It is a provenance/reference log, not a replacement for rerunning the code.

## 1. Historical `no_graph` KAN baseline

- ESM-2 `facebook/esm2_t33_650M_UR50D`, mean of last 2 hidden layers = 1280 d/residue.
- Historical local structure = DSSP H/E/C + raw phi + raw psi = 5 d.
- Classifier: `Linear(node_dim,32) -> KAN([32,8,2], grid=2, k=2)`, 43,872 trainable parameters in the historical run.
- Loss: weighted focal CE plus label-aware spatial smoothness; `POS_WEIGHT=9`, `gamma=2`, `position_weight=1.5`.
- Smoothness edges: Cα distance <17 Å, max 64 neighbors.
- Seed 15, 50 epochs, batch 64, AdamW lr 1e-4, wd 0.015, early stopping on validation micro F1 at threshold 0.5.

External metal-binding results:

| Dataset | AUPRC | AUROC | micro F1@0.5 | MCC@0.5 | macro-positive F1 | macro-positive MCC |
|---|---:|---:|---:|---:|---:|---:|
| TestSet300 | 0.3110 | 0.7965 | 0.3902 | 0.4048 | 0.2861 ± 0.0534 | 0.2971 ± 0.0545 |
| TestSetNew46 | 0.5634 | 0.9529 | 0.6713 | 0.6696 | 0.4257 ± 0.2027 | 0.4259 ± 0.2028 |

## 2. Spatial revamp

Patched structural representation:
- `SPATIAL112`: Cβ (Gly Cα) radial shells 0–4 / 4–6 / 6–8 / 8–10 Å, AA counts, nearest AA distances, long-range contacts and neighborhood summaries.
- `LOCAL8`: DSSP H/E/C, sin/cos phi, sin/cos psi, relative SASA proxy.

Stage-A Dev CV AUPRC:

| Representation | CV AUPRC |
|---|---:|
| ESM | 0.406102 |
| ESM+Spatial | 0.400905 |
| ESM+LocalStruct | 0.399604 |
| ESM+Spatial+Local | 0.399082 |
| AA+Spatial | 0.255266 |
| AA | 0.074441 |

Interpretation: coarse structure carries real signal without ESM, but is largely redundant after ESM.

## 3. Atomic coordination geometry

`ATOM15` models protein-side candidate coordination geometry using CYS SG, HIS ND1/NE2, ASP OD1/OD2, GLU OE1/OE2 and hypothetical 2.1 Å metal centers.

Key paired Dev results:
- ESM+Atomic AUPRC 0.437603 vs ESM 0.394372; Δ +0.043231, 5/5 folds, CI approximately [0.0235, 0.0630].
- AA+Atomic 0.378334 vs AA 0.074393; Δ +0.303941, 5/5 folds.
- Structure adds ~0 after Atomic.

## 4. Chemistry v1 and standardized 3-model suite

`CHEM24` includes donor-type counts within 4/6 Å and charge/electrostatic/O-N-S composition proxies.

Standardized MLP Dev CV AUPRC:

| Representation | AUPRC |
|---|---:|
| AA | ~0.0763 |
| AA+Structure | ~0.2679 |
| AA+Atomic | ~0.3813 |
| AA+Chem | ~0.4056 |
| AA+Atomic+Chem | ~0.4106 |
| ESM | 0.40232 |
| ESM+Structure | ~0.4049 |
| ESM+Atomic | 0.43928 |
| ESM+Chem | 0.44314 |
| ESM+Structure+Atomic | ~0.4389 |
| ESM+Structure+Chem | 0.43826 |
| ESM+Atomic+Chem | 0.44726 |
| ESM+Structure+Atomic+Chem | 0.44352 |

Atomic vs ESM Δ ~+0.0370 (5/5); Chem vs ESM Δ ~+0.0408 (5/5). Atomic+Chem gain over Atomic was small and not consistently significant.

## 5. MECH1 and MULTI2

MECH1 = 34 d:
- ACCESS 10
- SHELL2 12
- ENV 8
- CONF 4

MULTI2 = 58 d:
- METALSPEC 18
- ELEC3D 8
- TOPO 12
- SOLV 10
- SEQMOTIF 10

Merged MLP Dev CV AUPRC:

| Representation | CV AUPRC |
|---|---:|
| BASE+Topology | 0.4617727 |
| BASE+MULTI2 | 0.4583516 |
| BASE+Shell2 | 0.4567981 |
| BASE+ALL9 | 0.4540741 |
| BASE+MECH1 | 0.4517535 |
| BASE+Solvation | 0.4512501 |
| BASE+Access | 0.4506098 |
| BASE+MetalSpec | 0.4504608 |
| BASE+SeqMotif | 0.4499256 |
| BASE+Env | 0.4487896 |
| BASE+Elec3D | 0.4483528 |
| BASE ESM+Atomic+Chem | 0.4472754 |
| BASE+Conf | 0.4472199 |

MULTI2 vs BASE: Δ +0.011076, 5/5 folds, 95% CI [0.000193, 0.021960], raw p=0.04756, Holm-adjusted p=0.6658. No individual feature family survived Holm correction.

## 6. Final focused external comparison

| Representation | Test300 AUPRC | Test46 AUPRC |
|---|---:|---:|
| Original historical KAN | 0.3110 | 0.5634 |
| ESM+Atomic | 0.3578 | 0.6520 |
| ESM+Chem | 0.3525 | 0.6784 |
| ESM+Atomic+Chem | 0.3694 | 0.6655 |
| ESM+MULTI2 | 0.3718 | 0.6641 |
| **ESM+Atomic+Chem+MULTI2** | **0.3842** | **0.6936** |

Final representation gained approximately +23.55% relative AUPRC on Test300 and +23.11% on Test46 versus the historical baseline. Correct claim: highest AUPRC on both external sets, not highest on every metric.

Final locked-OOF-threshold results:
- Test300: threshold 0.9259, F1 0.4638, MCC 0.4920.
- Test46: F1 0.7111, MCC 0.7153.

## 7. Error-overlap / Sankey diagnostic

Among true-positive residues:

Test300 (881 positives):
- ESM TP/FN = 255/626
- Atomic = 286/595
- Chem = 266/615
- AtomicChem = 288/593
- MULTI2 = 309/572
- Final = 301/580
- Final rescued 63 ESM false negatives, lost 17 ESM true positives, net +46 TP.

Test46 (77 positives):
- ESM = 44/33
- Atomic = 47/30
- Chem = 53/24
- AtomicChem = 47/30
- MULTI2 = 49/28
- Final = 48/29

Interpretation: engineered features mostly correct a small hard-case subset rather than replacing all ESM signal.

## 8. No-ESM compact representations

`SEQCTX182`: 160 positional one-hot features at offsets ±1..±4, 20 AA-composition features in ±8 window, relative position and terminal proximity.

External AUPRC:

| Representation | Test300 | Test46 |
|---|---:|---:|
| ESM+Atomic+Chem+MULTI2 | 0.3842 | 0.6936 |
| AA+Atomic+Chem+MULTI2 | 0.3563 | 0.6163 |
| CompactFull | 0.3537 | 0.6188 |
| AA+Atomic+Chem | 0.3522 | 0.6086 |
| SEQCTX+Atomic+Chem+MULTI2 | 0.3477 | 0.5931 |
| AA+SEQCTX+Atomic+Chem+MULTI2 | 0.3464 | 0.6024 |

AA+Atomic+Chem+MULTI2 Dev folds: approximately 0.3959, 0.3671, 0.4399, 0.4826, 0.3847; mean ~0.4140. Compact mechanism-first information retains roughly 90% of ESM-augmented performance but leaves a significant context gap.

## 9. Maximal no-ESM graph

Node input = 453 d: AA20 + SEQCTX182 + SPATIAL112 + LOCAL8 + ATOM15 + CHEM24 + ACCESS10 + SHELL2 12 + ENV8 + CONF4 + METALSPEC18 + ELEC3D8 + TOPO12 + SOLV10 + SEQMOTIF10.

Edge input = 18 d: Cα distance/proximity, sequence separation, donor flags/distances, first-shell/second-shell relations, and charge relations.

Architecture: 3-layer edge-conditioned gated residual MPNN, hidden 160, edge hidden 48.

Results:
- Dev CV AUPRC 0.4083 ± 0.0446.
- Test300 AUPRC 0.3449.
- Test46 AUPRC 0.5897.

It underperformed the compact tabular no-ESM representation, supporting redundancy/noise/oversmoothing concerns.

## 10. Clean graph v2

Experiments:
- PureGraph_AA_Chem (44 d, rich edges)
- PureGraph_AA_Atomic_Chem (59 d, rich)
- ResidualGraph_AA_Atomic_Chem (59 d, rich)
- ResidualGraph_Compact (117 d, rich)
- ResidualGraph_DonorFocused (59 d, donor-focused)

Architecture: hidden 128, edge hidden 32, 2 message-passing layers. Residual model predicts `local_logit + sigmoid(alpha_raw) * graph_delta`, alpha initialized near 0.10.

Completed observations:
- PureGraph_AA_Chem folds = 0.4015, 0.4068, 0.4435, 0.4331, 0.3819; mean ~0.4134.
- PureGraph_AA_Atomic_Chem folds = 0.3831, 0.3945, 0.4386, 0.4652, 0.3863; mean ~0.4135.
- ResidualGraph_AA_Atomic_Chem folds = 0.3840, 0.3828, 0.4257, 0.4493, 0.3869; mean ~0.4057; alpha stayed around 0.103–0.107.

Interpretation: graph relations help AA+Chem modestly, but most local relational geometry is already summarized by ATOM. The remaining ESM gap likely contains context not recoverable by adding more local geometry alone.

## 11. Current EVO direction

Hypothesis: the residual ESM advantage may reflect evolutionary/function priors, whole-protein context, and long-range sequence semantics.

EVO v1 = 48 d per residue:
- 20 MSA AA frequencies
- 20 log-odds vs uniform background
- normalized entropy
- gap fraction
- log homolog depth
- focal-AA frequency
- HCDE donor-group frequency
- DE acidic frequency
- HC frequency
- has-homologs flag

At bundle creation time, ColabFold/MSA acquisition was in progress. Public server rate limiting was observed; batch size 25 with resume/retry was working. Scientific recommendation: finish DevSet1010 first, test EVO on Dev CV, and request external MSAs only if the Dev result justifies it.
